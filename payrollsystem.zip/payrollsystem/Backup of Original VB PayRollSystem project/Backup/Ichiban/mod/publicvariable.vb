﻿Module publicvariable
    Public con As OleDb.OleDbConnection = myconn()
    Public Nname As String
    Public Ngposition As String
    Public taxid As String
    Public emptaxid As String



End Module

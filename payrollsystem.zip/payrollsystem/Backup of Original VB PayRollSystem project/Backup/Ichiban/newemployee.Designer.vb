﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class newemployee
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Label4 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.cbpositon = New System.Windows.Forms.TextBox
        Me.Label40 = New System.Windows.Forms.Label
        Me.Label39 = New System.Windows.Forms.Label
        Me.Label38 = New System.Windows.Forms.Label
        Me.Label37 = New System.Windows.Forms.Label
        Me.Label36 = New System.Windows.Forms.Label
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.rbdep0 = New System.Windows.Forms.RadioButton
        Me.rbdep4 = New System.Windows.Forms.RadioButton
        Me.rbdep3 = New System.Windows.Forms.RadioButton
        Me.rbdep2 = New System.Windows.Forms.RadioButton
        Me.rbdep1 = New System.Windows.Forms.RadioButton
        Me.Label35 = New System.Windows.Forms.Label
        Me.cbocivil = New System.Windows.Forms.ComboBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.Label27 = New System.Windows.Forms.Label
        Me.Label30 = New System.Windows.Forms.Label
        Me.txtcollegeYear = New System.Windows.Forms.MaskedTextBox
        Me.txthschool_yeAR = New System.Windows.Forms.MaskedTextBox
        Me.txtelem_year = New System.Windows.Forms.MaskedTextBox
        Me.Label29 = New System.Windows.Forms.Label
        Me.txtcollege = New System.Windows.Forms.MaskedTextBox
        Me.Label23 = New System.Windows.Forms.Label
        Me.txthschool = New System.Windows.Forms.MaskedTextBox
        Me.Label22 = New System.Windows.Forms.Label
        Me.txtelem = New System.Windows.Forms.MaskedTextBox
        Me.Label24 = New System.Windows.Forms.Label
        Me.TabPage3 = New System.Windows.Forms.TabPage
        Me.Label45 = New System.Windows.Forms.Label
        Me.Label46 = New System.Windows.Forms.Label
        Me.txtPHIC = New System.Windows.Forms.MaskedTextBox
        Me.Label34 = New System.Windows.Forms.Label
        Me.Label44 = New System.Windows.Forms.Label
        Me.txtHDMF = New System.Windows.Forms.MaskedTextBox
        Me.Label43 = New System.Windows.Forms.Label
        Me.Label33 = New System.Windows.Forms.Label
        Me.txtpc = New System.Windows.Forms.DateTimePicker
        Me.Label42 = New System.Windows.Forms.Label
        Me.Label41 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.txtothers = New System.Windows.Forms.MaskedTextBox
        Me.txtnbic = New System.Windows.Forms.MaskedTextBox
        Me.Label32 = New System.Windows.Forms.Label
        Me.txtgl = New System.Windows.Forms.MaskedTextBox
        Me.Label31 = New System.Windows.Forms.Label
        Me.cboworkstat = New System.Windows.Forms.ComboBox
        Me.dtpHiredate = New System.Windows.Forms.DateTimePicker
        Me.Label21 = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.txtmotheradd = New System.Windows.Forms.TextBox
        Me.Label26 = New System.Windows.Forms.Label
        Me.txtfatheradd = New System.Windows.Forms.TextBox
        Me.Label28 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.txtsadd = New System.Windows.Forms.TextBox
        Me.lblsadd = New System.Windows.Forms.Label
        Me.txtmothername = New System.Windows.Forms.TextBox
        Me.Label20 = New System.Windows.Forms.Label
        Me.txtfathername = New System.Windows.Forms.TextBox
        Me.Label18 = New System.Windows.Forms.Label
        Me.txtnamSpouse = New System.Windows.Forms.TextBox
        Me.lblspouse = New System.Windows.Forms.Label
        Me.rdofemale = New System.Windows.Forms.RadioButton
        Me.rdomale = New System.Windows.Forms.RadioButton
        Me.dtpbdate = New System.Windows.Forms.DateTimePicker
        Me.txtreligon = New System.Windows.Forms.TextBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.txtcitizen = New System.Windows.Forms.TextBox
        Me.Label14 = New System.Windows.Forms.Label
        Me.txtHeight = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.txtContact = New System.Windows.Forms.TextBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.txtbplace = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.txtweight = New System.Windows.Forms.TextBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.txtage = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtmname = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtemp_id = New System.Windows.Forms.TextBox
        Me.label = New System.Windows.Forms.Label
        Me.txtfname = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtlname = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.btnadd = New System.Windows.Forms.Button
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog
        Me.Button1 = New System.Windows.Forms.Button
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.txtwecom1 = New System.Windows.Forms.TextBox
        Me.txtwecom2 = New System.Windows.Forms.TextBox
        Me.txtwecom3 = New System.Windows.Forms.TextBox
        Me.txtwepos1 = New System.Windows.Forms.TextBox
        Me.txtwepos2 = New System.Windows.Forms.TextBox
        Me.txtwepos3 = New System.Windows.Forms.TextBox
        Me.Label47 = New System.Windows.Forms.Label
        Me.Label48 = New System.Windows.Forms.Label
        Me.Label50 = New System.Windows.Forms.Label
        Me.txtwedate1 = New System.Windows.Forms.TextBox
        Me.txtwedate2 = New System.Windows.Forms.TextBox
        Me.txtwedate3 = New System.Windows.Forms.TextBox
        Me.Panel1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(663, 51)
        Me.Panel1.TabIndex = 3
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.Label4.Location = New System.Drawing.Point(3, 9)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(348, 33)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Add New Employee"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.cbpositon)
        Me.GroupBox1.Controls.Add(Me.Label40)
        Me.GroupBox1.Controls.Add(Me.Label39)
        Me.GroupBox1.Controls.Add(Me.Label38)
        Me.GroupBox1.Controls.Add(Me.Label37)
        Me.GroupBox1.Controls.Add(Me.Label36)
        Me.GroupBox1.Controls.Add(Me.GroupBox2)
        Me.GroupBox1.Controls.Add(Me.Label35)
        Me.GroupBox1.Controls.Add(Me.cbocivil)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.TabControl1)
        Me.GroupBox1.Controls.Add(Me.cboworkstat)
        Me.GroupBox1.Controls.Add(Me.dtpHiredate)
        Me.GroupBox1.Controls.Add(Me.Label21)
        Me.GroupBox1.Controls.Add(Me.Label25)
        Me.GroupBox1.Controls.Add(Me.txtmotheradd)
        Me.GroupBox1.Controls.Add(Me.Label26)
        Me.GroupBox1.Controls.Add(Me.txtfatheradd)
        Me.GroupBox1.Controls.Add(Me.Label28)
        Me.GroupBox1.Controls.Add(Me.Label17)
        Me.GroupBox1.Controls.Add(Me.txtsadd)
        Me.GroupBox1.Controls.Add(Me.lblsadd)
        Me.GroupBox1.Controls.Add(Me.txtmothername)
        Me.GroupBox1.Controls.Add(Me.Label20)
        Me.GroupBox1.Controls.Add(Me.txtfathername)
        Me.GroupBox1.Controls.Add(Me.Label18)
        Me.GroupBox1.Controls.Add(Me.txtnamSpouse)
        Me.GroupBox1.Controls.Add(Me.lblspouse)
        Me.GroupBox1.Controls.Add(Me.rdofemale)
        Me.GroupBox1.Controls.Add(Me.rdomale)
        Me.GroupBox1.Controls.Add(Me.dtpbdate)
        Me.GroupBox1.Controls.Add(Me.txtreligon)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.txtcitizen)
        Me.GroupBox1.Controls.Add(Me.Label14)
        Me.GroupBox1.Controls.Add(Me.txtHeight)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.txtContact)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.txtbplace)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label15)
        Me.GroupBox1.Controls.Add(Me.txtweight)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.txtage)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.txtmname)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.txtemp_id)
        Me.GroupBox1.Controls.Add(Me.label)
        Me.GroupBox1.Controls.Add(Me.txtfname)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtlname)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Location = New System.Drawing.Point(8, 57)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(648, 527)
        Me.GroupBox1.TabIndex = 4
        Me.GroupBox1.TabStop = False
        '
        'cbpositon
        '
        Me.cbpositon.Enabled = False
        Me.cbpositon.Location = New System.Drawing.Point(540, 254)
        Me.cbpositon.Name = "cbpositon"
        Me.cbpositon.ReadOnly = True
        Me.cbpositon.Size = New System.Drawing.Size(90, 20)
        Me.cbpositon.TabIndex = 94
        Me.cbpositon.Text = "Guard"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.ForeColor = System.Drawing.Color.Red
        Me.Label40.Location = New System.Drawing.Point(93, 152)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(18, 24)
        Me.Label40.TabIndex = 93
        Me.Label40.Text = "*"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.ForeColor = System.Drawing.Color.Red
        Me.Label39.Location = New System.Drawing.Point(89, 122)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(18, 24)
        Me.Label39.TabIndex = 92
        Me.Label39.Text = "*"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.ForeColor = System.Drawing.Color.Red
        Me.Label38.Location = New System.Drawing.Point(69, 97)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(18, 24)
        Me.Label38.TabIndex = 91
        Me.Label38.Text = "*"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.ForeColor = System.Drawing.Color.Red
        Me.Label37.Location = New System.Drawing.Point(517, 71)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(18, 24)
        Me.Label37.TabIndex = 90
        Me.Label37.Text = "*"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.ForeColor = System.Drawing.Color.Red
        Me.Label36.Location = New System.Drawing.Point(277, 70)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(18, 24)
        Me.Label36.TabIndex = 89
        Me.Label36.Text = "*"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.rbdep0)
        Me.GroupBox2.Controls.Add(Me.rbdep4)
        Me.GroupBox2.Controls.Add(Me.rbdep3)
        Me.GroupBox2.Controls.Add(Me.rbdep2)
        Me.GroupBox2.Controls.Add(Me.rbdep1)
        Me.GroupBox2.Enabled = False
        Me.GroupBox2.Location = New System.Drawing.Point(28, 324)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(263, 60)
        Me.GroupBox2.TabIndex = 57
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Number of Qualified Dependent"
        '
        'rbdep0
        '
        Me.rbdep0.AutoSize = True
        Me.rbdep0.Location = New System.Drawing.Point(20, 30)
        Me.rbdep0.Name = "rbdep0"
        Me.rbdep0.Size = New System.Drawing.Size(31, 17)
        Me.rbdep0.TabIndex = 4
        Me.rbdep0.TabStop = True
        Me.rbdep0.Text = "0"
        Me.rbdep0.UseVisualStyleBackColor = True
        '
        'rbdep4
        '
        Me.rbdep4.AutoSize = True
        Me.rbdep4.Location = New System.Drawing.Point(198, 30)
        Me.rbdep4.Name = "rbdep4"
        Me.rbdep4.Size = New System.Drawing.Size(31, 17)
        Me.rbdep4.TabIndex = 3
        Me.rbdep4.TabStop = True
        Me.rbdep4.Text = "4"
        Me.rbdep4.UseVisualStyleBackColor = True
        '
        'rbdep3
        '
        Me.rbdep3.AutoSize = True
        Me.rbdep3.Location = New System.Drawing.Point(160, 30)
        Me.rbdep3.Name = "rbdep3"
        Me.rbdep3.Size = New System.Drawing.Size(31, 17)
        Me.rbdep3.TabIndex = 2
        Me.rbdep3.TabStop = True
        Me.rbdep3.Text = "3"
        Me.rbdep3.UseVisualStyleBackColor = True
        '
        'rbdep2
        '
        Me.rbdep2.AutoSize = True
        Me.rbdep2.Location = New System.Drawing.Point(114, 30)
        Me.rbdep2.Name = "rbdep2"
        Me.rbdep2.Size = New System.Drawing.Size(31, 17)
        Me.rbdep2.TabIndex = 1
        Me.rbdep2.TabStop = True
        Me.rbdep2.Text = "2"
        Me.rbdep2.UseVisualStyleBackColor = True
        '
        'rbdep1
        '
        Me.rbdep1.AutoSize = True
        Me.rbdep1.Location = New System.Drawing.Point(69, 30)
        Me.rbdep1.Name = "rbdep1"
        Me.rbdep1.Size = New System.Drawing.Size(31, 17)
        Me.rbdep1.TabIndex = 0
        Me.rbdep1.TabStop = True
        Me.rbdep1.Text = "1"
        Me.rbdep1.UseVisualStyleBackColor = True
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.ForeColor = System.Drawing.Color.Red
        Me.Label35.Location = New System.Drawing.Point(89, 70)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(18, 24)
        Me.Label35.TabIndex = 88
        Me.Label35.Text = "*"
        '
        'cbocivil
        '
        Me.cbocivil.FormattingEnabled = True
        Me.cbocivil.Items.AddRange(New Object() {"Zero Exemption", "Single", "Married"})
        Me.cbocivil.Location = New System.Drawing.Point(109, 288)
        Me.cbocivil.Name = "cbocivil"
        Me.cbocivil.Size = New System.Drawing.Size(116, 21)
        Me.cbocivil.TabIndex = 56
        Me.cbocivil.Text = "Single"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(42, 291)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(65, 13)
        Me.Label8.TabIndex = 53
        Me.Label8.Text = "Civil Status :"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(14, 387)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(629, 135)
        Me.TabControl1.TabIndex = 84
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Label27)
        Me.TabPage1.Controls.Add(Me.Label30)
        Me.TabPage1.Controls.Add(Me.txtcollegeYear)
        Me.TabPage1.Controls.Add(Me.txthschool_yeAR)
        Me.TabPage1.Controls.Add(Me.txtelem_year)
        Me.TabPage1.Controls.Add(Me.Label29)
        Me.TabPage1.Controls.Add(Me.txtcollege)
        Me.TabPage1.Controls.Add(Me.Label23)
        Me.TabPage1.Controls.Add(Me.txthschool)
        Me.TabPage1.Controls.Add(Me.Label22)
        Me.TabPage1.Controls.Add(Me.txtelem)
        Me.TabPage1.Controls.Add(Me.Label24)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(621, 109)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Educational Backround"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(362, 76)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(35, 13)
        Me.Label27.TabIndex = 9
        Me.Label27.Text = "Year :"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(362, 50)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(35, 13)
        Me.Label30.TabIndex = 8
        Me.Label30.Text = "Year :"
        '
        'txtcollegeYear
        '
        Me.txtcollegeYear.Location = New System.Drawing.Point(411, 73)
        Me.txtcollegeYear.Name = "txtcollegeYear"
        Me.txtcollegeYear.Size = New System.Drawing.Size(198, 20)
        Me.txtcollegeYear.TabIndex = 5
        '
        'txthschool_yeAR
        '
        Me.txthschool_yeAR.Location = New System.Drawing.Point(411, 47)
        Me.txthschool_yeAR.Name = "txthschool_yeAR"
        Me.txthschool_yeAR.Size = New System.Drawing.Size(198, 20)
        Me.txthschool_yeAR.TabIndex = 7
        '
        'txtelem_year
        '
        Me.txtelem_year.Location = New System.Drawing.Point(411, 16)
        Me.txtelem_year.Name = "txtelem_year"
        Me.txtelem_year.Size = New System.Drawing.Size(198, 20)
        Me.txtelem_year.TabIndex = 6
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(362, 19)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(35, 13)
        Me.Label29.TabIndex = 4
        Me.Label29.Text = "Year :"
        '
        'txtcollege
        '
        Me.txtcollege.Location = New System.Drawing.Point(111, 70)
        Me.txtcollege.Name = "txtcollege"
        Me.txtcollege.Size = New System.Drawing.Size(238, 20)
        Me.txtcollege.TabIndex = 1
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(48, 73)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(48, 13)
        Me.Label23.TabIndex = 0
        Me.Label23.Text = "College :"
        '
        'txthschool
        '
        Me.txthschool.Location = New System.Drawing.Point(111, 44)
        Me.txthschool.Name = "txthschool"
        Me.txthschool.Size = New System.Drawing.Size(238, 20)
        Me.txthschool.TabIndex = 1
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(27, 47)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(71, 13)
        Me.Label22.TabIndex = 0
        Me.Label22.Text = "High School :"
        '
        'txtelem
        '
        Me.txtelem.Location = New System.Drawing.Point(111, 18)
        Me.txtelem.Name = "txtelem"
        Me.txtelem.Size = New System.Drawing.Size(238, 20)
        Me.txtelem.TabIndex = 1
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(27, 21)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(65, 13)
        Me.Label24.TabIndex = 0
        Me.Label24.Text = "Elementary :"
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.Label45)
        Me.TabPage3.Controls.Add(Me.Label46)
        Me.TabPage3.Controls.Add(Me.txtPHIC)
        Me.TabPage3.Controls.Add(Me.Label34)
        Me.TabPage3.Controls.Add(Me.Label44)
        Me.TabPage3.Controls.Add(Me.txtHDMF)
        Me.TabPage3.Controls.Add(Me.Label43)
        Me.TabPage3.Controls.Add(Me.Label33)
        Me.TabPage3.Controls.Add(Me.txtpc)
        Me.TabPage3.Controls.Add(Me.Label42)
        Me.TabPage3.Controls.Add(Me.Label41)
        Me.TabPage3.Controls.Add(Me.Label16)
        Me.TabPage3.Controls.Add(Me.Label19)
        Me.TabPage3.Controls.Add(Me.txtothers)
        Me.TabPage3.Controls.Add(Me.txtnbic)
        Me.TabPage3.Controls.Add(Me.Label32)
        Me.TabPage3.Controls.Add(Me.txtgl)
        Me.TabPage3.Controls.Add(Me.Label31)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(621, 109)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "License Record"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.ForeColor = System.Drawing.Color.Red
        Me.Label45.Location = New System.Drawing.Point(458, 9)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(15, 18)
        Me.Label45.TabIndex = 104
        Me.Label45.Text = "*"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(389, 11)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(76, 13)
        Me.Label46.TabIndex = 103
        Me.Label46.Text = "Philhealth No :"
        '
        'txtPHIC
        '
        Me.txtPHIC.Location = New System.Drawing.Point(392, 30)
        Me.txtPHIC.Name = "txtPHIC"
        Me.txtPHIC.Size = New System.Drawing.Size(154, 20)
        Me.txtPHIC.TabIndex = 102
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.ForeColor = System.Drawing.Color.Red
        Me.Label34.Location = New System.Drawing.Point(450, 55)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(15, 18)
        Me.Label34.TabIndex = 101
        Me.Label34.Text = "*"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(389, 56)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(65, 13)
        Me.Label44.TabIndex = 100
        Me.Label44.Text = "Pagibig No :"
        '
        'txtHDMF
        '
        Me.txtHDMF.Location = New System.Drawing.Point(392, 75)
        Me.txtHDMF.Name = "txtHDMF"
        Me.txtHDMF.Size = New System.Drawing.Size(154, 20)
        Me.txtHDMF.TabIndex = 99
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.ForeColor = System.Drawing.Color.Red
        Me.Label43.Location = New System.Drawing.Point(114, 54)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(15, 18)
        Me.Label43.TabIndex = 98
        Me.Label43.Text = "*"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.ForeColor = System.Drawing.Color.Red
        Me.Label33.Location = New System.Drawing.Point(129, 12)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(15, 18)
        Me.Label33.TabIndex = 97
        Me.Label33.Text = "*"
        '
        'txtpc
        '
        Me.txtpc.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.txtpc.Location = New System.Drawing.Point(31, 75)
        Me.txtpc.Name = "txtpc"
        Me.txtpc.Size = New System.Drawing.Size(121, 20)
        Me.txtpc.TabIndex = 96
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.ForeColor = System.Drawing.Color.Red
        Me.Label42.Location = New System.Drawing.Point(247, 13)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(15, 18)
        Me.Label42.TabIndex = 95
        Me.Label42.Text = "*"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.ForeColor = System.Drawing.Color.Red
        Me.Label41.Location = New System.Drawing.Point(250, 56)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(15, 18)
        Me.Label41.TabIndex = 94
        Me.Label41.Text = "*"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(207, 59)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(51, 13)
        Me.Label16.TabIndex = 12
        Me.Label16.Text = "SSS No :"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(207, 17)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(45, 13)
        Me.Label19.TabIndex = 10
        Me.Label19.Text = "TIN No."
        '
        'txtothers
        '
        Me.txtothers.Location = New System.Drawing.Point(210, 78)
        Me.txtothers.Name = "txtothers"
        Me.txtothers.Size = New System.Drawing.Size(154, 20)
        Me.txtothers.TabIndex = 9
        '
        'txtnbic
        '
        Me.txtnbic.Location = New System.Drawing.Point(210, 33)
        Me.txtnbic.Name = "txtnbic"
        Me.txtnbic.Size = New System.Drawing.Size(154, 20)
        Me.txtnbic.TabIndex = 7
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(32, 61)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(82, 13)
        Me.Label32.TabIndex = 4
        Me.Label32.Text = "Expiration Date."
        '
        'txtgl
        '
        Me.txtgl.Location = New System.Drawing.Point(31, 33)
        Me.txtgl.Name = "txtgl"
        Me.txtgl.Size = New System.Drawing.Size(173, 20)
        Me.txtgl.TabIndex = 3
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(32, 17)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(97, 13)
        Me.Label31.TabIndex = 2
        Me.Label31.Text = "Guard Licence No."
        '
        'cboworkstat
        '
        Me.cboworkstat.Enabled = False
        Me.cboworkstat.FormattingEnabled = True
        Me.cboworkstat.Items.AddRange(New Object() {"Active"})
        Me.cboworkstat.Location = New System.Drawing.Point(341, 254)
        Me.cboworkstat.Name = "cboworkstat"
        Me.cboworkstat.Size = New System.Drawing.Size(86, 21)
        Me.cboworkstat.TabIndex = 39
        Me.cboworkstat.Text = "Active"
        '
        'dtpHiredate
        '
        Me.dtpHiredate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpHiredate.Location = New System.Drawing.Point(112, 254)
        Me.dtpHiredate.Name = "dtpHiredate"
        Me.dtpHiredate.Size = New System.Drawing.Size(105, 20)
        Me.dtpHiredate.TabIndex = 38
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(294, 233)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(88, 13)
        Me.Label21.TabIndex = 83
        Me.Label21.Text = "Current Address :"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(484, 258)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(50, 13)
        Me.Label25.TabIndex = 17
        Me.Label25.Text = "Position :"
        '
        'txtmotheradd
        '
        Me.txtmotheradd.Location = New System.Drawing.Point(392, 226)
        Me.txtmotheradd.Name = "txtmotheradd"
        Me.txtmotheradd.Size = New System.Drawing.Size(238, 20)
        Me.txtmotheradd.TabIndex = 82
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(292, 261)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(43, 13)
        Me.Label26.TabIndex = 15
        Me.Label26.Text = "Status :"
        '
        'txtfatheradd
        '
        Me.txtfatheradd.Location = New System.Drawing.Point(392, 200)
        Me.txtfatheradd.Name = "txtfatheradd"
        Me.txtfatheradd.Size = New System.Drawing.Size(238, 20)
        Me.txtfatheradd.TabIndex = 81
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(37, 261)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(64, 13)
        Me.Label28.TabIndex = 13
        Me.Label28.Text = "Hired Date :"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(294, 207)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(88, 13)
        Me.Label17.TabIndex = 80
        Me.Label17.Text = "Current Address :"
        '
        'txtsadd
        '
        Me.txtsadd.Enabled = False
        Me.txtsadd.Location = New System.Drawing.Point(392, 353)
        Me.txtsadd.Name = "txtsadd"
        Me.txtsadd.Size = New System.Drawing.Size(238, 20)
        Me.txtsadd.TabIndex = 79
        '
        'lblsadd
        '
        Me.lblsadd.AutoSize = True
        Me.lblsadd.Location = New System.Drawing.Point(333, 356)
        Me.lblsadd.Name = "lblsadd"
        Me.lblsadd.Size = New System.Drawing.Size(51, 13)
        Me.lblsadd.TabIndex = 78
        Me.lblsadd.Text = "Address :"
        '
        'txtmothername
        '
        Me.txtmothername.Location = New System.Drawing.Point(112, 228)
        Me.txtmothername.Name = "txtmothername"
        Me.txtmothername.Size = New System.Drawing.Size(152, 20)
        Me.txtmothername.TabIndex = 77
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(23, 235)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(84, 13)
        Me.Label20.TabIndex = 76
        Me.Label20.Text = "Mother's Name :"
        '
        'txtfathername
        '
        Me.txtfathername.Location = New System.Drawing.Point(112, 202)
        Me.txtfathername.Name = "txtfathername"
        Me.txtfathername.Size = New System.Drawing.Size(152, 20)
        Me.txtfathername.TabIndex = 75
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(23, 209)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(81, 13)
        Me.Label18.TabIndex = 74
        Me.Label18.Text = "Father's Name :"
        '
        'txtnamSpouse
        '
        Me.txtnamSpouse.Enabled = False
        Me.txtnamSpouse.Location = New System.Drawing.Point(392, 327)
        Me.txtnamSpouse.Name = "txtnamSpouse"
        Me.txtnamSpouse.Size = New System.Drawing.Size(152, 20)
        Me.txtnamSpouse.TabIndex = 73
        '
        'lblspouse
        '
        Me.lblspouse.AutoSize = True
        Me.lblspouse.Location = New System.Drawing.Point(304, 334)
        Me.lblspouse.Name = "lblspouse"
        Me.lblspouse.Size = New System.Drawing.Size(80, 13)
        Me.lblspouse.TabIndex = 72
        Me.lblspouse.Text = "Spouse Name :"
        '
        'rdofemale
        '
        Me.rdofemale.AutoSize = True
        Me.rdofemale.Location = New System.Drawing.Point(167, 97)
        Me.rdofemale.Name = "rdofemale"
        Me.rdofemale.Size = New System.Drawing.Size(59, 17)
        Me.rdofemale.TabIndex = 71
        Me.rdofemale.TabStop = True
        Me.rdofemale.Text = "Female"
        Me.rdofemale.UseVisualStyleBackColor = True
        '
        'rdomale
        '
        Me.rdomale.AutoSize = True
        Me.rdomale.Location = New System.Drawing.Point(112, 96)
        Me.rdomale.Name = "rdomale"
        Me.rdomale.Size = New System.Drawing.Size(48, 17)
        Me.rdomale.TabIndex = 70
        Me.rdomale.TabStop = True
        Me.rdomale.Text = "Male"
        Me.rdomale.UseVisualStyleBackColor = True
        '
        'dtpbdate
        '
        Me.dtpbdate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpbdate.Location = New System.Drawing.Point(343, 96)
        Me.dtpbdate.Name = "dtpbdate"
        Me.dtpbdate.Size = New System.Drawing.Size(121, 20)
        Me.dtpbdate.TabIndex = 69
        '
        'txtreligon
        '
        Me.txtreligon.Location = New System.Drawing.Point(320, 176)
        Me.txtreligon.Name = "txtreligon"
        Me.txtreligon.Size = New System.Drawing.Size(144, 20)
        Me.txtreligon.TabIndex = 68
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(265, 179)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(49, 13)
        Me.Label13.TabIndex = 65
        Me.Label13.Text = "Religon :"
        '
        'txtcitizen
        '
        Me.txtcitizen.Location = New System.Drawing.Point(112, 176)
        Me.txtcitizen.Name = "txtcitizen"
        Me.txtcitizen.Size = New System.Drawing.Size(110, 20)
        Me.txtcitizen.TabIndex = 67
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(25, 183)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(63, 13)
        Me.Label14.TabIndex = 66
        Me.Label14.Text = "Citizenship :"
        '
        'txtHeight
        '
        Me.txtHeight.Location = New System.Drawing.Point(348, 147)
        Me.txtHeight.Name = "txtHeight"
        Me.txtHeight.Size = New System.Drawing.Size(60, 20)
        Me.txtHeight.TabIndex = 64
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(270, 152)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(73, 13)
        Me.Label11.TabIndex = 61
        Me.Label11.Text = "Height ( cm ) :"
        '
        'txtContact
        '
        Me.txtContact.Location = New System.Drawing.Point(112, 150)
        Me.txtContact.Name = "txtContact"
        Me.txtContact.Size = New System.Drawing.Size(110, 20)
        Me.txtContact.TabIndex = 63
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(24, 157)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(70, 13)
        Me.Label12.TabIndex = 62
        Me.Label12.Text = "Contact No. :"
        '
        'txtbplace
        '
        Me.txtbplace.Location = New System.Drawing.Point(112, 122)
        Me.txtbplace.Name = "txtbplace"
        Me.txtbplace.Size = New System.Drawing.Size(352, 20)
        Me.txtbplace.TabIndex = 60
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(23, 129)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(51, 13)
        Me.Label9.TabIndex = 59
        Me.Label9.Text = "Address :"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(278, 100)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(57, 13)
        Me.Label7.TabIndex = 57
        Me.Label7.Text = "BirthDate :"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(23, 99)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(48, 13)
        Me.Label15.TabIndex = 58
        Me.Label15.Text = "Gender :"
        '
        'txtweight
        '
        Me.txtweight.Location = New System.Drawing.Point(505, 148)
        Me.txtweight.Name = "txtweight"
        Me.txtweight.Size = New System.Drawing.Size(75, 20)
        Me.txtweight.TabIndex = 55
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(422, 152)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(75, 13)
        Me.Label10.TabIndex = 54
        Me.Label10.Text = "Weight ( lbs ) :"
        '
        'txtage
        '
        Me.txtage.Enabled = False
        Me.txtage.Location = New System.Drawing.Point(538, 118)
        Me.txtage.Name = "txtage"
        Me.txtage.Size = New System.Drawing.Size(75, 20)
        Me.txtage.TabIndex = 52
        Me.txtage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(500, 125)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(32, 13)
        Me.Label5.TabIndex = 51
        Me.Label5.Text = "Age :"
        '
        'txtmname
        '
        Me.txtmname.Location = New System.Drawing.Point(538, 70)
        Me.txtmname.Name = "txtmname"
        Me.txtmname.Size = New System.Drawing.Size(75, 20)
        Me.txtmname.TabIndex = 50
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(542, 54)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(22, 13)
        Me.Label6.TabIndex = 49
        Me.Label6.Text = "M.I"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(23, 77)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(41, 13)
        Me.Label1.TabIndex = 48
        Me.Label1.Text = "Name :"
        '
        'txtemp_id
        '
        Me.txtemp_id.Enabled = False
        Me.txtemp_id.Location = New System.Drawing.Point(109, 27)
        Me.txtemp_id.Name = "txtemp_id"
        Me.txtemp_id.Size = New System.Drawing.Size(155, 20)
        Me.txtemp_id.TabIndex = 47
        '
        'label
        '
        Me.label.AutoSize = True
        Me.label.Location = New System.Drawing.Point(25, 30)
        Me.label.Name = "label"
        Me.label.Size = New System.Drawing.Size(76, 13)
        Me.label.TabIndex = 46
        Me.label.Text = "Employees Id :"
        '
        'txtfname
        '
        Me.txtfname.Location = New System.Drawing.Point(297, 70)
        Me.txtfname.Name = "txtfname"
        Me.txtfname.Size = New System.Drawing.Size(167, 20)
        Me.txtfname.TabIndex = 45
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(300, 54)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(57, 13)
        Me.Label3.TabIndex = 42
        Me.Label3.Text = "First Name"
        '
        'txtlname
        '
        Me.txtlname.Location = New System.Drawing.Point(109, 69)
        Me.txtlname.Name = "txtlname"
        Me.txtlname.Size = New System.Drawing.Size(155, 20)
        Me.txtlname.TabIndex = 44
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(113, 54)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(58, 13)
        Me.Label2.TabIndex = 43
        Me.Label2.Text = "Last Name"
        '
        'btnadd
        '
        Me.btnadd.Location = New System.Drawing.Point(505, 585)
        Me.btnadd.Name = "btnadd"
        Me.btnadd.Size = New System.Drawing.Size(147, 32)
        Me.btnadd.TabIndex = 40
        Me.btnadd.Text = "Save"
        Me.btnadd.UseVisualStyleBackColor = True
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(368, 585)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(131, 32)
        Me.Button1.TabIndex = 42
        Me.Button1.Text = "Take Picture"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.txtwedate3)
        Me.TabPage2.Controls.Add(Me.txtwedate2)
        Me.TabPage2.Controls.Add(Me.txtwedate1)
        Me.TabPage2.Controls.Add(Me.Label50)
        Me.TabPage2.Controls.Add(Me.Label48)
        Me.TabPage2.Controls.Add(Me.Label47)
        Me.TabPage2.Controls.Add(Me.txtwepos3)
        Me.TabPage2.Controls.Add(Me.txtwepos2)
        Me.TabPage2.Controls.Add(Me.txtwepos1)
        Me.TabPage2.Controls.Add(Me.txtwecom3)
        Me.TabPage2.Controls.Add(Me.txtwecom2)
        Me.TabPage2.Controls.Add(Me.txtwecom1)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(621, 109)
        Me.TabPage2.TabIndex = 3
        Me.TabPage2.Text = "Work Experience"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'txtwecom1
        '
        Me.txtwecom1.Location = New System.Drawing.Point(17, 30)
        Me.txtwecom1.Name = "txtwecom1"
        Me.txtwecom1.Size = New System.Drawing.Size(289, 20)
        Me.txtwecom1.TabIndex = 95
        '
        'txtwecom2
        '
        Me.txtwecom2.Location = New System.Drawing.Point(17, 55)
        Me.txtwecom2.Name = "txtwecom2"
        Me.txtwecom2.Size = New System.Drawing.Size(289, 20)
        Me.txtwecom2.TabIndex = 101
        '
        'txtwecom3
        '
        Me.txtwecom3.Location = New System.Drawing.Point(17, 81)
        Me.txtwecom3.Name = "txtwecom3"
        Me.txtwecom3.Size = New System.Drawing.Size(289, 20)
        Me.txtwecom3.TabIndex = 102
        '
        'txtwepos1
        '
        Me.txtwepos1.Location = New System.Drawing.Point(313, 29)
        Me.txtwepos1.Name = "txtwepos1"
        Me.txtwepos1.Size = New System.Drawing.Size(186, 20)
        Me.txtwepos1.TabIndex = 103
        '
        'txtwepos2
        '
        Me.txtwepos2.Location = New System.Drawing.Point(313, 55)
        Me.txtwepos2.Name = "txtwepos2"
        Me.txtwepos2.Size = New System.Drawing.Size(186, 20)
        Me.txtwepos2.TabIndex = 104
        '
        'txtwepos3
        '
        Me.txtwepos3.Location = New System.Drawing.Point(313, 81)
        Me.txtwepos3.Name = "txtwepos3"
        Me.txtwepos3.Size = New System.Drawing.Size(186, 20)
        Me.txtwepos3.TabIndex = 105
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(21, 11)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(51, 13)
        Me.Label47.TabIndex = 95
        Me.Label47.Text = "Company"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(508, 10)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(75, 13)
        Me.Label48.TabIndex = 106
        Me.Label48.Text = "Inclusive Date"
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(316, 11)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(44, 13)
        Me.Label50.TabIndex = 108
        Me.Label50.Text = "Position"
        '
        'txtwedate1
        '
        Me.txtwedate1.Location = New System.Drawing.Point(505, 29)
        Me.txtwedate1.Name = "txtwedate1"
        Me.txtwedate1.Size = New System.Drawing.Size(107, 20)
        Me.txtwedate1.TabIndex = 95
        '
        'txtwedate2
        '
        Me.txtwedate2.Location = New System.Drawing.Point(505, 55)
        Me.txtwedate2.Name = "txtwedate2"
        Me.txtwedate2.Size = New System.Drawing.Size(107, 20)
        Me.txtwedate2.TabIndex = 109
        '
        'txtwedate3
        '
        Me.txtwedate3.Location = New System.Drawing.Point(505, 81)
        Me.txtwedate3.Name = "txtwedate3"
        Me.txtwedate3.Size = New System.Drawing.Size(107, 20)
        Me.txtwedate3.TabIndex = 110
        '
        'newemployee
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(663, 619)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.btnadd)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "newemployee"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Panel1.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtemp_id As System.Windows.Forms.TextBox
    Friend WithEvents label As System.Windows.Forms.Label
    Friend WithEvents txtfname As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtlname As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cbocivil As System.Windows.Forms.ComboBox
    Friend WithEvents txtweight As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtage As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtmname As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cboworkstat As System.Windows.Forms.ComboBox
    Friend WithEvents dtpHiredate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents txtmotheradd As System.Windows.Forms.TextBox
    Friend WithEvents txtfatheradd As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents txtsadd As System.Windows.Forms.TextBox
    Friend WithEvents lblsadd As System.Windows.Forms.Label
    Friend WithEvents txtmothername As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents txtfathername As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents txtnamSpouse As System.Windows.Forms.TextBox
    Friend WithEvents lblspouse As System.Windows.Forms.Label
    Friend WithEvents rdofemale As System.Windows.Forms.RadioButton
    Friend WithEvents rdomale As System.Windows.Forms.RadioButton
    Friend WithEvents dtpbdate As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtreligon As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtcitizen As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents txtHeight As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtContact As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents txtbplace As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents txtcollegeYear As System.Windows.Forms.MaskedTextBox
    Friend WithEvents txthschool_yeAR As System.Windows.Forms.MaskedTextBox
    Friend WithEvents txtelem_year As System.Windows.Forms.MaskedTextBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents txtcollege As System.Windows.Forms.MaskedTextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents txthschool As System.Windows.Forms.MaskedTextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents txtelem As System.Windows.Forms.MaskedTextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents btnadd As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents rbdep4 As System.Windows.Forms.RadioButton
    Friend WithEvents rbdep3 As System.Windows.Forms.RadioButton
    Friend WithEvents rbdep2 As System.Windows.Forms.RadioButton
    Friend WithEvents rbdep1 As System.Windows.Forms.RadioButton
    Friend WithEvents rbdep0 As System.Windows.Forms.RadioButton
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents txtgl As System.Windows.Forms.MaskedTextBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents txtothers As System.Windows.Forms.MaskedTextBox
    Friend WithEvents txtnbic As System.Windows.Forms.MaskedTextBox
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents txtpc As System.Windows.Forms.DateTimePicker
    Friend WithEvents cbpositon As System.Windows.Forms.TextBox
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents txtPHIC As System.Windows.Forms.MaskedTextBox
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents txtHDMF As System.Windows.Forms.MaskedTextBox
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents txtwepos2 As System.Windows.Forms.TextBox
    Friend WithEvents txtwepos1 As System.Windows.Forms.TextBox
    Friend WithEvents txtwecom3 As System.Windows.Forms.TextBox
    Friend WithEvents txtwecom2 As System.Windows.Forms.TextBox
    Friend WithEvents txtwecom1 As System.Windows.Forms.TextBox
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents txtwepos3 As System.Windows.Forms.TextBox
    Friend WithEvents txtwedate3 As System.Windows.Forms.TextBox
    Friend WithEvents txtwedate2 As System.Windows.Forms.TextBox
    Friend WithEvents txtwedate1 As System.Windows.Forms.TextBox
End Class

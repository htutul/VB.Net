﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace Ichiban
{
    [Microsoft.VisualBasic.CompilerServices.DesignerGenerated()]
    public partial class assign : Form
    {

        // Form overrides dispose to clean up the component list.
        [DebuggerNonUserCode()]
        protected override void Dispose(bool disposing)
        {
            try
            {
                if (disposing && components is not null)
                {
                    components.Dispose();
                }
            }
            finally
            {
                base.Dispose(disposing);
            }
        }

        // Required by the Windows Form Designer
        private System.ComponentModel.IContainer components;

        // NOTE: The following procedure is required by the Windows Form Designer
        // It can be modified using the Windows Form Designer.  
        // Do not modify it using the code editor.
        [DebuggerStepThrough()]
        private void InitializeComponent()
        {
            GroupBox1 = new GroupBox();
            DataGridView3 = new DataGridView();
            DataGridView3.CellClick += new DataGridViewCellEventHandler(DataGridView3_CellClick);
            Panel1 = new Panel();
            Label4 = new Label();
            gbclientinfo = new GroupBox();
            lblend = new Label();
            lblstart = new Label();
            ID = new Label();
            lblrate = new Label();
            lblAddress = new Label();
            lblclientName = new Label();
            Label1 = new Label();
            LBLCLIENTID = new Label();
            Label25 = new Label();
            Label24 = new Label();
            Label23 = new Label();
            GroupBox2 = new GroupBox();
            Label12 = new Label();
            Label2 = new Label();
            LBLEMPSTATUS = new Label();
            LBLAGE = new Label();
            LBLFULLNAME = new Label();
            Label7 = new Label();
            LBLEMPID = new Label();
            Label9 = new Label();
            Label11 = new Label();
            BTNASSIGN = new Button();
            BTNASSIGN.Click += new EventHandler(BTNASSIGN_Click);
            GroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)DataGridView3).BeginInit();
            Panel1.SuspendLayout();
            gbclientinfo.SuspendLayout();
            GroupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // GroupBox1
            // 
            GroupBox1.Controls.Add(DataGridView3);
            GroupBox1.Location = new Point(12, 57);
            GroupBox1.Name = "GroupBox1";
            GroupBox1.Size = new Size(590, 225);
            GroupBox1.TabIndex = 0;
            GroupBox1.TabStop = false;
            GroupBox1.Text = "List of Available Guard(s)";
            // 
            // DataGridView3
            // 
            DataGridView3.AllowUserToAddRows = false;
            DataGridView3.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DataGridView3.Location = new Point(19, 19);
            DataGridView3.Name = "DataGridView3";
            DataGridView3.RowHeadersVisible = false;
            DataGridView3.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            DataGridView3.Size = new Size(565, 190);
            DataGridView3.TabIndex = 56;
            // 
            // Panel1
            // 
            Panel1.BackColor = SystemColors.ActiveCaption;
            Panel1.Controls.Add(Label4);
            Panel1.Dock = DockStyle.Top;
            Panel1.Location = new Point(0, 0);
            Panel1.Name = "Panel1";
            Panel1.Size = new Size(614, 51);
            Panel1.TabIndex = 3;
            // 
            // Label4
            // 
            Label4.Font = new Font("Microsoft Sans Serif", 18.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label4.ForeColor = SystemColors.HighlightText;
            Label4.Location = new Point(3, 9);
            Label4.Name = "Label4";
            Label4.Size = new Size(348, 33);
            Label4.TabIndex = 1;
            Label4.Text = "Assigning of Guard to Client";
            // 
            // gbclientinfo
            // 
            gbclientinfo.Controls.Add(lblend);
            gbclientinfo.Controls.Add(lblstart);
            gbclientinfo.Controls.Add(ID);
            gbclientinfo.Controls.Add(lblrate);
            gbclientinfo.Controls.Add(lblAddress);
            gbclientinfo.Controls.Add(lblclientName);
            gbclientinfo.Controls.Add(Label1);
            gbclientinfo.Controls.Add(LBLCLIENTID);
            gbclientinfo.Controls.Add(Label25);
            gbclientinfo.Controls.Add(Label24);
            gbclientinfo.Controls.Add(Label23);
            gbclientinfo.Font = new Font("Microsoft Sans Serif", 12.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            gbclientinfo.Location = new Point(12, 288);
            gbclientinfo.Name = "gbclientinfo";
            gbclientinfo.Size = new Size(292, 209);
            gbclientinfo.TabIndex = 16;
            gbclientinfo.TabStop = false;
            gbclientinfo.Text = "Client Inforamtion";
            // 
            // lblend
            // 
            lblend.AutoSize = true;
            lblend.Location = new Point(137, 22);
            lblend.Name = "lblend";
            lblend.Size = new Size(57, 20);
            lblend.TabIndex = 30;
            lblend.Text = "Label3";
            lblend.Visible = false;
            // 
            // lblstart
            // 
            lblstart.AutoSize = true;
            lblstart.Location = new Point(53, 22);
            lblstart.Name = "lblstart";
            lblstart.Size = new Size(57, 20);
            lblstart.TabIndex = 29;
            lblstart.Text = "Label3";
            lblstart.Visible = false;
            // 
            // ID
            // 
            ID.AutoSize = true;
            ID.Location = new Point(6, 22);
            ID.Name = "ID";
            ID.Size = new Size(26, 20);
            ID.TabIndex = 28;
            ID.Text = "ID";
            ID.Visible = false;
            // 
            // lblrate
            // 
            lblrate.AutoSize = true;
            lblrate.Font = new Font("Microsoft Sans Serif", 12.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblrate.Location = new Point(127, 132);
            lblrate.Name = "lblrate";
            lblrate.Size = new Size(103, 20);
            lblrate.TabIndex = 26;
            lblrate.Text = "Client Name :";
            // 
            // lblAddress
            // 
            lblAddress.AutoSize = true;
            lblAddress.Font = new Font("Microsoft Sans Serif", 12.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblAddress.Location = new Point(127, 98);
            lblAddress.Name = "lblAddress";
            lblAddress.Size = new Size(103, 20);
            lblAddress.TabIndex = 25;
            lblAddress.Text = "Client Name :";
            // 
            // lblclientName
            // 
            lblclientName.AutoSize = true;
            lblclientName.Font = new Font("Microsoft Sans Serif", 12.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblclientName.Location = new Point(127, 67);
            lblclientName.Name = "lblclientName";
            lblclientName.Size = new Size(103, 20);
            lblclientName.TabIndex = 24;
            lblclientName.Text = "Client Name :";
            // 
            // Label1
            // 
            Label1.AutoSize = true;
            Label1.Font = new Font("Microsoft Sans Serif", 12.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label1.Location = new Point(37, 42);
            Label1.Name = "Label1";
            Label1.Size = new Size(78, 20);
            Label1.TabIndex = 23;
            Label1.Text = "Client ID :";
            // 
            // LBLCLIENTID
            // 
            LBLCLIENTID.AutoSize = true;
            LBLCLIENTID.Font = new Font("Microsoft Sans Serif", 12.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            LBLCLIENTID.Location = new Point(127, 42);
            LBLCLIENTID.Name = "LBLCLIENTID";
            LBLCLIENTID.Size = new Size(26, 20);
            LBLCLIENTID.TabIndex = 22;
            LBLCLIENTID.Text = "ID";
            // 
            // Label25
            // 
            Label25.AutoSize = true;
            Label25.Font = new Font("Microsoft Sans Serif", 12.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label25.Location = new Point(6, 132);
            Label25.Name = "Label25";
            Label25.Size = new Size(115, 40);
            Label25.TabIndex = 18;
            Label25.Text = "Contract Price" + '\r' + '\n' + "(monthly basis)";
            // 
            // Label24
            // 
            Label24.AutoSize = true;
            Label24.Font = new Font("Microsoft Sans Serif", 12.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label24.Location = new Point(5, 98);
            Label24.Name = "Label24";
            Label24.Size = new Size(120, 20);
            Label24.TabIndex = 16;
            Label24.Text = "Client Address :";
            // 
            // Label23
            // 
            Label23.AutoSize = true;
            Label23.Font = new Font("Microsoft Sans Serif", 12.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label23.Location = new Point(12, 67);
            Label23.Name = "Label23";
            Label23.Size = new Size(103, 20);
            Label23.TabIndex = 14;
            Label23.Text = "Client Name :";
            // 
            // GroupBox2
            // 
            GroupBox2.Controls.Add(Label12);
            GroupBox2.Controls.Add(Label2);
            GroupBox2.Controls.Add(LBLEMPSTATUS);
            GroupBox2.Controls.Add(LBLAGE);
            GroupBox2.Controls.Add(LBLFULLNAME);
            GroupBox2.Controls.Add(Label7);
            GroupBox2.Controls.Add(LBLEMPID);
            GroupBox2.Controls.Add(Label9);
            GroupBox2.Controls.Add(Label11);
            GroupBox2.Font = new Font("Microsoft Sans Serif", 12.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            GroupBox2.Location = new Point(310, 288);
            GroupBox2.Name = "GroupBox2";
            GroupBox2.Size = new Size(292, 171);
            GroupBox2.TabIndex = 29;
            GroupBox2.TabStop = false;
            GroupBox2.Text = "Guard Information";
            // 
            // Label12
            // 
            Label12.AutoSize = true;
            Label12.Font = new Font("Microsoft Sans Serif", 12.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label12.Location = new Point(63, 89);
            Label12.Name = "Label12";
            Label12.Size = new Size(46, 20);
            Label12.TabIndex = 29;
            Label12.Text = "Age :";
            // 
            // Label2
            // 
            Label2.AutoSize = true;
            Label2.Location = new Point(6, 22);
            Label2.Name = "Label2";
            Label2.Size = new Size(26, 20);
            Label2.TabIndex = 28;
            Label2.Text = "ID";
            Label2.Visible = false;
            // 
            // LBLEMPSTATUS
            // 
            LBLEMPSTATUS.AutoSize = true;
            LBLEMPSTATUS.Font = new Font("Microsoft Sans Serif", 12.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            LBLEMPSTATUS.Location = new Point(119, 119);
            LBLEMPSTATUS.Name = "LBLEMPSTATUS";
            LBLEMPSTATUS.Size = new Size(103, 20);
            LBLEMPSTATUS.TabIndex = 26;
            LBLEMPSTATUS.Text = "Client Name :";
            // 
            // LBLAGE
            // 
            LBLAGE.AutoSize = true;
            LBLAGE.Font = new Font("Microsoft Sans Serif", 12.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            LBLAGE.Location = new Point(115, 89);
            LBLAGE.Name = "LBLAGE";
            LBLAGE.Size = new Size(103, 20);
            LBLAGE.TabIndex = 25;
            LBLAGE.Text = "Client Name :";
            // 
            // LBLFULLNAME
            // 
            LBLFULLNAME.AutoSize = true;
            LBLFULLNAME.Font = new Font("Microsoft Sans Serif", 12.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            LBLFULLNAME.Location = new Point(115, 67);
            LBLFULLNAME.Name = "LBLFULLNAME";
            LBLFULLNAME.Size = new Size(103, 20);
            LBLFULLNAME.TabIndex = 24;
            LBLFULLNAME.Text = "Client Name :";
            // 
            // Label7
            // 
            Label7.AutoSize = true;
            Label7.Font = new Font("Microsoft Sans Serif", 12.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label7.Location = new Point(5, 42);
            Label7.Name = "Label7";
            Label7.Size = new Size(108, 20);
            Label7.TabIndex = 23;
            Label7.Text = "Employee ID :";
            // 
            // LBLEMPID
            // 
            LBLEMPID.AutoSize = true;
            LBLEMPID.Font = new Font("Microsoft Sans Serif", 12.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            LBLEMPID.Location = new Point(115, 42);
            LBLEMPID.Name = "LBLEMPID";
            LBLEMPID.Size = new Size(26, 20);
            LBLEMPID.TabIndex = 22;
            LBLEMPID.Text = "ID";
            // 
            // Label9
            // 
            Label9.AutoSize = true;
            Label9.Font = new Font("Microsoft Sans Serif", 12.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label9.Location = new Point(8, 119);
            Label9.Name = "Label9";
            Label9.Size = new Size(105, 20);
            Label9.TabIndex = 18;
            Label9.Text = "Work Status :";
            // 
            // Label11
            // 
            Label11.AutoSize = true;
            Label11.Font = new Font("Microsoft Sans Serif", 12.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label11.Location = new Point(25, 67);
            Label11.Name = "Label11";
            Label11.Size = new Size(88, 20);
            Label11.TabIndex = 14;
            Label11.Text = "Full Name :";
            // 
            // BTNASSIGN
            // 
            BTNASSIGN.Location = new Point(489, 468);
            BTNASSIGN.Name = "BTNASSIGN";
            BTNASSIGN.Size = new Size(113, 29);
            BTNASSIGN.TabIndex = 30;
            BTNASSIGN.Text = "Assign Guard";
            BTNASSIGN.UseVisualStyleBackColor = true;
            // 
            // assign
            // 
            AutoScaleDimensions = new SizeF(6.0f, 13.0f);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(614, 503);
            Controls.Add(BTNASSIGN);
            Controls.Add(GroupBox2);
            Controls.Add(gbclientinfo);
            Controls.Add(Panel1);
            Controls.Add(GroupBox1);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Name = "assign";
            StartPosition = FormStartPosition.CenterScreen;
            GroupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)DataGridView3).EndInit();
            Panel1.ResumeLayout(false);
            gbclientinfo.ResumeLayout(false);
            gbclientinfo.PerformLayout();
            GroupBox2.ResumeLayout(false);
            GroupBox2.PerformLayout();
            Load += new EventHandler(assign_Load);
            ResumeLayout(false);

        }
        internal GroupBox GroupBox1;
        internal DataGridView DataGridView3;
        internal Panel Panel1;
        internal Label Label4;
        internal GroupBox gbclientinfo;
        internal Label LBLCLIENTID;
        internal Label Label25;
        internal Label Label24;
        internal Label Label23;
        internal Label Label1;
        internal Label lblrate;
        internal Label lblAddress;
        internal Label lblclientName;
        internal Label ID;
        internal GroupBox GroupBox2;
        internal Label Label12;
        internal Label Label2;
        internal Label LBLEMPSTATUS;
        internal Label LBLAGE;
        internal Label LBLFULLNAME;
        internal Label Label7;
        internal Label LBLEMPID;
        internal Label Label9;
        internal Label Label11;
        internal Button BTNASSIGN;
        internal Label lblend;
        internal Label lblstart;
    }
}
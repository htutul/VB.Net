﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace Ichiban
{
    [Microsoft.VisualBasic.CompilerServices.DesignerGenerated()]
    public partial class frmIndividualprofile : Form
    {

        // Form overrides dispose to clean up the component list.
        [DebuggerNonUserCode()]
        protected override void Dispose(bool disposing)
        {
            try
            {
                if (disposing && components is not null)
                {
                    components.Dispose();
                }
            }
            finally
            {
                base.Dispose(disposing);
            }
        }

        // Required by the Windows Form Designer
        private System.ComponentModel.IContainer components;

        // NOTE: The following procedure is required by the Windows Form Designer
        // It can be modified using the Windows Form Designer.  
        // Do not modify it using the code editor.
        [DebuggerStepThrough()]
        private void InitializeComponent()
        {
            Button6 = new Button();
            Button6.Click += new EventHandler(Button6_Click);
            Button4 = new Button();
            Button4.Click += new EventHandler(Button4_Click);
            PictureBox2 = new PictureBox();
            TextBox2 = new TextBox();
            OpenFileDialog1 = new OpenFileDialog();
            Label1 = new Label();
            TabControl1 = new TabControl();
            TabPage1 = new TabPage();
            Label39 = new Label();
            Label38 = new Label();
            Label11 = new Label();
            Label10 = new Label();
            Label9 = new Label();
            Label36 = new Label();
            Label37 = new Label();
            Button1 = new Button();
            Button1.Click += new EventHandler(Button1_Click);
            Label8 = new Label();
            Label2 = new Label();
            txtmotheradd = new TextBox();
            txtfatheradd = new TextBox();
            txtsadd = new TextBox();
            Label19 = new Label();
            txtmothername = new TextBox();
            Label20 = new Label();
            txtfathername = new TextBox();
            Label18 = new Label();
            txtnamSpouse = new TextBox();
            Label16 = new Label();
            rdofemale = new RadioButton();
            rdomale = new RadioButton();
            dtpbdate = new DateTimePicker();
            dtpbdate.TextChanged += new EventHandler(dtpbdate_TextChanged);
            dtpbdate.ValueChanged += new EventHandler(dtpbdate_ValueChanged);
            txtreligon = new TextBox();
            Label13 = new Label();
            txtcitizen = new TextBox();
            Label14 = new Label();
            txtHeight = new TextBox();
            txtHeight.TextChanged += new EventHandler(txtHeight_TextChanged);
            txtContact = new TextBox();
            Label12 = new Label();
            txtbplace = new TextBox();
            Label7 = new Label();
            Label15 = new Label();
            txtweight = new TextBox();
            txtweight.TextChanged += new EventHandler(txtweight_TextChanged);
            txtage = new TextBox();
            Label5 = new Label();
            txtmname = new TextBox();
            txtmname.TextChanged += new EventHandler(txtmname_TextChanged);
            Label6 = new Label();
            txtfname = new TextBox();
            Label3 = new Label();
            txtlname = new TextBox();
            Label4 = new Label();
            txtemp_id = new TextBox();
            label = new Label();
            Label35 = new Label();
            TabPage2 = new TabPage();
            cbpositon = new TextBox();
            GroupBox3 = new GroupBox();
            Label46 = new Label();
            txtPHIC = new MaskedTextBox();
            Label44 = new Label();
            txtHDMF = new MaskedTextBox();
            Label31 = new Label();
            txtgl = new MaskedTextBox();
            Label32 = new Label();
            txtpc = new MaskedTextBox();
            Label33 = new Label();
            txtothers = new MaskedTextBox();
            txtnbic = new MaskedTextBox();
            Label34 = new Label();
            GroupBox1 = new GroupBox();
            txtcollege = new MaskedTextBox();
            Label24 = new Label();
            txtelem = new MaskedTextBox();
            Label22 = new Label();
            txthschool = new MaskedTextBox();
            Label23 = new Label();
            Label29 = new Label();
            txtelem_year = new MaskedTextBox();
            Label27 = new Label();
            txthschool_yeAR = new MaskedTextBox();
            Label30 = new Label();
            txtcollegeYear = new MaskedTextBox();
            Button2 = new Button();
            Button2.Click += new EventHandler(Button2_Click);
            GroupBox2 = new GroupBox();
            rbdep0 = new RadioButton();
            rbdep4 = new RadioButton();
            rbdep3 = new RadioButton();
            rbdep2 = new RadioButton();
            rbdep1 = new RadioButton();
            cbocivil = new ComboBox();
            Label17 = new Label();
            cboworkstat = new ComboBox();
            dtpHiredate = new DateTimePicker();
            Label25 = new Label();
            Label26 = new Label();
            Label28 = new Label();
            Label21 = new Label();
            TabPage3 = new TabPage();
            txtwedate3 = new TextBox();
            txtwedate2 = new TextBox();
            txtwedate1 = new TextBox();
            Label50 = new Label();
            Label48 = new Label();
            Label47 = new Label();
            txtwepos3 = new TextBox();
            txtwepos2 = new TextBox();
            txtwepos1 = new TextBox();
            txtwecom3 = new TextBox();
            txtwecom2 = new TextBox();
            txtwecom1 = new TextBox();
            Button3 = new Button();
            Label40 = new Label();
            ((System.ComponentModel.ISupportInitialize)PictureBox2).BeginInit();
            TabControl1.SuspendLayout();
            TabPage1.SuspendLayout();
            TabPage2.SuspendLayout();
            GroupBox3.SuspendLayout();
            GroupBox1.SuspendLayout();
            GroupBox2.SuspendLayout();
            TabPage3.SuspendLayout();
            SuspendLayout();
            // 
            // Button6
            // 
            Button6.Location = new Point(150, 213);
            Button6.Name = "Button6";
            Button6.Size = new Size(82, 23);
            Button6.TabIndex = 47;
            Button6.Text = "Save";
            Button6.UseVisualStyleBackColor = true;
            // 
            // Button4
            // 
            Button4.Location = new Point(62, 213);
            Button4.Name = "Button4";
            Button4.Size = new Size(82, 23);
            Button4.TabIndex = 46;
            Button4.Text = "Upload";
            Button4.UseVisualStyleBackColor = true;
            // 
            // PictureBox2
            // 
            PictureBox2.BorderStyle = BorderStyle.FixedSingle;
            PictureBox2.Location = new Point(15, 12);
            PictureBox2.Name = "PictureBox2";
            PictureBox2.Size = new Size(217, 188);
            PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            PictureBox2.TabIndex = 45;
            PictureBox2.TabStop = false;
            // 
            // TextBox2
            // 
            TextBox2.Location = new Point(32, 115);
            TextBox2.Name = "TextBox2";
            TextBox2.Size = new Size(138, 20);
            TextBox2.TabIndex = 48;
            // 
            // OpenFileDialog1
            // 
            OpenFileDialog1.FileName = "OpenFileDialog1";
            // 
            // Label1
            // 
            Label1.AutoSize = true;
            Label1.Location = new Point(32, 96);
            Label1.Name = "Label1";
            Label1.Size = new Size(39, 13);
            Label1.TabIndex = 50;
            Label1.Text = "Label1";
            // 
            // TabControl1
            // 
            TabControl1.Controls.Add(TabPage1);
            TabControl1.Controls.Add(TabPage2);
            TabControl1.Controls.Add(TabPage3);
            TabControl1.Location = new Point(12, 12);
            TabControl1.Name = "TabControl1";
            TabControl1.SelectedIndex = 0;
            TabControl1.Size = new Size(712, 508);
            TabControl1.TabIndex = 51;
            // 
            // TabPage1
            // 
            TabPage1.Controls.Add(Label40);
            TabPage1.Controls.Add(PictureBox2);
            TabPage1.Controls.Add(Label39);
            TabPage1.Controls.Add(Label38);
            TabPage1.Controls.Add(Label11);
            TabPage1.Controls.Add(Label10);
            TabPage1.Controls.Add(Label9);
            TabPage1.Controls.Add(Label36);
            TabPage1.Controls.Add(Label37);
            TabPage1.Controls.Add(Button1);
            TabPage1.Controls.Add(Label8);
            TabPage1.Controls.Add(Label2);
            TabPage1.Controls.Add(txtmotheradd);
            TabPage1.Controls.Add(txtfatheradd);
            TabPage1.Controls.Add(txtsadd);
            TabPage1.Controls.Add(Label19);
            TabPage1.Controls.Add(txtmothername);
            TabPage1.Controls.Add(Label20);
            TabPage1.Controls.Add(txtfathername);
            TabPage1.Controls.Add(Label18);
            TabPage1.Controls.Add(txtnamSpouse);
            TabPage1.Controls.Add(Label16);
            TabPage1.Controls.Add(rdofemale);
            TabPage1.Controls.Add(rdomale);
            TabPage1.Controls.Add(dtpbdate);
            TabPage1.Controls.Add(txtreligon);
            TabPage1.Controls.Add(Label13);
            TabPage1.Controls.Add(txtcitizen);
            TabPage1.Controls.Add(Label14);
            TabPage1.Controls.Add(txtHeight);
            TabPage1.Controls.Add(txtContact);
            TabPage1.Controls.Add(Label12);
            TabPage1.Controls.Add(txtbplace);
            TabPage1.Controls.Add(Label7);
            TabPage1.Controls.Add(Label15);
            TabPage1.Controls.Add(txtweight);
            TabPage1.Controls.Add(txtage);
            TabPage1.Controls.Add(Label5);
            TabPage1.Controls.Add(txtmname);
            TabPage1.Controls.Add(Label6);
            TabPage1.Controls.Add(txtfname);
            TabPage1.Controls.Add(Label3);
            TabPage1.Controls.Add(txtlname);
            TabPage1.Controls.Add(Label4);
            TabPage1.Controls.Add(txtemp_id);
            TabPage1.Controls.Add(label);
            TabPage1.Controls.Add(Button4);
            TabPage1.Controls.Add(Button6);
            TabPage1.Controls.Add(Label35);
            TabPage1.Location = new Point(4, 22);
            TabPage1.Name = "TabPage1";
            TabPage1.Padding = new Padding(3);
            TabPage1.Size = new Size(704, 482);
            TabPage1.TabIndex = 0;
            TabPage1.Text = "Personal Info";
            TabPage1.UseVisualStyleBackColor = true;
            // 
            // Label39
            // 
            Label39.AutoSize = true;
            Label39.Font = new Font("Microsoft Sans Serif", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label39.ForeColor = Color.Red;
            Label39.Location = new Point(302, 233);
            Label39.Name = "Label39";
            Label39.Size = new Size(18, 24);
            Label39.TabIndex = 141;
            Label39.Text = "*";
            // 
            // Label38
            // 
            Label38.AutoSize = true;
            Label38.Font = new Font("Microsoft Sans Serif", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label38.ForeColor = Color.Red;
            Label38.Location = new Point(307, 132);
            Label38.Name = "Label38";
            Label38.Size = new Size(18, 24);
            Label38.TabIndex = 140;
            Label38.Text = "*";
            // 
            // Label11
            // 
            Label11.AutoSize = true;
            Label11.Font = new Font("Microsoft Sans Serif", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label11.ForeColor = Color.Red;
            Label11.Location = new Point(305, 106);
            Label11.Name = "Label11";
            Label11.Size = new Size(18, 24);
            Label11.TabIndex = 139;
            Label11.Text = "*";
            // 
            // Label10
            // 
            Label10.AutoSize = true;
            Label10.Font = new Font("Microsoft Sans Serif", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label10.ForeColor = Color.Red;
            Label10.Location = new Point(305, 82);
            Label10.Name = "Label10";
            Label10.Size = new Size(18, 24);
            Label10.TabIndex = 138;
            Label10.Text = "*";
            // 
            // Label9
            // 
            Label9.AutoSize = true;
            Label9.Location = new Point(249, 241);
            Label9.Name = "Label9";
            Label9.Size = new Size(51, 13);
            Label9.TabIndex = 137;
            Label9.Text = "Address :";
            // 
            // Label36
            // 
            Label36.AutoSize = true;
            Label36.Location = new Point(344, 187);
            Label36.Name = "Label36";
            Label36.Size = new Size(73, 13);
            Label36.TabIndex = 136;
            Label36.Text = "Height ( cm ) :";
            // 
            // Label37
            // 
            Label37.AutoSize = true;
            Label37.Location = new Point(526, 194);
            Label37.Name = "Label37";
            Label37.Size = new Size(75, 13);
            Label37.TabIndex = 135;
            Label37.Text = "Weight ( lbs ) :";
            // 
            // Button1
            // 
            Button1.Location = new Point(15, 444);
            Button1.Name = "Button1";
            Button1.Size = new Size(82, 23);
            Button1.TabIndex = 134;
            Button1.Text = "Update";
            Button1.UseVisualStyleBackColor = true;
            // 
            // Label8
            // 
            Label8.AutoSize = true;
            Label8.Location = new Point(244, 424);
            Label8.Name = "Label8";
            Label8.Size = new Size(51, 13);
            Label8.TabIndex = 133;
            Label8.Text = "Address :";
            // 
            // Label2
            // 
            Label2.AutoSize = true;
            Label2.Location = new Point(246, 352);
            Label2.Name = "Label2";
            Label2.Size = new Size(51, 13);
            Label2.TabIndex = 132;
            Label2.Text = "Address :";
            // 
            // txtmotheradd
            // 
            txtmotheradd.Location = new Point(326, 417);
            txtmotheradd.Name = "txtmotheradd";
            txtmotheradd.Size = new Size(352, 20);
            txtmotheradd.TabIndex = 129;
            // 
            // txtfatheradd
            // 
            txtfatheradd.Location = new Point(326, 348);
            txtfatheradd.Name = "txtfatheradd";
            txtfatheradd.Size = new Size(352, 20);
            txtfatheradd.TabIndex = 128;
            // 
            // txtsadd
            // 
            txtsadd.Location = new Point(326, 289);
            txtsadd.Name = "txtsadd";
            txtsadd.Size = new Size(352, 20);
            txtsadd.TabIndex = 126;
            // 
            // Label19
            // 
            Label19.AutoSize = true;
            Label19.Location = new Point(246, 293);
            Label19.Name = "Label19";
            Label19.Size = new Size(51, 13);
            Label19.TabIndex = 125;
            Label19.Text = "Address :";
            // 
            // txtmothername
            // 
            txtmothername.Location = new Point(326, 382);
            txtmothername.Name = "txtmothername";
            txtmothername.Size = new Size(152, 20);
            txtmothername.TabIndex = 124;
            // 
            // Label20
            // 
            Label20.AutoSize = true;
            Label20.Location = new Point(240, 385);
            Label20.Name = "Label20";
            Label20.Size = new Size(84, 13);
            Label20.TabIndex = 123;
            Label20.Text = "Mother's Name :";
            // 
            // txtfathername
            // 
            txtfathername.Location = new Point(326, 318);
            txtfathername.Name = "txtfathername";
            txtfathername.Size = new Size(152, 20);
            txtfathername.TabIndex = 122;
            // 
            // Label18
            // 
            Label18.AutoSize = true;
            Label18.Location = new Point(244, 321);
            Label18.Name = "Label18";
            Label18.Size = new Size(81, 13);
            Label18.TabIndex = 121;
            Label18.Text = "Father's Name :";
            // 
            // txtnamSpouse
            // 
            txtnamSpouse.Location = new Point(326, 261);
            txtnamSpouse.Name = "txtnamSpouse";
            txtnamSpouse.Size = new Size(152, 20);
            txtnamSpouse.TabIndex = 120;
            // 
            // Label16
            // 
            Label16.AutoSize = true;
            Label16.Location = new Point(243, 264);
            Label16.Name = "Label16";
            Label16.Size = new Size(80, 13);
            Label16.TabIndex = 119;
            Label16.Text = "Spouse Name :";
            // 
            // rdofemale
            // 
            rdofemale.AutoSize = true;
            rdofemale.Location = new Point(623, 148);
            rdofemale.Name = "rdofemale";
            rdofemale.Size = new Size(59, 17);
            rdofemale.TabIndex = 118;
            rdofemale.TabStop = true;
            rdofemale.Text = "Female";
            rdofemale.UseVisualStyleBackColor = true;
            // 
            // rdomale
            // 
            rdomale.AutoSize = true;
            rdomale.Location = new Point(568, 147);
            rdomale.Name = "rdomale";
            rdomale.Size = new Size(48, 17);
            rdomale.TabIndex = 117;
            rdomale.TabStop = true;
            rdomale.Text = "Male";
            rdomale.UseVisualStyleBackColor = true;
            // 
            // dtpbdate
            // 
            dtpbdate.Format = DateTimePickerFormat.Short;
            dtpbdate.Location = new Point(561, 82);
            dtpbdate.Name = "dtpbdate";
            dtpbdate.Size = new Size(121, 20);
            dtpbdate.TabIndex = 116;
            // 
            // txtreligon
            // 
            txtreligon.Location = new Point(88, 338);
            txtreligon.Name = "txtreligon";
            txtreligon.Size = new Size(144, 20);
            txtreligon.TabIndex = 115;
            // 
            // Label13
            // 
            Label13.AutoSize = true;
            Label13.Location = new Point(12, 345);
            Label13.Name = "Label13";
            Label13.Size = new Size(49, 13);
            Label13.TabIndex = 112;
            Label13.Text = "Religon :";
            // 
            // txtcitizen
            // 
            txtcitizen.Location = new Point(88, 311);
            txtcitizen.Name = "txtcitizen";
            txtcitizen.Size = new Size(144, 20);
            txtcitizen.TabIndex = 114;
            // 
            // Label14
            // 
            Label14.AutoSize = true;
            Label14.Location = new Point(12, 314);
            Label14.Name = "Label14";
            Label14.Size = new Size(63, 13);
            Label14.TabIndex = 113;
            Label14.Text = "Citizenship :";
            // 
            // txtHeight
            // 
            txtHeight.Location = new Point(421, 187);
            txtHeight.Name = "txtHeight";
            txtHeight.Size = new Size(60, 20);
            txtHeight.TabIndex = 111;
            // 
            // txtContact
            // 
            txtContact.Location = new Point(88, 285);
            txtContact.Name = "txtContact";
            txtContact.Size = new Size(144, 20);
            txtContact.TabIndex = 110;
            // 
            // Label12
            // 
            Label12.AutoSize = true;
            Label12.Location = new Point(12, 288);
            Label12.Name = "Label12";
            Label12.Size = new Size(70, 13);
            Label12.TabIndex = 109;
            Label12.Text = "Contact No. :";
            // 
            // txtbplace
            // 
            txtbplace.Location = new Point(326, 234);
            txtbplace.Name = "txtbplace";
            txtbplace.Size = new Size(352, 20);
            txtbplace.TabIndex = 107;
            // 
            // Label7
            // 
            Label7.AutoSize = true;
            Label7.Location = new Point(496, 86);
            Label7.Name = "Label7";
            Label7.Size = new Size(57, 13);
            Label7.TabIndex = 104;
            Label7.Text = "BirthDate :";
            // 
            // Label15
            // 
            Label15.AutoSize = true;
            Label15.Location = new Point(498, 149);
            Label15.Name = "Label15";
            Label15.Size = new Size(48, 13);
            Label15.TabIndex = 105;
            Label15.Text = "Gender :";
            // 
            // txtweight
            // 
            txtweight.Location = new Point(607, 187);
            txtweight.Name = "txtweight";
            txtweight.Size = new Size(75, 20);
            txtweight.TabIndex = 103;
            // 
            // txtage
            // 
            txtage.Location = new Point(607, 110);
            txtage.Name = "txtage";
            txtage.Size = new Size(75, 20);
            txtage.TabIndex = 101;
            // 
            // Label5
            // 
            Label5.AutoSize = true;
            Label5.Location = new Point(498, 113);
            Label5.Name = "Label5";
            Label5.Size = new Size(32, 13);
            Label5.TabIndex = 100;
            Label5.Text = "Age :";
            // 
            // txtmname
            // 
            txtmname.Location = new Point(326, 132);
            txtmname.Name = "txtmname";
            txtmname.Size = new Size(75, 20);
            txtmname.TabIndex = 99;
            // 
            // Label6
            // 
            Label6.AutoSize = true;
            Label6.Location = new Point(246, 139);
            Label6.Name = "Label6";
            Label6.Size = new Size(22, 13);
            Label6.TabIndex = 98;
            Label6.Text = "M.I";
            // 
            // txtfname
            // 
            txtfname.Location = new Point(326, 106);
            txtfname.Name = "txtfname";
            txtfname.Size = new Size(155, 20);
            txtfname.TabIndex = 96;
            // 
            // Label3
            // 
            Label3.AutoSize = true;
            Label3.Location = new Point(243, 113);
            Label3.Name = "Label3";
            Label3.Size = new Size(57, 13);
            Label3.TabIndex = 93;
            Label3.Text = "First Name";
            // 
            // txtlname
            // 
            txtlname.Location = new Point(326, 80);
            txtlname.Name = "txtlname";
            txtlname.Size = new Size(155, 20);
            txtlname.TabIndex = 95;
            // 
            // Label4
            // 
            Label4.AutoSize = true;
            Label4.Location = new Point(242, 88);
            Label4.Name = "Label4";
            Label4.Size = new Size(58, 13);
            Label4.TabIndex = 94;
            Label4.Text = "Last Name";
            // 
            // txtemp_id
            // 
            txtemp_id.Enabled = false;
            txtemp_id.Location = new Point(326, 35);
            txtemp_id.Name = "txtemp_id";
            txtemp_id.Size = new Size(155, 20);
            txtemp_id.TabIndex = 49;
            // 
            // label
            // 
            label.AutoSize = true;
            label.Location = new Point(242, 38);
            label.Name = "label";
            label.Size = new Size(76, 13);
            label.TabIndex = 48;
            label.Text = "Employees Id :";
            // 
            // Label35
            // 
            Label35.AutoSize = true;
            Label35.Location = new Point(165, 174);
            Label35.Name = "Label35";
            Label35.Size = new Size(45, 13);
            Label35.TabIndex = 53;
            Label35.Text = "Label35";
            // 
            // TabPage2
            // 
            TabPage2.Controls.Add(cbpositon);
            TabPage2.Controls.Add(GroupBox3);
            TabPage2.Controls.Add(GroupBox1);
            TabPage2.Controls.Add(Button2);
            TabPage2.Controls.Add(GroupBox2);
            TabPage2.Controls.Add(cbocivil);
            TabPage2.Controls.Add(Label17);
            TabPage2.Controls.Add(cboworkstat);
            TabPage2.Controls.Add(dtpHiredate);
            TabPage2.Controls.Add(Label25);
            TabPage2.Controls.Add(Label26);
            TabPage2.Controls.Add(Label28);
            TabPage2.Location = new Point(4, 22);
            TabPage2.Name = "TabPage2";
            TabPage2.Padding = new Padding(3);
            TabPage2.Size = new Size(704, 482);
            TabPage2.TabIndex = 1;
            TabPage2.Text = "Education and Work Info";
            TabPage2.UseVisualStyleBackColor = true;
            // 
            // cbpositon
            // 
            cbpositon.Enabled = false;
            cbpositon.Location = new Point(116, 102);
            cbpositon.Name = "cbpositon";
            cbpositon.ReadOnly = true;
            cbpositon.Size = new Size(90, 20);
            cbpositon.TabIndex = 139;
            cbpositon.Text = "Guard";
            // 
            // GroupBox3
            // 
            GroupBox3.Controls.Add(Label46);
            GroupBox3.Controls.Add(txtPHIC);
            GroupBox3.Controls.Add(Label44);
            GroupBox3.Controls.Add(txtHDMF);
            GroupBox3.Controls.Add(Label31);
            GroupBox3.Controls.Add(txtgl);
            GroupBox3.Controls.Add(Label32);
            GroupBox3.Controls.Add(txtpc);
            GroupBox3.Controls.Add(Label33);
            GroupBox3.Controls.Add(txtothers);
            GroupBox3.Controls.Add(txtnbic);
            GroupBox3.Controls.Add(Label34);
            GroupBox3.Location = new Point(25, 173);
            GroupBox3.Name = "GroupBox3";
            GroupBox3.Size = new Size(654, 143);
            GroupBox3.TabIndex = 138;
            GroupBox3.TabStop = false;
            GroupBox3.Text = "Work Details";
            // 
            // Label46
            // 
            Label46.AutoSize = true;
            Label46.Location = new Point(27, 97);
            Label46.Name = "Label46";
            Label46.Size = new Size(76, 13);
            Label46.TabIndex = 141;
            Label46.Text = "Philhealth No :";
            // 
            // txtPHIC
            // 
            txtPHIC.Location = new Point(28, 113);
            txtPHIC.Name = "txtPHIC";
            txtPHIC.Size = new Size(238, 20);
            txtPHIC.TabIndex = 140;
            // 
            // Label44
            // 
            Label44.AutoSize = true;
            Label44.Location = new Point(287, 98);
            Label44.Name = "Label44";
            Label44.Size = new Size(65, 13);
            Label44.TabIndex = 138;
            Label44.Text = "Pagibig No :";
            // 
            // txtHDMF
            // 
            txtHDMF.Location = new Point(290, 113);
            txtHDMF.Name = "txtHDMF";
            txtHDMF.Size = new Size(238, 20);
            txtHDMF.TabIndex = 137;
            // 
            // Label31
            // 
            Label31.AutoSize = true;
            Label31.Location = new Point(25, 19);
            Label31.Name = "Label31";
            Label31.Size = new Size(123, 13);
            Label31.TabIndex = 94;
            Label31.Text = "Guard Licence Number :";
            // 
            // txtgl
            // 
            txtgl.Location = new Point(28, 35);
            txtgl.Name = "txtgl";
            txtgl.Size = new Size(238, 20);
            txtgl.TabIndex = 95;
            // 
            // Label32
            // 
            Label32.AutoSize = true;
            Label32.Location = new Point(287, 19);
            Label32.Name = "Label32";
            Label32.Size = new Size(82, 13);
            Label32.TabIndex = 136;
            Label32.Text = "Expiration Date.";
            // 
            // txtpc
            // 
            txtpc.Location = new Point(290, 35);
            txtpc.Name = "txtpc";
            txtpc.Size = new Size(238, 20);
            txtpc.TabIndex = 114;
            // 
            // Label33
            // 
            Label33.AutoSize = true;
            Label33.Location = new Point(25, 58);
            Label33.Name = "Label33";
            Label33.Size = new Size(45, 13);
            Label33.TabIndex = 115;
            Label33.Text = "TIN No.";
            // 
            // txtothers
            // 
            txtothers.Location = new Point(290, 74);
            txtothers.Name = "txtothers";
            txtothers.Size = new Size(238, 20);
            txtothers.TabIndex = 118;
            // 
            // txtnbic
            // 
            txtnbic.Location = new Point(28, 74);
            txtnbic.Name = "txtnbic";
            txtnbic.Size = new Size(238, 20);
            txtnbic.TabIndex = 116;
            // 
            // Label34
            // 
            Label34.AutoSize = true;
            Label34.Location = new Point(287, 58);
            Label34.Name = "Label34";
            Label34.Size = new Size(48, 13);
            Label34.TabIndex = 117;
            Label34.Text = "SSS No.";
            // 
            // GroupBox1
            // 
            GroupBox1.Controls.Add(txtcollege);
            GroupBox1.Controls.Add(Label24);
            GroupBox1.Controls.Add(txtelem);
            GroupBox1.Controls.Add(Label22);
            GroupBox1.Controls.Add(txthschool);
            GroupBox1.Controls.Add(Label23);
            GroupBox1.Controls.Add(Label29);
            GroupBox1.Controls.Add(txtelem_year);
            GroupBox1.Controls.Add(Label27);
            GroupBox1.Controls.Add(txthschool_yeAR);
            GroupBox1.Controls.Add(Label30);
            GroupBox1.Controls.Add(txtcollegeYear);
            GroupBox1.Location = new Point(25, 322);
            GroupBox1.Name = "GroupBox1";
            GroupBox1.Size = new Size(657, 122);
            GroupBox1.TabIndex = 137;
            GroupBox1.TabStop = false;
            GroupBox1.Text = "Educational Deatils";
            // 
            // txtcollege
            // 
            txtcollege.Location = new Point(110, 89);
            txtcollege.Name = "txtcollege";
            txtcollege.Size = new Size(335, 20);
            txtcollege.TabIndex = 102;
            // 
            // Label24
            // 
            Label24.AutoSize = true;
            Label24.Location = new Point(31, 22);
            Label24.Name = "Label24";
            Label24.Size = new Size(65, 13);
            Label24.TabIndex = 101;
            Label24.Text = "Elementary :";
            // 
            // txtelem
            // 
            txtelem.Location = new Point(110, 19);
            txtelem.Name = "txtelem";
            txtelem.Size = new Size(335, 20);
            txtelem.TabIndex = 103;
            // 
            // Label22
            // 
            Label22.AutoSize = true;
            Label22.Location = new Point(30, 56);
            Label22.Name = "Label22";
            Label22.Size = new Size(71, 13);
            Label22.TabIndex = 99;
            Label22.Text = "High School :";
            // 
            // txthschool
            // 
            txthschool.Location = new Point(110, 53);
            txthschool.Name = "txthschool";
            txthschool.Size = new Size(335, 20);
            txthschool.TabIndex = 104;
            // 
            // Label23
            // 
            Label23.AutoSize = true;
            Label23.Location = new Point(30, 92);
            Label23.Name = "Label23";
            Label23.Size = new Size(48, 13);
            Label23.TabIndex = 100;
            Label23.Text = "College :";
            // 
            // Label29
            // 
            Label29.AutoSize = true;
            Label29.Location = new Point(451, 22);
            Label29.Name = "Label29";
            Label29.Size = new Size(35, 13);
            Label29.TabIndex = 105;
            Label29.Text = "Year :";
            // 
            // txtelem_year
            // 
            txtelem_year.Location = new Point(492, 19);
            txtelem_year.Name = "txtelem_year";
            txtelem_year.Size = new Size(110, 20);
            txtelem_year.TabIndex = 107;
            // 
            // Label27
            // 
            Label27.AutoSize = true;
            Label27.Location = new Point(451, 92);
            Label27.Name = "Label27";
            Label27.Size = new Size(35, 13);
            Label27.TabIndex = 110;
            Label27.Text = "Year :";
            // 
            // txthschool_yeAR
            // 
            txthschool_yeAR.Location = new Point(492, 53);
            txthschool_yeAR.Name = "txthschool_yeAR";
            txthschool_yeAR.Size = new Size(110, 20);
            txthschool_yeAR.TabIndex = 108;
            // 
            // Label30
            // 
            Label30.AutoSize = true;
            Label30.Location = new Point(451, 60);
            Label30.Name = "Label30";
            Label30.Size = new Size(35, 13);
            Label30.TabIndex = 109;
            Label30.Text = "Year :";
            // 
            // txtcollegeYear
            // 
            txtcollegeYear.Location = new Point(492, 89);
            txtcollegeYear.Name = "txtcollegeYear";
            txtcollegeYear.Size = new Size(110, 20);
            txtcollegeYear.TabIndex = 106;
            // 
            // Button2
            // 
            Button2.Location = new Point(597, 453);
            Button2.Name = "Button2";
            Button2.Size = new Size(82, 23);
            Button2.TabIndex = 135;
            Button2.Text = "Update";
            Button2.UseVisualStyleBackColor = true;
            // 
            // GroupBox2
            // 
            GroupBox2.Controls.Add(rbdep0);
            GroupBox2.Controls.Add(rbdep4);
            GroupBox2.Controls.Add(rbdep3);
            GroupBox2.Controls.Add(rbdep2);
            GroupBox2.Controls.Add(rbdep1);
            GroupBox2.Location = new Point(247, 107);
            GroupBox2.Name = "GroupBox2";
            GroupBox2.Size = new Size(255, 49);
            GroupBox2.TabIndex = 98;
            GroupBox2.TabStop = false;
            GroupBox2.Text = "Number of Qualified Dependent";
            // 
            // rbdep0
            // 
            rbdep0.AutoSize = true;
            rbdep0.Location = new Point(18, 20);
            rbdep0.Name = "rbdep0";
            rbdep0.Size = new Size(31, 17);
            rbdep0.TabIndex = 4;
            rbdep0.TabStop = true;
            rbdep0.Text = "0";
            rbdep0.UseVisualStyleBackColor = true;
            // 
            // rbdep4
            // 
            rbdep4.AutoSize = true;
            rbdep4.Location = new Point(196, 20);
            rbdep4.Name = "rbdep4";
            rbdep4.Size = new Size(31, 17);
            rbdep4.TabIndex = 3;
            rbdep4.TabStop = true;
            rbdep4.Text = "4";
            rbdep4.UseVisualStyleBackColor = true;
            // 
            // rbdep3
            // 
            rbdep3.AutoSize = true;
            rbdep3.Location = new Point(158, 20);
            rbdep3.Name = "rbdep3";
            rbdep3.Size = new Size(31, 17);
            rbdep3.TabIndex = 2;
            rbdep3.TabStop = true;
            rbdep3.Text = "3";
            rbdep3.UseVisualStyleBackColor = true;
            // 
            // rbdep2
            // 
            rbdep2.AutoSize = true;
            rbdep2.Location = new Point(112, 20);
            rbdep2.Name = "rbdep2";
            rbdep2.Size = new Size(31, 17);
            rbdep2.TabIndex = 1;
            rbdep2.TabStop = true;
            rbdep2.Text = "2";
            rbdep2.UseVisualStyleBackColor = true;
            // 
            // rbdep1
            // 
            rbdep1.AutoSize = true;
            rbdep1.Location = new Point(67, 20);
            rbdep1.Name = "rbdep1";
            rbdep1.Size = new Size(31, 17);
            rbdep1.TabIndex = 0;
            rbdep1.TabStop = true;
            rbdep1.Text = "1";
            rbdep1.UseVisualStyleBackColor = true;
            // 
            // cbocivil
            // 
            cbocivil.FormattingEnabled = true;
            cbocivil.Items.AddRange(new object[] { "Zero Exemption", "Single", "Married" });
            cbocivil.Location = new Point(116, 135);
            cbocivil.Name = "cbocivil";
            cbocivil.Size = new Size(116, 21);
            cbocivil.TabIndex = 97;
            cbocivil.Text = "Single";
            // 
            // Label17
            // 
            Label17.AutoSize = true;
            Label17.Location = new Point(37, 143);
            Label17.Name = "Label17";
            Label17.Size = new Size(65, 13);
            Label17.TabIndex = 96;
            Label17.Text = "Civil Status :";
            // 
            // cboworkstat
            // 
            cboworkstat.FormattingEnabled = true;
            cboworkstat.Items.AddRange(new object[] { "Active", "Suspended", "Resigned", "Retired" });
            cboworkstat.Location = new Point(116, 65);
            cboworkstat.Name = "cboworkstat";
            cboworkstat.Size = new Size(118, 21);
            cboworkstat.TabIndex = 92;
            cboworkstat.Text = "Active";
            // 
            // dtpHiredate
            // 
            dtpHiredate.Format = DateTimePickerFormat.Short;
            dtpHiredate.Location = new Point(116, 36);
            dtpHiredate.Name = "dtpHiredate";
            dtpHiredate.Size = new Size(118, 20);
            dtpHiredate.TabIndex = 91;
            // 
            // Label25
            // 
            Label25.AutoSize = true;
            Label25.Location = new Point(37, 102);
            Label25.Name = "Label25";
            Label25.Size = new Size(50, 13);
            Label25.TabIndex = 90;
            Label25.Text = "Position :";
            // 
            // Label26
            // 
            Label26.AutoSize = true;
            Label26.Location = new Point(36, 73);
            Label26.Name = "Label26";
            Label26.Size = new Size(43, 13);
            Label26.TabIndex = 89;
            Label26.Text = "Status :";
            // 
            // Label28
            // 
            Label28.AutoSize = true;
            Label28.Location = new Point(36, 42);
            Label28.Name = "Label28";
            Label28.Size = new Size(64, 13);
            Label28.TabIndex = 88;
            Label28.Text = "Hired Date :";
            // 
            // Label21
            // 
            Label21.AutoSize = true;
            Label21.Location = new Point(77, 83);
            Label21.Name = "Label21";
            Label21.Size = new Size(45, 13);
            Label21.TabIndex = 52;
            Label21.Text = "Label21";
            // 
            // TabPage3
            // 
            TabPage3.Controls.Add(Button3);
            TabPage3.Controls.Add(txtwedate3);
            TabPage3.Controls.Add(txtwedate2);
            TabPage3.Controls.Add(txtwedate1);
            TabPage3.Controls.Add(Label50);
            TabPage3.Controls.Add(Label48);
            TabPage3.Controls.Add(Label47);
            TabPage3.Controls.Add(txtwepos3);
            TabPage3.Controls.Add(txtwepos2);
            TabPage3.Controls.Add(txtwepos1);
            TabPage3.Controls.Add(txtwecom3);
            TabPage3.Controls.Add(txtwecom2);
            TabPage3.Controls.Add(txtwecom1);
            TabPage3.Location = new Point(4, 22);
            TabPage3.Name = "TabPage3";
            TabPage3.Padding = new Padding(3);
            TabPage3.Size = new Size(704, 482);
            TabPage3.TabIndex = 2;
            TabPage3.Text = "Work Experience";
            TabPage3.UseVisualStyleBackColor = true;
            // 
            // txtwedate3
            // 
            txtwedate3.Location = new Point(516, 106);
            txtwedate3.Name = "txtwedate3";
            txtwedate3.Size = new Size(107, 20);
            txtwedate3.TabIndex = 122;
            // 
            // txtwedate2
            // 
            txtwedate2.Location = new Point(516, 80);
            txtwedate2.Name = "txtwedate2";
            txtwedate2.Size = new Size(107, 20);
            txtwedate2.TabIndex = 121;
            // 
            // txtwedate1
            // 
            txtwedate1.Location = new Point(516, 54);
            txtwedate1.Name = "txtwedate1";
            txtwedate1.Size = new Size(107, 20);
            txtwedate1.TabIndex = 111;
            // 
            // Label50
            // 
            Label50.AutoSize = true;
            Label50.Location = new Point(327, 36);
            Label50.Name = "Label50";
            Label50.Size = new Size(44, 13);
            Label50.TabIndex = 120;
            Label50.Text = "Position";
            // 
            // Label48
            // 
            Label48.AutoSize = true;
            Label48.Location = new Point(519, 35);
            Label48.Name = "Label48";
            Label48.Size = new Size(75, 13);
            Label48.TabIndex = 119;
            Label48.Text = "Inclusive Date";
            // 
            // Label47
            // 
            Label47.AutoSize = true;
            Label47.Location = new Point(32, 36);
            Label47.Name = "Label47";
            Label47.Size = new Size(51, 13);
            Label47.TabIndex = 113;
            Label47.Text = "Company";
            // 
            // txtwepos3
            // 
            txtwepos3.Location = new Point(324, 106);
            txtwepos3.Name = "txtwepos3";
            txtwepos3.Size = new Size(186, 20);
            txtwepos3.TabIndex = 118;
            // 
            // txtwepos2
            // 
            txtwepos2.Location = new Point(324, 80);
            txtwepos2.Name = "txtwepos2";
            txtwepos2.Size = new Size(186, 20);
            txtwepos2.TabIndex = 117;
            // 
            // txtwepos1
            // 
            txtwepos1.Location = new Point(324, 54);
            txtwepos1.Name = "txtwepos1";
            txtwepos1.Size = new Size(186, 20);
            txtwepos1.TabIndex = 116;
            // 
            // txtwecom3
            // 
            txtwecom3.Location = new Point(28, 106);
            txtwecom3.Name = "txtwecom3";
            txtwecom3.Size = new Size(289, 20);
            txtwecom3.TabIndex = 115;
            // 
            // txtwecom2
            // 
            txtwecom2.Location = new Point(28, 80);
            txtwecom2.Name = "txtwecom2";
            txtwecom2.Size = new Size(289, 20);
            txtwecom2.TabIndex = 114;
            // 
            // txtwecom1
            // 
            txtwecom1.Location = new Point(28, 55);
            txtwecom1.Name = "txtwecom1";
            txtwecom1.Size = new Size(289, 20);
            txtwecom1.TabIndex = 112;
            // 
            // Button3
            // 
            Button3.Location = new Point(593, 439);
            Button3.Name = "Button3";
            Button3.Size = new Size(82, 23);
            Button3.TabIndex = 136;
            Button3.Text = "Update";
            Button3.UseVisualStyleBackColor = true;
            // 
            // Label40
            // 
            Label40.AutoSize = true;
            Label40.Location = new Point(60, 149);
            Label40.Name = "Label40";
            Label40.Size = new Size(45, 13);
            Label40.TabIndex = 142;
            Label40.Text = "Label40";
            // 
            // frmIndividualprofile
            // 
            AutoScaleDimensions = new SizeF(6.0f, 13.0f);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(732, 532);
            Controls.Add(TabControl1);
            Controls.Add(Label1);
            Controls.Add(TextBox2);
            Controls.Add(Label21);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Name = "frmIndividualprofile";
            StartPosition = FormStartPosition.CenterScreen;
            ((System.ComponentModel.ISupportInitialize)PictureBox2).EndInit();
            TabControl1.ResumeLayout(false);
            TabPage1.ResumeLayout(false);
            TabPage1.PerformLayout();
            TabPage2.ResumeLayout(false);
            TabPage2.PerformLayout();
            GroupBox3.ResumeLayout(false);
            GroupBox3.PerformLayout();
            GroupBox1.ResumeLayout(false);
            GroupBox1.PerformLayout();
            GroupBox2.ResumeLayout(false);
            GroupBox2.PerformLayout();
            TabPage3.ResumeLayout(false);
            TabPage3.PerformLayout();
            Load += new EventHandler(frmIndividualprofile_Load);
            ResumeLayout(false);
            PerformLayout();

        }
        internal PictureBox PictureBox2;
        internal Button Button6;
        internal Button Button4;
        internal TextBox TextBox2;
        internal OpenFileDialog OpenFileDialog1;
        internal Label Label1;
        internal TabControl TabControl1;
        internal TabPage TabPage1;
        internal TabPage TabPage2;
        internal TextBox txtemp_id;
        internal Label label;
        internal TextBox txtmotheradd;
        internal TextBox txtfatheradd;
        internal TextBox txtsadd;
        internal Label Label19;
        internal TextBox txtmothername;
        internal Label Label20;
        internal TextBox txtfathername;
        internal Label Label18;
        internal TextBox txtnamSpouse;
        internal Label Label16;
        internal RadioButton rdofemale;
        internal RadioButton rdomale;
        internal DateTimePicker dtpbdate;
        internal TextBox txtreligon;
        internal Label Label13;
        internal TextBox txtcitizen;
        internal Label Label14;
        internal TextBox txtHeight;
        internal TextBox txtContact;
        internal Label Label12;
        internal TextBox txtbplace;
        internal Label Label7;
        internal Label Label15;
        internal TextBox txtweight;
        internal TextBox txtage;
        internal Label Label5;
        internal TextBox txtmname;
        internal Label Label6;
        internal TextBox txtfname;
        internal Label Label3;
        internal TextBox txtlname;
        internal Label Label4;
        internal Label Label8;
        internal Label Label2;
        internal ComboBox cboworkstat;
        internal DateTimePicker dtpHiredate;
        internal Label Label25;
        internal Label Label26;
        internal Label Label28;
        internal MaskedTextBox txtgl;
        internal Label Label31;
        internal GroupBox GroupBox2;
        internal RadioButton rbdep0;
        internal RadioButton rbdep4;
        internal RadioButton rbdep3;
        internal RadioButton rbdep2;
        internal RadioButton rbdep1;
        internal ComboBox cbocivil;
        internal Label Label17;
        internal Label Label27;
        internal Label Label30;
        internal MaskedTextBox txtcollegeYear;
        internal MaskedTextBox txthschool_yeAR;
        internal MaskedTextBox txtelem_year;
        internal Label Label29;
        internal MaskedTextBox txtcollege;
        internal Label Label23;
        internal MaskedTextBox txthschool;
        internal Label Label22;
        internal MaskedTextBox txtelem;
        internal Label Label24;
        internal MaskedTextBox txtothers;
        internal Label Label34;
        internal MaskedTextBox txtnbic;
        internal Label Label33;
        internal MaskedTextBox txtpc;
        internal Button Button1;
        internal Button Button2;
        internal Label Label21;
        internal Label Label35;
        internal Label Label36;
        internal Label Label37;
        internal Label Label9;
        internal Label Label39;
        internal Label Label38;
        internal Label Label11;
        internal Label Label10;
        internal GroupBox GroupBox3;
        internal Label Label32;
        internal GroupBox GroupBox1;
        internal TextBox cbpositon;
        internal Label Label46;
        internal MaskedTextBox txtPHIC;
        internal Label Label44;
        internal MaskedTextBox txtHDMF;
        internal TabPage TabPage3;
        internal TextBox txtwedate3;
        internal TextBox txtwedate2;
        internal TextBox txtwedate1;
        internal Label Label50;
        internal Label Label48;
        internal Label Label47;
        internal TextBox txtwepos3;
        internal TextBox txtwepos2;
        internal TextBox txtwepos1;
        internal TextBox txtwecom3;
        internal TextBox txtwecom2;
        internal TextBox txtwecom1;
        internal Button Button3;
        internal Label Label40;
    }
}
﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace Ichiban
{
    [Microsoft.VisualBasic.CompilerServices.DesignerGenerated()]
    public partial class client : Form
    {

        // Form overrides dispose to clean up the component list.
        [DebuggerNonUserCode()]
        protected override void Dispose(bool disposing)
        {
            try
            {
                if (disposing && components is not null)
                {
                    components.Dispose();
                }
            }
            finally
            {
                base.Dispose(disposing);
            }
        }

        // Required by the Windows Form Designer
        private System.ComponentModel.IContainer components;

        // NOTE: The following procedure is required by the Windows Form Designer
        // It can be modified using the Windows Form Designer.  
        // Do not modify it using the code editor.
        [DebuggerStepThrough()]
        private void InitializeComponent()
        {
            Panel1 = new Panel();
            Label4 = new Label();
            gbclientinfo = new GroupBox();
            endDate = new DateTimePicker();
            strtdate = new DateTimePicker();
            Label2 = new Label();
            Label1 = new Label();
            LBLCLIENTID = new Label();
            btnUpdateClient = new Button();
            btnUpdateClient.Click += new EventHandler(btnUpdateClient_Click);
            btnClientsave = new Button();
            btnClientsave.Click += new EventHandler(btnClientsave_Click);
            txtrate = new TextBox();
            txtrate.TextChanged += new EventHandler(txtrate_TextChanged);
            Label25 = new Label();
            txtClientadd = new TextBox();
            Label24 = new Label();
            txtClinetName = new TextBox();
            txtClinetName.TextChanged += new EventHandler(txtClinetName_TextChanged);
            Label23 = new Label();
            GroupBox1 = new GroupBox();
            TabControl1 = new TabControl();
            TabPage1 = new TabPage();
            Button1 = new Button();
            Button1.Click += new EventHandler(Button1_Click);
            DataGridView2 = new DataGridView();
            DataGridView2.CellClick += new DataGridViewCellEventHandler(DataGridView2_CellClick);
            DataGridView2.CellContentClick += new DataGridViewCellEventHandler(DataGridView2_CellContentClick);
            TabPage2 = new TabPage();
            DataGridView1 = new DataGridView();
            ID = new Label();
            Panel1.SuspendLayout();
            gbclientinfo.SuspendLayout();
            GroupBox1.SuspendLayout();
            TabControl1.SuspendLayout();
            TabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)DataGridView2).BeginInit();
            TabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)DataGridView1).BeginInit();
            SuspendLayout();
            // 
            // Panel1
            // 
            Panel1.BackColor = SystemColors.ActiveCaption;
            Panel1.Controls.Add(Label4);
            Panel1.Dock = DockStyle.Top;
            Panel1.Location = new Point(0, 0);
            Panel1.Name = "Panel1";
            Panel1.Size = new Size(480, 51);
            Panel1.TabIndex = 2;
            // 
            // Label4
            // 
            Label4.Font = new Font("Microsoft Sans Serif", 18.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label4.ForeColor = SystemColors.HighlightText;
            Label4.Location = new Point(3, 9);
            Label4.Name = "Label4";
            Label4.Size = new Size(348, 33);
            Label4.TabIndex = 1;
            Label4.Text = "Client's Information";
            // 
            // gbclientinfo
            // 
            gbclientinfo.Controls.Add(endDate);
            gbclientinfo.Controls.Add(strtdate);
            gbclientinfo.Controls.Add(Label2);
            gbclientinfo.Controls.Add(Label1);
            gbclientinfo.Controls.Add(LBLCLIENTID);
            gbclientinfo.Controls.Add(btnUpdateClient);
            gbclientinfo.Controls.Add(btnClientsave);
            gbclientinfo.Controls.Add(txtrate);
            gbclientinfo.Controls.Add(Label25);
            gbclientinfo.Controls.Add(txtClientadd);
            gbclientinfo.Controls.Add(Label24);
            gbclientinfo.Controls.Add(txtClinetName);
            gbclientinfo.Controls.Add(Label23);
            gbclientinfo.Location = new Point(8, 70);
            gbclientinfo.Name = "gbclientinfo";
            gbclientinfo.Size = new Size(452, 180);
            gbclientinfo.TabIndex = 15;
            gbclientinfo.TabStop = false;
            gbclientinfo.Text = "Information";
            // 
            // endDate
            // 
            endDate.Format = DateTimePickerFormat.Short;
            endDate.Location = new Point(252, 112);
            endDate.Name = "endDate";
            endDate.Size = new Size(92, 20);
            endDate.TabIndex = 26;
            // 
            // strtdate
            // 
            strtdate.Format = DateTimePickerFormat.Short;
            strtdate.Location = new Point(90, 113);
            strtdate.Name = "strtdate";
            strtdate.Size = new Size(92, 20);
            strtdate.TabIndex = 25;
            // 
            // Label2
            // 
            Label2.AutoSize = true;
            Label2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label2.Location = new Point(188, 119);
            Label2.Name = "Label2";
            Label2.Size = new Size(58, 13);
            Label2.TabIndex = 24;
            Label2.Text = "End Date :";
            // 
            // Label1
            // 
            Label1.AutoSize = true;
            Label1.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label1.Location = new Point(26, 119);
            Label1.Name = "Label1";
            Label1.Size = new Size(58, 13);
            Label1.TabIndex = 23;
            Label1.Text = "Start Date:";
            // 
            // LBLCLIENTID
            // 
            LBLCLIENTID.AutoSize = true;
            LBLCLIENTID.Location = new Point(327, 20);
            LBLCLIENTID.Name = "LBLCLIENTID";
            LBLCLIENTID.Size = new Size(18, 13);
            LBLCLIENTID.TabIndex = 22;
            LBLCLIENTID.Text = "ID";
            LBLCLIENTID.Visible = false;
            // 
            // btnUpdateClient
            // 
            btnUpdateClient.BackgroundImageLayout = ImageLayout.Stretch;
            btnUpdateClient.Location = new Point(363, 145);
            btnUpdateClient.Name = "btnUpdateClient";
            btnUpdateClient.Size = new Size(83, 29);
            btnUpdateClient.TabIndex = 21;
            btnUpdateClient.Text = "Update";
            btnUpdateClient.UseVisualStyleBackColor = true;
            // 
            // btnClientsave
            // 
            btnClientsave.BackgroundImageLayout = ImageLayout.Stretch;
            btnClientsave.Location = new Point(274, 145);
            btnClientsave.Name = "btnClientsave";
            btnClientsave.Size = new Size(83, 29);
            btnClientsave.TabIndex = 20;
            btnClientsave.Text = "New";
            btnClientsave.UseVisualStyleBackColor = true;
            // 
            // txtrate
            // 
            txtrate.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtrate.Location = new Point(90, 74);
            txtrate.Name = "txtrate";
            txtrate.Size = new Size(228, 22);
            txtrate.TabIndex = 19;
            // 
            // Label25
            // 
            Label25.AutoSize = true;
            Label25.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label25.Location = new Point(8, 79);
            Label25.Name = "Label25";
            Label25.Size = new Size(76, 26);
            Label25.TabIndex = 18;
            Label25.Text = "Contract Price" + '\r' + '\n' + "(monthly basis)";
            // 
            // txtClientadd
            // 
            txtClientadd.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtClientadd.Location = new Point(91, 46);
            txtClientadd.Name = "txtClientadd";
            txtClientadd.Size = new Size(329, 22);
            txtClientadd.TabIndex = 15;
            // 
            // Label24
            // 
            Label24.AutoSize = true;
            Label24.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label24.Location = new Point(8, 54);
            Label24.Name = "Label24";
            Label24.Size = new Size(80, 13);
            Label24.TabIndex = 16;
            Label24.Text = "Client Address :";
            // 
            // txtClinetName
            // 
            txtClinetName.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtClinetName.Location = new Point(91, 18);
            txtClinetName.Name = "txtClinetName";
            txtClinetName.Size = new Size(228, 22);
            txtClinetName.TabIndex = 13;
            // 
            // Label23
            // 
            Label23.AutoSize = true;
            Label23.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label23.Location = new Point(15, 23);
            Label23.Name = "Label23";
            Label23.Size = new Size(70, 13);
            Label23.TabIndex = 14;
            Label23.Text = "Client Name :";
            // 
            // GroupBox1
            // 
            GroupBox1.Controls.Add(TabControl1);
            GroupBox1.Location = new Point(8, 256);
            GroupBox1.Name = "GroupBox1";
            GroupBox1.Size = new Size(457, 201);
            GroupBox1.TabIndex = 16;
            GroupBox1.TabStop = false;
            // 
            // TabControl1
            // 
            TabControl1.Controls.Add(TabPage1);
            TabControl1.Controls.Add(TabPage2);
            TabControl1.Dock = DockStyle.Fill;
            TabControl1.Location = new Point(3, 16);
            TabControl1.Name = "TabControl1";
            TabControl1.SelectedIndex = 0;
            TabControl1.Size = new Size(451, 182);
            TabControl1.TabIndex = 0;
            // 
            // TabPage1
            // 
            TabPage1.Controls.Add(Button1);
            TabPage1.Controls.Add(DataGridView2);
            TabPage1.Location = new Point(4, 22);
            TabPage1.Name = "TabPage1";
            TabPage1.Padding = new Padding(3);
            TabPage1.Size = new Size(443, 156);
            TabPage1.TabIndex = 0;
            TabPage1.Text = "List of Client";
            TabPage1.UseVisualStyleBackColor = true;
            // 
            // Button1
            // 
            Button1.BackgroundImageLayout = ImageLayout.Stretch;
            Button1.Location = new Point(335, 121);
            Button1.Name = "Button1";
            Button1.Size = new Size(102, 29);
            Button1.TabIndex = 22;
            Button1.Text = "Assign Guard";
            Button1.UseVisualStyleBackColor = true;
            // 
            // DataGridView2
            // 
            DataGridView2.AllowUserToAddRows = false;
            DataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DataGridView2.Location = new Point(11, 6);
            DataGridView2.Name = "DataGridView2";
            DataGridView2.RowHeadersVisible = false;
            DataGridView2.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            DataGridView2.Size = new Size(426, 109);
            DataGridView2.TabIndex = 16;
            // 
            // TabPage2
            // 
            TabPage2.Controls.Add(DataGridView1);
            TabPage2.Location = new Point(4, 22);
            TabPage2.Name = "TabPage2";
            TabPage2.Padding = new Padding(3);
            TabPage2.Size = new Size(443, 156);
            TabPage2.TabIndex = 1;
            TabPage2.Text = "Reminders";
            TabPage2.UseVisualStyleBackColor = true;
            // 
            // DataGridView1
            // 
            DataGridView1.AllowUserToAddRows = false;
            DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DataGridView1.Location = new Point(6, 6);
            DataGridView1.Name = "DataGridView1";
            DataGridView1.RowHeadersVisible = false;
            DataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            DataGridView1.Size = new Size(426, 144);
            DataGridView1.TabIndex = 17;
            // 
            // ID
            // 
            ID.AutoSize = true;
            ID.Location = new Point(11, 54);
            ID.Name = "ID";
            ID.Size = new Size(18, 13);
            ID.TabIndex = 27;
            ID.Text = "ID";
            ID.Visible = false;
            // 
            // client
            // 
            AutoScaleDimensions = new SizeF(6.0f, 13.0f);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(480, 473);
            Controls.Add(ID);
            Controls.Add(GroupBox1);
            Controls.Add(gbclientinfo);
            Controls.Add(Panel1);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Name = "client";
            StartPosition = FormStartPosition.CenterScreen;
            Panel1.ResumeLayout(false);
            gbclientinfo.ResumeLayout(false);
            gbclientinfo.PerformLayout();
            GroupBox1.ResumeLayout(false);
            TabControl1.ResumeLayout(false);
            TabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)DataGridView2).EndInit();
            TabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)DataGridView1).EndInit();
            Load += new EventHandler(client_Load);
            ResumeLayout(false);
            PerformLayout();

        }
        internal Panel Panel1;
        internal Label Label4;
        internal GroupBox gbclientinfo;
        internal TextBox txtrate;
        internal Label Label25;
        internal TextBox txtClientadd;
        internal Label Label24;
        internal TextBox txtClinetName;
        internal Label Label23;
        internal GroupBox GroupBox1;
        internal DataGridView DataGridView2;
        internal Button btnUpdateClient;
        internal Button btnClientsave;
        internal Button Button1;
        internal Label LBLCLIENTID;
        internal DateTimePicker endDate;
        internal DateTimePicker strtdate;
        internal Label Label2;
        internal Label Label1;
        internal Label ID;
        internal TabControl TabControl1;
        internal TabPage TabPage1;
        internal TabPage TabPage2;
        internal DataGridView DataGridView1;
    }
}
﻿using System;
using System.Drawing;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace Ichiban
{
    public partial class frmIndividualprofile
    {

        private string sql;

        public frmIndividualprofile()
        {
            InitializeComponent();
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            if ((int)OpenFileDialog1.ShowDialog() == 1)
            {

                PictureBox2.Image = Image.FromFile(OpenFileDialog1.FileName);
                TextBox2.Text = System.IO.Path.GetFileName(OpenFileDialog1.FileName);
                // strfilenam = OpenFileDialog1.FileName

                // TextBox2.Text = strfilenam

            }

        }

        private void Button6_Click(object sender, EventArgs e)
        {


            sql = "select * from tblemppic where empid = '" + Label1.Text + "'";
            jokensqlselect.jokenfindthis(sql);
            jokensqlselect.checkresult("Pic");



        }


        private void Button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtfname.Text) | string.IsNullOrEmpty(txtlname.Text) | string.IsNullOrEmpty(txtmname.Text) | string.IsNullOrEmpty(txtbplace.Text) | string.IsNullOrEmpty(txtage.Text))
            {
                Interaction.MsgBox("You must fill up the Required fields.", MsgBoxStyle.Critical);
            }
            else
            {
                object rdo;

                if (rdomale.Checked == true)
                {
                    rdo = "Male";
                }
                else
                {
                    rdo = "Female";
                }

                if (rbdep1.Checked & cbocivil.Text == "Married")
                {
                    publicvariable.taxid = "M1";
                }
                else if (rbdep2.Checked & cbocivil.Text == "Married")
                {
                    publicvariable.taxid = "M2";
                }
                else if (rbdep3.Checked & cbocivil.Text == "Married")
                {
                    publicvariable.taxid = "M3";
                }
                else if (rbdep4.Checked & cbocivil.Text == "Married")
                {
                    publicvariable.taxid = "M4";
                }
                else if (rbdep0.Checked & cbocivil.Text == "Married")
                {
                    publicvariable.taxid = "M";
                }

                if (rbdep1.Checked & cbocivil.Text == "Single")
                {
                    publicvariable.taxid = "S1";
                }
                else if (rbdep2.Checked & cbocivil.Text == "Single")
                {
                    publicvariable.taxid = "S2";
                }
                else if (rbdep3.Checked & cbocivil.Text == "Single")
                {
                    publicvariable.taxid = "S3";
                }
                else if (rbdep4.Checked & cbocivil.Text == "Single")
                {
                    publicvariable.taxid = "S4";
                }
                else if (rbdep0.Checked & cbocivil.Text == "Single")
                {
                    publicvariable.taxid = "S";
                }



                crud.jokenupdate(Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("update tblemployee set FNAME = '" + txtfname.Text + "', LNAME = '" + txtlname.Text + "', MI = '" + txtmname.Text + "', AGE = " + Conversion.Val(txtage.Text) + ", GENDER = '", rdo), "', BDAY = '"), dtpbdate.Value), "', BPLACE = '"), txtbplace.Text), "', HEIGHT = '"), txtHeight.Text), "', WEIGHT = '"), txtweight.Text), "', CIVIL_STATUS = '"), cbocivil.Text), "', CONTACT = '"), txtContact.Text), "', RELIGION = '"), txtreligon.Text), "', SPOUSE = '"), txtnamSpouse.Text), "', SP_ADDRESS = '"), txtsadd.Text), "', CITIZENSHIP = '"), txtcitizen.Text), "', HIREDDATE = '"), dtpHiredate.Value), "', WORKSTATUS = '"), cboworkstat.Text), "', GPOSITION = '"), cbpositon.Text), "', TAXID = '"), publicvariable.taxid), "' where ID = "), Label40.Text), "")));






                crud.jokenupdate("update tblempbackgrd set MOTHER = '" + txtmothername.Text + "', M_ADDRESS = '" + txtmotheradd.Text + "', ELEMENTARY = '" + txtelem.Text + "', ELEMYEAR = '" + txtelem_year.Text + "', SECONDARY = '" + txthschool.Text + "', SECONDARY_YEAR = '" + txthschool_yeAR.Text + "', TERTIARY = '" + txtcollege.Text + "', TERTIARY_YEAR = '" + txtcollegeYear.Text + "', OTHERS = '" + txtothers.Text + "',  FATHER = '" + txtfathername.Text + "', F_ADDRESS = '" + txtfatheradd.Text + "', GLNO = '" + txtgl.Text + "', POLCL = '" + txtpc.Text + "',  NBICL = '" + txtnbic.Text + "', WECOMP1 = '" + txtwecom1.Text + "',  WECOMP2 = '" + txtwecom2.Text + "', WECOMP3 = '" + txtwecom3.Text + "', WEPOS1 = '" + txtwepos1.Text + "', WEPOS2 = '" + txtwepos2.Text + "', WEPOS3 = '" + txtwepos3.Text + "', WEDATE1 = '" + txtwedate1.Text + "', WEDATE2 = '" + txtwedate2.Text + "', WEDATE3 = '" + txtwedate3.Text + "' where EMPID = '" + txtemp_id.Text + "'");









                Interaction.MsgBox("The Data Has Been Updated in the Database.");
                usableselect.cleartext(this);
            }

        }

        private void Button2_Click(object sender, EventArgs e)
        {
            object rdo;

            if (rdomale.Checked == true)
            {
                rdo = "Male";
            }
            else
            {
                rdo = "Female";
            }

            if (rbdep1.Checked & cbocivil.Text == "Married")
            {
                publicvariable.taxid = "M1";
            }
            else if (rbdep2.Checked & cbocivil.Text == "Married")
            {
                publicvariable.taxid = "M2";
            }
            else if (rbdep3.Checked & cbocivil.Text == "Married")
            {
                publicvariable.taxid = "M3";
            }
            else if (rbdep4.Checked & cbocivil.Text == "Married")
            {
                publicvariable.taxid = "M4";
            }
            else if (rbdep0.Checked & cbocivil.Text == "Married")
            {
                publicvariable.taxid = "M";
            }

            if (rbdep1.Checked & cbocivil.Text == "Single")
            {
                publicvariable.taxid = "S1";
            }
            else if (rbdep2.Checked & cbocivil.Text == "Single")
            {
                publicvariable.taxid = "S2";
            }
            else if (rbdep3.Checked & cbocivil.Text == "Single")
            {
                publicvariable.taxid = "S3";
            }
            else if (rbdep4.Checked & cbocivil.Text == "Single")
            {
                publicvariable.taxid = "S4";
            }
            else if (rbdep0.Checked & cbocivil.Text == "Single")
            {
                publicvariable.taxid = "S";
            }


            crud.jokenupdate(Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("update tblemployee set EMPID = '" + txtemp_id.Text + "', FNAME = '" + txtfname.Text + "', LNAME = '" + txtlname.Text + "', MI = '" + txtmname.Text + "', AGE = '" + txtage.Text + "', GENDER = '", rdo), "', BDAY = '"), dtpbdate.Text), "', BPLACE = '"), txtbplace.Text), "', HEIGHT = '"), txtHeight.Text), "', WEIGHT = '"), txtweight.Text), "', CIVIL_STATUS = '"), cbocivil.Text), "', CONTACT = '"), txtContact.Text), "', RELIGION = '"), txtreligon.Text), "', SPOUSE = '"), txtnamSpouse.Text), "', SP_ADDRESS = '"), txtsadd.Text), "', CITIZENSHIP = '"), txtcitizen.Text), "', HIREDDATE = '"), dtpHiredate.Text), "', WORKSTATUS = '"), cboworkstat.Text), "', GPOSITION = '"), cbpositon.Text), "', TAXID = '"), publicvariable.taxid), "' where ID = "), Label21.Text), "")));






            crud.jokenupdate("update tblempbackgrd set EMPID = '" + txtemp_id.Text + "', MOTHER = '" + txtmothername.Text + "', M_ADDRESS = '" + txtmotheradd.Text + "', ELEMENTARY = '" + txtelem.Text + "', ELEMYEAR = '" + txtelem_year.Text + "', SECONDARY = '" + txthschool.Text + "', SECONDARY_YEAR = '" + txthschool_yeAR.Text + "', TERTIARY = '" + txtcollege.Text + "', TERTIARY_YEAR = '" + txtcollegeYear.Text + "', OTHERS = '" + txtothers.Text + "',  FATHER = '" + txtfathername.Text + "', F_ADDRESS = '" + txtfatheradd.Text + "', GLNO = '" + txtgl.Text + "', POLCL = '" + txtpc.Text + "',  NBICL = '" + txtnbic.Text + "' where BACKID = " + Label35.Text + "");




            Interaction.MsgBox("The Data Has Been Updated in the Database.");
            usableselect.cleartext(this);

        }

        private void txtHeight_TextChanged(object sender, EventArgs e)
        {
            if (!Information.IsNumeric(txtHeight.Text))
            {
                txtHeight.Text = null;
            }
            if (txtHeight.TextLength > 3)
            {
                txtHeight.Text = null;
            }
        }

        private void txtweight_TextChanged(object sender, EventArgs e)
        {
            if (!Information.IsNumeric(txtweight.Text))
            {
                txtContact.Text = null;
            }
            if (txtweight.TextLength > 3)
            {
                txtweight.Text = null;
            }
        }

        private void txtmname_TextChanged(object sender, EventArgs e)
        {
            if (txtmname.TextLength > 1)
            {
                txtmname.Text = null;
            }
        }

        private void frmIndividualprofile_Load(object sender, EventArgs e)
        {

        }

        private void dtpbdate_TextChanged(object sender, EventArgs e)
        {
            var offset = new DateTime(1, 1, 1);

            var dateOne = dtpbdate.Value;
            var dateTwo = DateTime.Now;

            var diff = dateTwo - dateOne;

            int years = (offset + diff).Year - 1;



            if (years < 18 & years < 50)
            {
                Interaction.MsgBox("Age requirement must be 18 - 50 years old!");
            }
            else
            {
                txtage.Text = years.ToString();
            }
        }

        private void dtpbdate_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
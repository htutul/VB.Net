﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace Ichiban
{
    [Microsoft.VisualBasic.CompilerServices.DesignerGenerated()]
    public partial class frmlogin : Form
    {

        // Form overrides dispose to clean up the component list.
        [DebuggerNonUserCode()]
        protected override void Dispose(bool disposing)
        {
            try
            {
                if (disposing && components is not null)
                {
                    components.Dispose();
                }
            }
            finally
            {
                base.Dispose(disposing);
            }
        }

        // Required by the Windows Form Designer
        private System.ComponentModel.IContainer components;

        // NOTE: The following procedure is required by the Windows Form Designer
        // It can be modified using the Windows Form Designer.  
        // Do not modify it using the code editor.
        [DebuggerStepThrough()]
        private void InitializeComponent()
        {
            Button1 = new Button();
            Button1.Click += new EventHandler(Button1_Click);
            txtusername = new TextBox();
            txtpassword = new TextBox();
            Button2 = new Button();
            Button2.Click += new EventHandler(Button2_Click);
            PictureBox1 = new PictureBox();
            Label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)PictureBox1).BeginInit();
            SuspendLayout();
            // 
            // Button1
            // 
            Button1.BackColor = Color.FromArgb(224, 224, 224);
            Button1.BackgroundImageLayout = ImageLayout.None;
            Button1.FlatAppearance.MouseDownBackColor = Color.FromArgb(128, 255, 128);
            Button1.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 255);
            Button1.FlatStyle = FlatStyle.Flat;
            Button1.Font = new Font("Microsoft Sans Serif", 12.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Button1.Location = new Point(362, 218);
            Button1.Name = "Button1";
            Button1.Size = new Size(88, 34);
            Button1.TabIndex = 1;
            Button1.Text = "Cancel";
            Button1.UseVisualStyleBackColor = false;
            // 
            // txtusername
            // 
            txtusername.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            txtusername.AutoCompleteSource = AutoCompleteSource.CustomSource;
            txtusername.Font = new Font("Microsoft Sans Serif", 12.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtusername.Location = new Point(113, 98);
            txtusername.Name = "txtusername";
            txtusername.Size = new Size(337, 26);
            txtusername.TabIndex = 2;
            // 
            // txtpassword
            // 
            txtpassword.Font = new Font("Microsoft Sans Serif", 12.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtpassword.Location = new Point(116, 172);
            txtpassword.Name = "txtpassword";
            txtpassword.Size = new Size(334, 26);
            txtpassword.TabIndex = 3;
            txtpassword.UseSystemPasswordChar = true;
            // 
            // Button2
            // 
            Button2.BackColor = Color.FromArgb(224, 224, 224);
            Button2.BackgroundImageLayout = ImageLayout.None;
            Button2.FlatAppearance.MouseDownBackColor = Color.FromArgb(128, 255, 128);
            Button2.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 255, 255);
            Button2.FlatStyle = FlatStyle.Flat;
            Button2.Font = new Font("Microsoft Sans Serif", 12.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Button2.Location = new Point(268, 218);
            Button2.Name = "Button2";
            Button2.Size = new Size(88, 34);
            Button2.TabIndex = 4;
            Button2.Text = "Sign In";
            Button2.UseVisualStyleBackColor = false;
            // 
            // PictureBox1
            // 
            PictureBox1.Dock = DockStyle.Fill;
            PictureBox1.Image = My.Resources.Resources.log14;
            PictureBox1.Location = new Point(0, 0);
            PictureBox1.Name = "PictureBox1";
            PictureBox1.Size = new Size(515, 287);
            PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            PictureBox1.TabIndex = 0;
            PictureBox1.TabStop = false;
            // 
            // Label1
            // 
            Label1.AutoSize = true;
            Label1.Font = new Font("Microsoft Sans Serif", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label1.Location = new Point(55, 12);
            Label1.Name = "Label1";
            Label1.Size = new Size(267, 24);
            Label1.TabIndex = 5;
            Label1.Text = "ICHIGAN SECURITY AGENCY";
            // 
            // frmlogin
            // 
            AutoScaleDimensions = new SizeF(6.0f, 13.0f);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(515, 287);
            Controls.Add(Label1);
            Controls.Add(Button2);
            Controls.Add(txtpassword);
            Controls.Add(txtusername);
            Controls.Add(Button1);
            Controls.Add(PictureBox1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "frmlogin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "frmlogin";
            ((System.ComponentModel.ISupportInitialize)PictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();

        }
        internal PictureBox PictureBox1;
        internal Button Button1;
        internal TextBox txtusername;
        internal TextBox txtpassword;
        internal Button Button2;
        internal Label Label1;
    }
}
﻿using System;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace Ichiban
{
    public partial class employee
    {

        private string sql;

        public employee()
        {
            InitializeComponent();
        }

        private void employee_Load(object sender, EventArgs e)
        {

            Timer1.Start();

            // jokenselect("SELECT EMPID AS [EMPLOYEE ID],(LNAME & ', ' &  FNAME   ) AS [EMPLOYEE NAME],GENDER,AGE,BDAY AS [BIRTHDAY],BPLACE AS [BIRTH PALCE],SP_ADDRESS AS [ADDRESS] FROM tblemployee where ASSIGN = NO")
            // filltable(dtgEmplist, "EmpInfo")
            load_basic_info();

            usableselect.jokenselect("SELECT tblemployee.*, tblempbackgrd.* FROM tblempbackgrd INNER JOIN tblemployee ON tblempbackgrd.EMPID = tblemployee.EMPID where WORKSTATUS = 'Active'");
            usableselect.filltable(DataGridView1, "EmpPic");

        }

        public void load_basic_info()
        {
            usableselect.jokenselect("SELECT COUNT(*) FROM tblemployee");
            usableselect.filltotal_employee();

            usableselect.jokenselect("SELECT COUNT(*) FROM tblemployee where WORKSTATUS = 'Active'");
            usableselect.filltotal_activeemployee();
            usableselect.jokenselect("SELECT COUNT(*) FROM tblemployee where WORKSTATUS = 'Inactive'");
            usableselect.filltotal_inactiveemployee();
            usableselect.jokenselect("SELECT COUNT(*) FROM tblemployee where ASSIGN = YES");
            usableselect.filltotal_onduty();

        }



        private void BTNNEW_Click(object sender, EventArgs e)
        {
            My.MyProject.Forms.newemployee.Show();
            Close();

        }


        private void dtgEmplist_DoubleClick(object sender, EventArgs e)
        {
            My.MyProject.Forms.newemployee.Show();
            My.MyProject.Forms.newemployee.txtemp_id.Text = Conversions.ToString(DataGridView1.CurrentRow.Cells[0].Value);

        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            Label3.Text = Conversions.ToString(DateAndTime.TimeOfDay);
            Label9.Text = Conversions.ToString(DateTime.Today);
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            if (lblEMployeeID.Text == "EMployeeID")
            {
                Interaction.MsgBox("Please Select employee to Deactivate!");
            }
            else
            {
                crud.jokenupdate("UPDATE tblemployee set WORKSTATUS='Inactive' where ID=" + Conversion.Val(lblEMployeeID.Text) + " ");
                employee_Load(sender, e);
                lblEMployeeID.Text = "EMployeeID";
            }

        }



        private void TXTSEARCH_TextChanged(object sender, EventArgs e)
        {
            usableselect.jokenselect("SELECT tblemployee.*, tblempbackgrd.* FROM tblempbackgrd INNER JOIN tblemployee ON tblempbackgrd.EMPID = tblemployee.EMPID WHERE tblemployee.EMPID LIKE '%" + TXTSEARCH.Text + "%' OR LNAME LIKE '%" + TXTSEARCH.Text + "%' OR FNAME LIKE '%" + TXTSEARCH.Text + "%' AND ASSIGN = NO");
            usableselect.filltable(DataGridView1, "EmpPic");
        }

        private void Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void DataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            My.MyProject.Forms.frmIndividualprofile.Show();

            {
                var withBlock = My.MyProject.Forms.frmIndividualprofile;



                withBlock.Label40.Text = DataGridView1.CurrentRow.Cells[0].Value.ToString();
                withBlock.Label35.Text = DataGridView1.CurrentRow.Cells[23].Value.ToString();

                withBlock.Label1.Text = DataGridView1.CurrentRow.Cells[1].Value.ToString();
                withBlock.txtemp_id.Text = DataGridView1.CurrentRow.Cells[1].Value.ToString();

                withBlock.txtlname.Text = DataGridView1.CurrentRow.Cells[2].Value.ToString();
                withBlock.txtfname.Text = DataGridView1.CurrentRow.Cells[3].Value.ToString();
                withBlock.txtmname.Text = DataGridView1.CurrentRow.Cells[4].Value.ToString();

                if (DataGridView1.CurrentRow.Cells[5].Value.ToString() == "Male")
                {
                    withBlock.rdomale.Select();
                }
                else
                {
                    withBlock.rdofemale.Select();
                }

                withBlock.txtage.Text = DataGridView1.CurrentRow.Cells[6].Value.ToString();
                withBlock.dtpbdate.Text = DataGridView1.CurrentRow.Cells[7].Value.ToString();
                withBlock.txtbplace.Text = DataGridView1.CurrentRow.Cells[8].Value.ToString();

                withBlock.txtHeight.Text = DataGridView1.CurrentRow.Cells[9].Value.ToString();
                withBlock.txtweight.Text = DataGridView1.CurrentRow.Cells[10].Value.ToString();
                withBlock.cbocivil.Text = DataGridView1.CurrentRow.Cells[11].Value.ToString();
                withBlock.txtContact.Text = DataGridView1.CurrentRow.Cells[12].Value.ToString();
                withBlock.txtreligon.Text = DataGridView1.CurrentRow.Cells[13].Value.ToString();
                withBlock.txtnamSpouse.Text = DataGridView1.CurrentRow.Cells[14].Value.ToString();
                withBlock.txtsadd.Text = DataGridView1.CurrentRow.Cells[15].Value.ToString();
                withBlock.txtcitizen.Text = DataGridView1.CurrentRow.Cells[16].Value.ToString();
                withBlock.dtpHiredate.Text = DataGridView1.CurrentRow.Cells[17].Value.ToString();
                withBlock.cboworkstat.Text = DataGridView1.CurrentRow.Cells[18].Value.ToString();
                withBlock.cbpositon.Text = DataGridView1.CurrentRow.Cells[19].Value.ToString();

                if (DataGridView1.CurrentRow.Cells[21].Value.ToString() == "Z")
                {
                    withBlock.cbocivil.Text = "Zero Exemption";
                    withBlock.rbdep0.Select();
                }
                else if (DataGridView1.CurrentRow.Cells[21].Value.ToString() == "S")
                {
                    withBlock.cbocivil.Text = "Single";
                    withBlock.rbdep0.Select();
                }
                else if (DataGridView1.CurrentRow.Cells[21].Value.ToString() == "M")
                {
                    withBlock.cbocivil.Text = "Single";
                    withBlock.rbdep0.Select();
                }
                else if (DataGridView1.CurrentRow.Cells[21].Value.ToString() == "S1")
                {
                    withBlock.cbocivil.Text = "Single";
                    withBlock.rbdep1.Select();
                }
                else if (DataGridView1.CurrentRow.Cells[21].Value.ToString() == "S2")
                {
                    withBlock.cbocivil.Text = "Single";
                    withBlock.rbdep2.Select();
                }
                else if (DataGridView1.CurrentRow.Cells[21].Value.ToString() == "S3")
                {
                    withBlock.cbocivil.Text = "Single";
                    withBlock.rbdep3.Select();
                }
                else if (DataGridView1.CurrentRow.Cells[21].Value.ToString() == "S4")
                {
                    withBlock.cbocivil.Text = "Single";
                    withBlock.rbdep4.Select();
                }
                else if (DataGridView1.CurrentRow.Cells[21].Value.ToString() == "M1")
                {
                    withBlock.cbocivil.Text = "Married";
                    withBlock.rbdep1.Select();
                }
                else if (DataGridView1.CurrentRow.Cells[21].Value.ToString() == "M2")
                {
                    withBlock.cbocivil.Text = "Married";
                    withBlock.rbdep2.Select();
                }
                else if (DataGridView1.CurrentRow.Cells[21].Value.ToString() == "M3")
                {
                    withBlock.cbocivil.Text = "Married";
                    withBlock.rbdep3.Select();
                }
                else if (DataGridView1.CurrentRow.Cells[21].Value.ToString() == "M4")
                {
                    withBlock.cbocivil.Text = "Married";
                    withBlock.rbdep4.Select();
                }


                withBlock.txtmothername.Text = DataGridView1.CurrentRow.Cells[25].Value.ToString();
                withBlock.txtmotheradd.Text = DataGridView1.CurrentRow.Cells[26].Value.ToString();
                withBlock.txtfathername.Text = DataGridView1.CurrentRow.Cells[27].Value.ToString();
                withBlock.txtfatheradd.Text = DataGridView1.CurrentRow.Cells[28].Value.ToString();
                withBlock.txtelem.Text = DataGridView1.CurrentRow.Cells[29].Value.ToString();
                withBlock.txtelem_year.Text = DataGridView1.CurrentRow.Cells[30].Value.ToString();
                withBlock.txthschool.Text = DataGridView1.CurrentRow.Cells[31].Value.ToString();
                withBlock.txthschool_yeAR.Text = DataGridView1.CurrentRow.Cells[32].Value.ToString();
                withBlock.txtcollege.Text = DataGridView1.CurrentRow.Cells[33].Value.ToString();
                withBlock.txtcollegeYear.Text = DataGridView1.CurrentRow.Cells[34].Value.ToString();

                withBlock.txtothers.Text = DataGridView1.CurrentRow.Cells[37].Value.ToString();
                withBlock.txtgl.Text = DataGridView1.CurrentRow.Cells[40].Value.ToString();
                withBlock.txtpc.Text = DataGridView1.CurrentRow.Cells[41].Value.ToString();
                withBlock.txtnbic.Text = DataGridView1.CurrentRow.Cells[42].Value.ToString();

                withBlock.txtwecom1.Text = DataGridView1.CurrentRow.Cells[43].Value.ToString();
                withBlock.txtwecom2.Text = DataGridView1.CurrentRow.Cells[44].Value.ToString();
                withBlock.txtwecom3.Text = DataGridView1.CurrentRow.Cells[45].Value.ToString();
                withBlock.txtwepos1.Text = DataGridView1.CurrentRow.Cells[46].Value.ToString();
                withBlock.txtwepos2.Text = DataGridView1.CurrentRow.Cells[47].Value.ToString();
                withBlock.txtwepos3.Text = DataGridView1.CurrentRow.Cells[48].Value.ToString();
                withBlock.txtwedate1.Text = DataGridView1.CurrentRow.Cells[49].Value.ToString();
                withBlock.txtwedate2.Text = DataGridView1.CurrentRow.Cells[50].Value.ToString();
                withBlock.txtwedate3.Text = DataGridView1.CurrentRow.Cells[51].Value.ToString();

                withBlock.txtPHIC.Text = DataGridView1.CurrentRow.Cells[23].Value.ToString();
                withBlock.txtHDMF.Text = DataGridView1.CurrentRow.Cells[24].Value.ToString();



                sql = "select picfile from tblemppic where empid ='" + withBlock.Label1.Text + "'";
                jokensqlselect.jokenfindthis(sql);
                jokensqlselect.checkresult("picload");

            }
        }

        private void DataGridView1_Click(object sender, EventArgs e)
        {
            lblEMployeeID.Text = Conversions.ToString(DataGridView1.CurrentRow.Cells[0].Value);
        }
    }
}
﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace Ichiban
{
    [Microsoft.VisualBasic.CompilerServices.DesignerGenerated()]
    public partial class Utilities : Form
    {

        // Form overrides dispose to clean up the component list.
        [DebuggerNonUserCode()]
        protected override void Dispose(bool disposing)
        {
            try
            {
                if (disposing && components is not null)
                {
                    components.Dispose();
                }
            }
            finally
            {
                base.Dispose(disposing);
            }
        }

        // Required by the Windows Form Designer
        private System.ComponentModel.IContainer components;

        // NOTE: The following procedure is required by the Windows Form Designer
        // It can be modified using the Windows Form Designer.  
        // Do not modify it using the code editor.
        [DebuggerStepThrough()]
        private void InitializeComponent()
        {
            GroupBox1 = new GroupBox();
            Button2 = new Button();
            Button2.Click += new EventHandler(Button2_Click);
            Button1 = new Button();
            Button1.Click += new EventHandler(Button1_Click);
            GroupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // GroupBox1
            // 
            GroupBox1.Controls.Add(Button2);
            GroupBox1.Controls.Add(Button1);
            GroupBox1.Font = new Font("Microsoft Sans Serif", 12.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            GroupBox1.ForeColor = Color.Red;
            GroupBox1.Location = new Point(12, 12);
            GroupBox1.Name = "GroupBox1";
            GroupBox1.Size = new Size(321, 163);
            GroupBox1.TabIndex = 0;
            GroupBox1.TabStop = false;
            GroupBox1.Text = "Database Backup/Restore Utilities";
            // 
            // Button2
            // 
            Button2.Location = new Point(64, 94);
            Button2.Name = "Button2";
            Button2.Size = new Size(186, 63);
            Button2.TabIndex = 3;
            Button2.Text = "Restore Backup";
            Button2.UseVisualStyleBackColor = true;
            // 
            // Button1
            // 
            Button1.Location = new Point(64, 25);
            Button1.Name = "Button1";
            Button1.Size = new Size(186, 63);
            Button1.TabIndex = 2;
            Button1.Text = "Create Backup";
            Button1.UseVisualStyleBackColor = true;
            // 
            // Utilities
            // 
            AutoScaleDimensions = new SizeF(6.0f, 13.0f);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(346, 197);
            Controls.Add(GroupBox1);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Name = "Utilities";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Utilities";
            GroupBox1.ResumeLayout(false);
            ResumeLayout(false);

        }
        internal GroupBox GroupBox1;
        internal Button Button2;
        internal Button Button1;
    }
}
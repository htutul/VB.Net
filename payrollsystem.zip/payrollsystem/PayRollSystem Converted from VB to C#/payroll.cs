﻿using System;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace Ichiban
{
    public partial class payroll
    {

        private decimal empTotaltax, empExcesstax, temptax, addtax, finaltax;

        public payroll()
        {
            InitializeComponent();
        }

        private void txtClientRate_TextChanged(object sender, EventArgs e)
        {
            // Agency Fee
            txtAgencyFee.Text = (Conversion.Val(txtClientRate.Text) * 0.2d).ToString();
            // By Monthly Rate
            txtByMonthlyRate.Text = ((Conversion.Val(txtClientRate.Text) - Conversion.Val(txtAgencyFee.Text)) / 2d).ToString();
            // Basic Pay
            txtbasicPay.Text = (Conversion.Val(txtByMonthlyRate.Text) / 15d).ToString();
            txtbasicPay.Text = Strings.FormatNumber(txtbasicPay.Text, 2);
            // Hourly Rate
            txtHourlyRate.Text = (Conversion.Val(txtbasicPay.Text) / 8d).ToString();

        }

        private void Button2_Click(object sender, EventArgs e)
        {

            int salary = (int)Math.Round(Conversion.Val(txtGrossPay.Text) * 2d);
            // MsgBox(salary)
            int EE, ER;
            if (salary >= 1000 & salary < 1250)
            {
                EE = (int)Math.Round(36.3);
                ER = (int)Math.Round(83.7);
                txtSSS.Text = (EE / 2d).ToString();
                txtSSS_ER.Text = (ER / 2d).ToString();
            }

            else if (salary >= 1250 & salary < 1750)
            {
                EE = (int)Math.Round(54.5);
                ER = (int)Math.Round(120.5);
                txtSSS.Text = (EE / 2d).ToString();
                txtSSS_ER.Text = (ER / 2d).ToString();
            }
            else if (salary >= 1750 & salary < 2250)
            {
                EE = (int)Math.Round(72.7);
                ER = (int)Math.Round(157.3);
                txtSSS.Text = (EE / 2d).ToString();
                txtSSS_ER.Text = (ER / 2d).ToString();
            }
            else if (salary >= 2250 & salary < 2750)
            {
                EE = (int)Math.Round(90.8);
                ER = (int)Math.Round(194.2);
                txtSSS.Text = (EE / 2d).ToString();
                txtSSS_ER.Text = (ER / 2d).ToString();
            }
            else if (salary >= 2750 & salary < 3250)
            {
                EE = 109;
                ER = 231;
                txtSSS.Text = (EE / 2d).ToString();
                txtSSS_ER.Text = (ER / 2d).ToString();
            }
            else if (salary >= 3250 & salary < 3750)
            {
                EE = (int)Math.Round(127.2);
                ER = (int)Math.Round(267.8);
                txtSSS.Text = (EE / 2d).ToString();
                txtSSS_ER.Text = (ER / 2d).ToString();
            }
            else if (salary >= 3750 & salary < 4250)
            {
                EE = (int)Math.Round(145.3);
                ER = (int)Math.Round(304.7);
                txtSSS.Text = (EE / 2d).ToString();
                txtSSS_ER.Text = (ER / 2d).ToString();
            }
            else if (salary >= 4250 & salary < 4750)
            {
                EE = (int)Math.Round(163.5);
                ER = (int)Math.Round(341.5);
                txtSSS.Text = (EE / 2d).ToString();
                txtSSS_ER.Text = (ER / 2d).ToString();
            }
            else if (salary >= 4750 & salary < 5250)
            {
                EE = (int)Math.Round(181.7);
                ER = (int)Math.Round(378.3);
                txtSSS.Text = (EE / 2d).ToString();
                txtSSS_ER.Text = (ER / 2d).ToString();
            }
            else if (salary >= 5250 & salary < 5750)
            {
                EE = (int)Math.Round(199.8);
                ER = (int)Math.Round(415.2);
                txtSSS.Text = (EE / 2d).ToString();
                txtSSS_ER.Text = (ER / 2d).ToString();
            }
            else if (salary >= 5750 & salary < 6250)
            {
                EE = 218;
                ER = 452;
                txtSSS.Text = (EE / 2d).ToString();
                txtSSS_ER.Text = (ER / 2d).ToString();
            }
            else if (salary >= 6250 & salary < 6750)
            {
                EE = (int)Math.Round(236.2);
                ER = (int)Math.Round(488.8);
                txtSSS.Text = (EE / 2d).ToString();
                txtSSS_ER.Text = (ER / 2d).ToString();
            }
            else if (salary >= 6750 & salary < 7250)
            {
                EE = (int)Math.Round(254.3);
                ER = (int)Math.Round(525.7);
                txtSSS.Text = (EE / 2d).ToString();
                txtSSS_ER.Text = (ER / 2d).ToString();
            }
            else if (salary >= 7250 & salary < 7750)
            {
                EE = (int)Math.Round(272.5);
                ER = (int)Math.Round(562.5);
                txtSSS.Text = (EE / 2d).ToString();
                txtSSS_ER.Text = (ER / 2d).ToString();
            }
            else if (salary >= 7750 & salary < 8250)
            {
                EE = (int)Math.Round(290.7);
                ER = (int)Math.Round(599.3);
                txtSSS.Text = (EE / 2d).ToString();
                txtSSS_ER.Text = (ER / 2d).ToString();
            }
            else if (salary >= 8250 & salary < 8750)
            {
                EE = (int)Math.Round(308.8);
                ER = (int)Math.Round(636.2);
                txtSSS.Text = (EE / 2d).ToString();
                txtSSS_ER.Text = (ER / 2d).ToString();
            }
            else if (salary >= 8750 & salary < 9250)
            {
                EE = 327;
                ER = 673;
                txtSSS.Text = (EE / 2d).ToString();
                txtSSS_ER.Text = (ER / 2d).ToString();
            }
            else if (salary >= 9250 & salary < 9750)
            {
                EE = (int)Math.Round(345.2);
                ER = (int)Math.Round(709.8);
                txtSSS.Text = (EE / 2d).ToString();
                txtSSS_ER.Text = (ER / 2d).ToString();
            }
            else if (salary >= 9750 & salary < 10250)
            {
                EE = (int)Math.Round(363.3);
                ER = (int)Math.Round(746.7);
                txtSSS.Text = (EE / 2d).ToString();
                txtSSS_ER.Text = (ER / 2d).ToString();
            }
            else if (salary >= 10250 & salary < 10750)
            {
                EE = (int)Math.Round(381.5);
                ER = (int)Math.Round(783.5);
                txtSSS.Text = (EE / 2d).ToString();
                txtSSS_ER.Text = (ER / 2d).ToString();
            }
            else if (salary >= 10750 & salary < 11250)
            {
                EE = (int)Math.Round(399.7);
                ER = (int)Math.Round(820.3);
                txtSSS.Text = (EE / 2d).ToString();
                txtSSS_ER.Text = (ER / 2d).ToString();
            }
            else if (salary >= 11250 & salary < 11750)
            {
                EE = (int)Math.Round(417.8);
                ER = (int)Math.Round(857.2);
                txtSSS.Text = (EE / 2d).ToString();
                txtSSS_ER.Text = (ER / 2d).ToString();
            }
            else if (salary >= 11750 & salary < 12250)
            {
                EE = (int)Math.Round(436.0);
                ER = (int)Math.Round(894.0);
                txtSSS.Text = (EE / 2d).ToString();
                txtSSS_ER.Text = (ER / 2d).ToString();
            }
            else if (salary >= 12250 & salary < 12750)
            {
                EE = (int)Math.Round(454.2);
                ER = (int)Math.Round(930.8);
                txtSSS.Text = (EE / 2d).ToString();
                txtSSS_ER.Text = (ER / 2d).ToString();
            }
            else if (salary >= 12750 & salary < 13250)
            {
                EE = (int)Math.Round(472.3);
                ER = (int)Math.Round(967.7);
                txtSSS.Text = (EE / 2d).ToString();
                txtSSS_ER.Text = (ER / 2d).ToString();
            }
            else if (salary >= 13250 & salary < 13750)
            {
                EE = (int)Math.Round(490.5);
                ER = (int)Math.Round(1004.5);
                txtSSS.Text = (EE / 2d).ToString();
                txtSSS_ER.Text = (ER / 2d).ToString();
            }
            else if (salary >= 13750 & salary < 14250)
            {
                EE = (int)Math.Round(508.7);
                ER = (int)Math.Round(1041.3);
                txtSSS.Text = (EE / 2d).ToString();
                txtSSS_ER.Text = (ER / 2d).ToString();
            }
            else if (salary >= 14250 & salary < 14750)
            {
                EE = (int)Math.Round(526.8);
                ER = (int)Math.Round(1078.2);
                txtSSS.Text = (EE / 2d).ToString();
                txtSSS_ER.Text = (ER / 2d).ToString();
            }
            else if (salary >= 14750 & salary < 15250)
            {
                EE = 545;
                ER = 1135;
                txtSSS.Text = (EE / 2d).ToString();
                txtSSS_ER.Text = (ER / 2d).ToString();
            }
            else if (salary >= 15250 & salary < 15750)
            {
                EE = (int)Math.Round(563.2);
                ER = (int)Math.Round(1171.8);
                txtSSS.Text = (EE / 2d).ToString();
                txtSSS_ER.Text = (ER / 2d).ToString();
            }
            else if (salary >= 15750)
            {
                EE = (int)Math.Round(581.3);
                ER = (int)Math.Round(1208.7);
                txtSSS.Text = (EE / 2d).ToString();
                txtSSS_ER.Text = (ER / 2d).ToString();
            }

        }

        private void txtNoHoursWork_TextChanged(object sender, EventArgs e)
        {
            // Gross Salary
            GrossSalary.Text = (Conversion.Val(txtHourlyRate.Text) * Conversion.Val(txtNoHoursWork.Text)).ToString();
            // GrossSalary.Text = FormatNumber(GrossSalary.Text, 2)
            // Gross Pay
            // txtGrossPay.Text = Val(GrossSalary.Text)
            // txtGrossPay.Text = FormatNumber(txtGrossPay.Text, 2)
            if (string.IsNullOrEmpty(txtNoHoursWork.Text))
            {
                txtSSS.Text = "0.00";
            }
            if (!Information.IsNumeric(txtNoHoursWork.Text))
            {
                txtNoHoursWork.Text = null;
            }
        }

        private void txtAllowances_TextChanged(object sender, EventArgs e)
        {
            // Gross Pay
            txtGrossPay.Text = (Conversion.Val(GrossSalary.Text) + Conversion.Val(txtAllowances.Text)).ToString();
            // txtGrossPay.Text = FormatNumber(txtGrossPay.Text, 2)
        }

        private void txtAdjustments_TextChanged(object sender, EventArgs e)
        {
            // Gross Pay
            txtGrossPay.Text = (Conversion.Val(txtAdjustments.Text) + Conversion.Val(txtAllowances.Text) + Conversion.Val(GrossSalary.Text)).ToString();
            // txtGrossPay.Text = FormatNumber(GrossSalary.Text, 2)
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            My.MyProject.Forms.popup.Show();
        }

        private void GrossSalary_TextChanged(object sender, EventArgs e)
        {
            // txtPagibig.Text = Val(GrossSalary.Text) * 0.02
            txtGrossPay.Text = Math.Round(Conversion.Val(GrossSalary.Text) + Conversion.Val(txtAllowances.Text) + Conversion.Val(txtAdjustments.Text), 2).ToString();


        }

        private void Button3_Click(object sender, EventArgs e)
        {
            int salary = (int)Math.Round(Conversion.Val(txtGrossPay.Text) * 2d);
            int PHIL_EE, PHIL_ER;
            if (salary < 9000)
            {
                PHIL_EE = 100;
                PHIL_ER = 100;
                txtPhilhealth.Text = (PHIL_EE / 2d).ToString();
                txtPHIL_ER.Text = (PHIL_ER / 2d).ToString();
            }
            else if (salary >= 9000 & salary < 10000)
            {
                PHIL_EE = (int)Math.Round(112.5);
                PHIL_ER = (int)Math.Round(112.5);
                txtPhilhealth.Text = (PHIL_EE / 2d).ToString();
                txtPHIL_ER.Text = (PHIL_ER / 2d).ToString();
            }
            else if (salary >= 10000 & salary < 11000)
            {
                PHIL_EE = 125;
                PHIL_ER = 125;
                txtPhilhealth.Text = (PHIL_EE / 2d).ToString();
                txtPHIL_ER.Text = (PHIL_ER / 2d).ToString();
            }
            else if (salary >= 11000 & salary < 12000)
            {
                PHIL_EE = (int)Math.Round(137.5);
                PHIL_ER = (int)Math.Round(137.5);
                txtPhilhealth.Text = (PHIL_EE / 2d).ToString();
                txtPHIL_ER.Text = (PHIL_ER / 2d).ToString();
            }
            else if (salary >= 12000 & salary < 13000)
            {
                PHIL_EE = 150;
                PHIL_ER = 150;
                txtPhilhealth.Text = (PHIL_EE / 2d).ToString();
                txtPHIL_ER.Text = (PHIL_ER / 2d).ToString();
            }
            else if (salary >= 13000 & salary < 14000)
            {
                PHIL_EE = (int)Math.Round(162.5);
                PHIL_ER = (int)Math.Round(162.5);
                txtPhilhealth.Text = (PHIL_EE / 2d).ToString();
                txtPHIL_ER.Text = (PHIL_ER / 2d).ToString();
            }
            else if (salary >= 14000 & salary < 15000)
            {
                PHIL_EE = 175;
                PHIL_ER = 175;
                txtPhilhealth.Text = (PHIL_EE / 2d).ToString();
                txtPHIL_ER.Text = (PHIL_ER / 2d).ToString();
            }
            else if (salary >= 15000 & salary < 16000)
            {
                PHIL_EE = (int)Math.Round(187.5);
                PHIL_ER = (int)Math.Round(187.5);
                txtPhilhealth.Text = (PHIL_EE / 2d).ToString();
                txtPHIL_ER.Text = (PHIL_ER / 2d).ToString();

            }
        }

        private void txtGrossPay_TextChanged(object sender, EventArgs e)
        {
            Button2_Click(sender, e);
            Button3_Click(sender, e);
            Button4_Click(sender, e);
            Button5_Click(sender, e);
        }



        private void Button4_Click(object sender, EventArgs e)
        {
            int RESULT = (int)Math.Round(Conversion.Val(txtGrossPay.Text) * 2d);
            int HDMF_EE, HDMF_ER;

            // 750 is derived from 1500 earnings per month divided by two'
            if (RESULT <= 750) // 750 is derived from 1500'
            {
                HDMF_EE = (int)Math.Round(RESULT * 0.01d);
                HDMF_ER = (int)Math.Round(RESULT * 0.02d);
                txtPagibig.Text = (HDMF_EE / 2d).ToString();
                txtPGIBIG_ER.Text = (HDMF_ER / 2d).ToString();
            }

            else if (RESULT > 750)
            {
                HDMF_EE = (int)Math.Round(RESULT * 0.02d);
                HDMF_ER = (int)Math.Round(RESULT * 0.02d);
                txtPagibig.Text = (HDMF_EE / 2d).ToString();
                txtPGIBIG_ER.Text = (HDMF_ER / 2d).ToString();

            }
        }

        private void txtSSS_TextChanged(object sender, EventArgs e)
        {

            txttotalDeductions.Text = (Conversion.Val(txtSSS.Text) + Conversion.Val(txtPagibig.Text) + Conversion.Val(txtPhilhealth.Text) + Conversion.Val(txtWtax.Text) + Conversion.Val(txtSSSLoans.Text) + Conversion.Val(txtOtherLoans.Text) + Conversion.Val(txtPagibigLoans.Text)).ToString();
            txtNetIncome.Text = (Conversion.Val(txtGrossPay.Text) - Conversion.Val(txttotalDeductions.Text)).ToString();
        }

        private void txtPagibig_TextChanged(object sender, EventArgs e)
        {



            txttotalDeductions.Text = (Conversion.Val(txtSSS.Text) + Conversion.Val(txtPagibig.Text) + Conversion.Val(txtPhilhealth.Text) + Conversion.Val(txtWtax.Text) + Conversion.Val(txtSSSLoans.Text) + Conversion.Val(txtOtherLoans.Text) + Conversion.Val(txtPagibigLoans.Text)).ToString();
            txtNetIncome.Text = (Conversion.Val(txtGrossPay.Text) - Conversion.Val(txttotalDeductions.Text)).ToString();


        }

        private void txtPhilhealth_TextChanged(object sender, EventArgs e)
        {
            txttotalDeductions.Text = (Conversion.Val(txtSSS.Text) + Conversion.Val(txtPagibig.Text) + Conversion.Val(txtPhilhealth.Text) + Conversion.Val(txtWtax.Text) + Conversion.Val(txtSSSLoans.Text) + Conversion.Val(txtOtherLoans.Text) + Conversion.Val(txtPagibigLoans.Text)).ToString();
            txtNetIncome.Text = (Conversion.Val(txtGrossPay.Text) - Conversion.Val(txttotalDeductions.Text)).ToString();
        }

        private void txtWtax_TextChanged(object sender, EventArgs e)
        {
            txttotalDeductions.Text = (Conversion.Val(txtSSS.Text) + Conversion.Val(txtPagibig.Text) + Conversion.Val(txtPhilhealth.Text) + Conversion.Val(txtWtax.Text) + Conversion.Val(txtSSSLoans.Text) + Conversion.Val(txtOtherLoans.Text) + Conversion.Val(txtPagibigLoans.Text)).ToString();
            txtNetIncome.Text = (Conversion.Val(txtGrossPay.Text) - Conversion.Val(txttotalDeductions.Text)).ToString();


        }

        private void txtSSSLoans_TextChanged(object sender, EventArgs e)
        {
            txttotalDeductions.Text = (Conversion.Val(txtSSS.Text) + Conversion.Val(txtPagibig.Text) + Conversion.Val(txtPhilhealth.Text) + Conversion.Val(txtWtax.Text) + Conversion.Val(txtSSSLoans.Text) + Conversion.Val(txtOtherLoans.Text) + Conversion.Val(txtPagibigLoans.Text)).ToString();
            txtNetIncome.Text = (Conversion.Val(txtGrossPay.Text) - Conversion.Val(txttotalDeductions.Text)).ToString();
        }

        private void txtOtherLoans_TextChanged(object sender, EventArgs e)
        {
            txttotalDeductions.Text = (Conversion.Val(txtSSS.Text) + Conversion.Val(txtPagibig.Text) + Conversion.Val(txtPhilhealth.Text) + Conversion.Val(txtWtax.Text) + Conversion.Val(txtSSSLoans.Text) + Conversion.Val(txtOtherLoans.Text) + Conversion.Val(txtPagibigLoans.Text)).ToString();
            txtNetIncome.Text = (Conversion.Val(txtGrossPay.Text) - Conversion.Val(txttotalDeductions.Text)).ToString();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(payEmpID.Text))
            {
                Interaction.MsgBox("Please select Guard.");
            }
            else
            {
                try
                {
                    string sql;

                    sql = "select * from tblpayroll where PAYROLLID = '" + lblpayrolid.Text + "' AND EMPID = '" + payEmpID.Text + "'";
                    jokensqlselect.jokenfindthis(sql);
                    jokensqlselect.checkresult("Payroll");
                }

                catch (Exception ex)
                {
                    Interaction.MsgBox(ex.Message);
                }
                Close();

            }



        }





        private void Button5_Click(object sender, EventArgs e)
        {

            if (publicvariable.emptaxid == "Z")
            {

                empTotaltax = (decimal)(Conversion.Val(txtGrossPay.Text) - (Conversion.Val(txtSSS.Text) + Conversion.Val(txtPagibig.Text) + Conversions.ToDouble(txtPhilhealth.Text)));

                if (empTotaltax > 5833m & empTotaltax < 10417m)
                {

                    temptax = 937.5m;
                    empExcesstax = empTotaltax - 5833m;

                    addtax = (decimal)((double)empExcesstax * 0.25d);

                    finaltax = (temptax + addtax) / 2m;

                    txtWtax.Text = finaltax.ToString();
                }

                else if (empTotaltax < 5833m & empTotaltax > 2917m)
                {

                    temptax = 354.17m;
                    empExcesstax = empTotaltax - 2917m;

                    addtax = (decimal)((double)empExcesstax * 0.2d);

                    finaltax = (temptax + addtax) / 2m;

                    txtWtax.Text = finaltax.ToString();
                }

                else
                {
                    finaltax = 0m;
                    txtWtax.Text = finaltax.ToString();

                }
            }


            else if (publicvariable.emptaxid == "S" | publicvariable.emptaxid == "M")
            {


                if (empTotaltax > 5000m & empTotaltax < 7917m)
                {

                    temptax = 354.17m;
                    empExcesstax = empTotaltax - 5000m;

                    addtax = (decimal)((double)empExcesstax * 0.2d);

                    finaltax = (temptax + addtax) / 2m;

                    txtWtax.Text = finaltax.ToString();
                }

                else if (empTotaltax < 3333m & empTotaltax > 5000m)
                {

                    temptax = 104.17m;
                    empExcesstax = empTotaltax - 3333m;

                    addtax = (decimal)((double)empExcesstax * 0.15d);

                    finaltax = (temptax + addtax) / 2m;

                    txtWtax.Text = finaltax.ToString();
                }
                else
                {

                    finaltax = 50m;
                    txtWtax.Text = finaltax.ToString();

                }
            }


            else if (publicvariable.emptaxid == "S1" | publicvariable.emptaxid == "M1")
            {


                if (empTotaltax > 6250m & empTotaltax < 7083m)
                {

                    temptax = 0m;
                    empExcesstax = empTotaltax - 6250m;

                    addtax = (decimal)((double)empExcesstax * 0.05d);

                    finaltax = (temptax + addtax) / 2m;

                    txtWtax.Text = finaltax.ToString();
                }

                else
                {

                    finaltax = 75m;
                    txtWtax.Text = finaltax.ToString();

                }
            }

            else if (publicvariable.emptaxid == "S2" | publicvariable.emptaxid == "M2")
            {


                if (empTotaltax > 8333m & empTotaltax < 9167m)
                {

                    temptax = 0m;
                    empExcesstax = empTotaltax - 8333m;

                    addtax = (decimal)((double)empExcesstax * 0.05d);

                    finaltax = (temptax + addtax) / 2m;

                    txtWtax.Text = finaltax.ToString();
                }

                else
                {

                    finaltax = 100m;
                    txtWtax.Text = finaltax.ToString();

                }
            }

            else if (publicvariable.emptaxid == "S3" | publicvariable.emptaxid == "M3")
            {


                if (empTotaltax > 10417m & empTotaltax < 11250m)
                {

                    temptax = 0m;
                    empExcesstax = empTotaltax - 10417m;

                    addtax = (decimal)((double)empExcesstax * 0.05d);

                    finaltax = (temptax + addtax) / 2m;

                    txtWtax.Text = finaltax.ToString();
                }

                else
                {

                    finaltax = 125m;
                    txtWtax.Text = finaltax.ToString();

                }
            }

            else if (publicvariable.emptaxid == "S4" | publicvariable.emptaxid == "M4")
            {


                if (empTotaltax > 12500m & empTotaltax < 13333m)
                {

                    temptax = 0m;
                    empExcesstax = empTotaltax - 12500m;

                    addtax = (decimal)((double)empExcesstax * 0.05d);

                    finaltax = (temptax + addtax) / 2m;

                    txtWtax.Text = finaltax.ToString();
                }

                else
                {

                    finaltax = 150m;
                    txtWtax.Text = finaltax.ToString();

                }


            }
        }



        private void btncancel_Click(object sender, EventArgs e)
        {
            My.MyProject.Forms.Form1.BringToFront();

            Close();

        }

        private void txtPagibigLoans_TextChanged(object sender, EventArgs e)
        {
            txttotalDeductions.Text = (Conversion.Val(txtSSS.Text) + Conversion.Val(txtPagibig.Text) + Conversion.Val(txtPhilhealth.Text) + Conversion.Val(txtWtax.Text) + Conversion.Val(txtSSSLoans.Text) + Conversion.Val(txtOtherLoans.Text) + Conversion.Val(txtPagibigLoans.Text)).ToString();
            txtNetIncome.Text = (Conversion.Val(txtGrossPay.Text) - Conversion.Val(txttotalDeductions.Text)).ToString();

        }


        private void payroll_Load(object sender, EventArgs e)
        {

            // Dim Msg, Number, StartDate As String   'Declare variables.

            // Dim Months As Double
            // Dim SecondDate As Date
            // Dim IntervalType As DateInterval

            // IntervalType = DateInterval.Month   ' Specifies months as interval.

            // StartDate = InputBox("Enter a date")
            // SecondDate = CDate(StartDate)
            // Number = InputBox("Enter number of months to add")
            // Months = Val(Number)
            // Msg = "New date: " & DateAdd(IntervalType, Months, SecondDate)
            // MsgBox(Msg)

            // Dim offset = New Date(1, 1, 1)
            // Dim dateOne = DateTimePicker1.Value
            // Dim dateTwo = DateTimePicker2.Value
            // Dim diff As TimeSpan = dateTwo - dateOne
            // Dim years = (offset + diff).Year - 1
            // Dim months = (dateTwo.Month - dateOne.Month) + 12 * (dateTwo.Year - dateOne.Year)
            // Dim days = diff.Days
            // TxtYear.Text = years.ToString
            // TxtMonth.Text = months.ToString
            // TxtDays.Text = days.ToString
        }

        private void dtpPeriodStart_TextChanged(object sender, EventArgs e)
        {
            if (dtpPeriodStart.Value.Day <= 15)
            {

                int diffdate;

                diffdate = 15 - dtpPeriodStart.Value.Day;
                dtpPeriodEnd.Value = dtpPeriodStart.Value.AddDays(diffdate);

                lblpayrolid.Text = "ICHI" + dtpPeriodEnd.Value.Month + dtpPeriodEnd.Value.Day + dtpPeriodEnd.Value.Year;
            }

            else
            {
                int diffdate;

                diffdate = 30 - dtpPeriodStart.Value.Day;
                dtpPeriodEnd.Value = dtpPeriodStart.Value.AddDays(diffdate);

                lblpayrolid.Text = "ICHI" + dtpPeriodEnd.Value.Month + dtpPeriodEnd.Value.Day + dtpPeriodEnd.Value.Year;

            }
        }
    }
}
﻿using System;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace Ichiban
{
    public partial class client
    {
        public client()
        {
            InitializeComponent();
        }


        private void client_Load(object sender, EventArgs e)
        {
            LOAD_CLIENT();
        }

        public void LOAD_CLIENT()
        {

            usableselect.jokenselect("SELECT id,CLIENTID as [CLIENT ID], CL_NAME as [CLIENT NAME], CL_ADDRESS AS [ADDRESS], CL_RATE AS [RATE], START_DATE AS [START DATE], END_DATE AS [END DATE] FROM tblclient");
            usableselect.filltable(DataGridView2, "EmpInfo");

            usableselect.jokenselect("select id, CL_NAME as [CLIENT NAME], START_DATE AS [START DATE],  END_DATE AS [END DATE],  datediff ('d', #10/14/2014#, end_date  ) as [Days Left] from tblclient where datediff ('D', #10/14/2014#, end_date ) < 15 and datediff ('D', #" + Conversions.ToString(DateTime.Now) + "#, end_date ) > 0");
            usableselect.filltable(DataGridView1, "EmpInfo");



        }



        private void txtClinetName_TextChanged(object sender, EventArgs e)
        {
            LBLCLIENTID.Text = txtClinetName.Text + "-" + (678 + 3);

        }

        private void btnClientsave_Click(object sender, EventArgs e)
        {
            if (btnClientsave.Text == "New")
            {

                btnClientsave.Text = "Save";
                usableselect.cleartext(gbclientinfo);
            }

            else
            {

                btnClientsave.Text = "New";

                if (string.IsNullOrEmpty(txtClinetName.Text))
                {

                    Interaction.MsgBox("Please fill up Client Name.");
                }

                else
                {

                    string sql;
                    sql = "select * from tblclient where CLIENTID = '" + LBLCLIENTID.Text + "'";
                    jokensqlselect.jokenfindthis(sql);
                    jokensqlselect.Checkclient("client");

                    usableselect.cleartext(gbclientinfo);
                    LOAD_CLIENT();

                }

            }
        }

        private void DataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            ID.Text = Conversions.ToString(DataGridView2.CurrentRow.Cells[0].Value);
            LBLCLIENTID.Text = DataGridView2.CurrentRow.Cells[1].Value.ToString();
            txtClinetName.Text = DataGridView2.CurrentRow.Cells[2].Value.ToString();
            txtClientadd.Text = DataGridView2.CurrentRow.Cells[3].Value.ToString();
            txtrate.Text = Conversions.ToString(DataGridView2.CurrentRow.Cells[4].Value);

            strtdate.Value = Conversions.ToDate(DataGridView2.CurrentRow.Cells[5].Value);
            endDate.Value = Conversions.ToDate(DataGridView2.CurrentRow.Cells[6].Value);

        }


        private void btnUpdateClient_Click(object sender, EventArgs e)
        {
            if (ID.Text == "ID")
            {
                Interaction.MsgBox("Please select a client to modify!");
            }
            else
            {
                crud.jokenupdate("update tblclient set CL_NAME ='" + txtClinetName.Text + "', CL_ADDRESS ='" + txtClientadd.Text + "', CL_RATE =" + Conversion.Val(txtrate.Text) + ", START_DATE =#" + strtdate.Text + "#, END_DATE =#" + endDate.Text + "# " + " where ID =" + ID.Text + " ");



                LOAD_CLIENT();
                usableselect.cleartext(gbclientinfo);
            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            try
            {



                {
                    var withBlock = My.MyProject.Forms.assign;
                    withBlock.ID.Text = Conversions.ToString(DataGridView2.CurrentRow.Cells[0].Value);
                    withBlock.LBLCLIENTID.Text = DataGridView2.CurrentRow.Cells[1].Value.ToString();
                    withBlock.lblclientName.Text = DataGridView2.CurrentRow.Cells[2].Value.ToString();
                    withBlock.lblAddress.Text = DataGridView2.CurrentRow.Cells[3].Value.ToString();
                    withBlock.lblrate.Text = Conversions.ToString(DataGridView2.CurrentRow.Cells[4].Value);
                    withBlock.lblstart.Text = Conversions.ToString(DataGridView2.CurrentRow.Cells[5].Value);
                    withBlock.lblend.Text = Conversions.ToString(DataGridView2.CurrentRow.Cells[6].Value);
                }
                My.MyProject.Forms.assign.Show();
            }
            catch (Exception ex)
            {
                Interaction.MsgBox("Please Select a specific client!");
            }


        }

        private void txtrate_TextChanged(object sender, EventArgs e)
        {
            if (!(Information.IsNumeric(txtrate.Text) == true))
            {
                txtrate.Text = null;

            }
        }

        private void DataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
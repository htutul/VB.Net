﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace Ichiban
{
    [Microsoft.VisualBasic.CompilerServices.DesignerGenerated()]
    public partial class Form1 : Form
    {

        // Form overrides dispose to clean up the component list.
        [DebuggerNonUserCode()]
        protected override void Dispose(bool disposing)
        {
            try
            {
                if (disposing && components is not null)
                {
                    components.Dispose();
                }
            }
            finally
            {
                base.Dispose(disposing);
            }
        }

        // Required by the Windows Form Designer
        private System.ComponentModel.IContainer components;

        // NOTE: The following procedure is required by the Windows Form Designer
        // It can be modified using the Windows Form Designer.  
        // Do not modify it using the code editor.
        [DebuggerStepThrough()]
        private void InitializeComponent()
        {
            Panel1 = new Panel();
            Button7 = new Button();
            Button7.Click += new EventHandler(Button7_Click);
            Button6 = new Button();
            Button6.Click += new EventHandler(Button6_Click);
            Button5 = new Button();
            Button5.Click += new EventHandler(Button5_Click);
            Button3 = new Button();
            Button3.Click += new EventHandler(Button3_Click);
            Button4 = new Button();
            Button4.Click += new EventHandler(Button4_Click);
            Button2 = new Button();
            Button2.Click += new EventHandler(Button2_Click);
            Button1 = new Button();
            Button1.Click += new EventHandler(Button1_Click);
            lbllogname = new Label();
            Label1 = new Label();
            Panel1.SuspendLayout();
            SuspendLayout();
            // 
            // Panel1
            // 
            Panel1.BackColor = SystemColors.ActiveCaption;
            Panel1.Controls.Add(Button7);
            Panel1.Controls.Add(Button6);
            Panel1.Controls.Add(Button5);
            Panel1.Controls.Add(Button3);
            Panel1.Controls.Add(Button4);
            Panel1.Controls.Add(Button2);
            Panel1.Controls.Add(Button1);
            Panel1.Controls.Add(lbllogname);
            Panel1.Dock = DockStyle.Left;
            Panel1.Location = new Point(0, 0);
            Panel1.Name = "Panel1";
            Panel1.Size = new Size(195, 596);
            Panel1.TabIndex = 3;
            // 
            // Button7
            // 
            Button7.Enabled = false;
            Button7.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Button7.Location = new Point(9, 463);
            Button7.Name = "Button7";
            Button7.Size = new Size(179, 61);
            Button7.TabIndex = 6;
            Button7.Text = "Settings";
            Button7.UseVisualStyleBackColor = true;
            // 
            // Button6
            // 
            Button6.Enabled = false;
            Button6.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Button6.Location = new Point(9, 396);
            Button6.Name = "Button6";
            Button6.Size = new Size(179, 61);
            Button6.TabIndex = 5;
            Button6.Text = "Register";
            Button6.UseVisualStyleBackColor = true;
            // 
            // Button5
            // 
            Button5.Enabled = false;
            Button5.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Button5.Location = new Point(8, 329);
            Button5.Name = "Button5";
            Button5.Size = new Size(179, 61);
            Button5.TabIndex = 4;
            Button5.Text = "Report";
            Button5.UseVisualStyleBackColor = true;
            // 
            // Button3
            // 
            Button3.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Button3.Location = new Point(8, 59);
            Button3.Name = "Button3";
            Button3.Size = new Size(179, 61);
            Button3.TabIndex = 2;
            Button3.Text = "LOGIN";
            Button3.UseVisualStyleBackColor = true;
            // 
            // Button4
            // 
            Button4.Enabled = false;
            Button4.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Button4.Location = new Point(8, 262);
            Button4.Name = "Button4";
            Button4.Size = new Size(179, 61);
            Button4.TabIndex = 3;
            Button4.Text = "Payroll";
            Button4.UseVisualStyleBackColor = true;
            // 
            // Button2
            // 
            Button2.Enabled = false;
            Button2.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Button2.Location = new Point(9, 195);
            Button2.Name = "Button2";
            Button2.Size = new Size(179, 61);
            Button2.TabIndex = 1;
            Button2.Text = "Client";
            Button2.UseVisualStyleBackColor = true;
            // 
            // Button1
            // 
            Button1.Enabled = false;
            Button1.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Button1.Location = new Point(9, 128);
            Button1.Name = "Button1";
            Button1.Size = new Size(179, 61);
            Button1.TabIndex = 0;
            Button1.Text = "Employee";
            Button1.UseVisualStyleBackColor = true;
            // 
            // lbllogname
            // 
            lbllogname.AutoSize = true;
            lbllogname.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbllogname.Location = new Point(8, 34);
            lbllogname.Name = "lbllogname";
            lbllogname.Size = new Size(49, 16);
            lbllogname.TabIndex = 4;
            lbllogname.Text = "Label1";
            lbllogname.Visible = false;
            // 
            // Label1
            // 
            Label1.AutoSize = true;
            Label1.Font = new Font("Microsoft Sans Serif", 20.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label1.Location = new Point(259, 21);
            Label1.Name = "Label1";
            Label1.Size = new Size(554, 31);
            Label1.TabIndex = 4;
            Label1.Text = "Payroll System Source Code Visual Basic";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(6.0f, 13.0f);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1026, 596);
            Controls.Add(Label1);
            Controls.Add(Panel1);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Panel1.ResumeLayout(false);
            Panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();

        }
        internal Panel Panel1;
        internal Button Button5;
        internal Button Button4;
        internal Button Button3;
        internal Button Button2;
        internal Button Button1;
        internal Label lbllogname;
        internal Button Button6;
        internal Button Button7;
        internal Label Label1;

    }
}
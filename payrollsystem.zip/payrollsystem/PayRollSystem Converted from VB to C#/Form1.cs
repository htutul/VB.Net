﻿using System;

namespace Ichiban
{
    public partial class Form1
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            My.MyProject.Forms.client.Show();

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            My.MyProject.Forms.employee.Show();
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            My.MyProject.Forms.payroll.Show();
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            report.Show();
        }


        private void Button3_Click(object sender, EventArgs e)
        {

            if (Button3.Text == "LOGIN")
            {
                My.MyProject.Forms.frmlogin.Show();
            }
            else
            {
                Button3.Text = "LOGIN";

                lbllogname.Visible = false;
                Button1.Enabled = false;
                Button2.Enabled = false;
                Button4.Enabled = false;
                Button5.Enabled = false;
                Button6.Enabled = false;


            }


        }

        private void Button6_Click(object sender, EventArgs e)
        {
            My.MyProject.Forms.frmUserAccountsProfile.Show();
        }


        private void Button7_Click(object sender, EventArgs e)
        {
            My.MyProject.Forms.Utilities.Show();

        }
    }
}
﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace Ichiban
{
    [Microsoft.VisualBasic.CompilerServices.DesignerGenerated()]
    public partial class frmUserAccountsProfile : Form
    {

        // Form overrides dispose to clean up the component list.
        [DebuggerNonUserCode()]
        protected override void Dispose(bool disposing)
        {
            try
            {
                if (disposing && components is not null)
                {
                    components.Dispose();
                }
            }
            finally
            {
                base.Dispose(disposing);
            }
        }

        // Required by the Windows Form Designer
        private System.ComponentModel.IContainer components;

        // NOTE: The following procedure is required by the Windows Form Designer
        // It can be modified using the Windows Form Designer.  
        // Do not modify it using the code editor.
        [DebuggerStepThrough()]
        private void InitializeComponent()
        {
            GroupBox2 = new GroupBox();
            DataGridView1 = new DataGridView();
            DataGridView1.CellClick += new DataGridViewCellEventHandler(itemdatagrid_CellClick);
            GroupBox1 = new GroupBox();
            Label7 = new Label();
            txtEmpID = new TextBox();
            Button3 = new Button();
            Button3.Click += new EventHandler(Button3_Click);
            btnedit = new Button();
            btnedit.Click += new EventHandler(btnedit_Click);
            lblid = new Label();
            btndel = new Button();
            btndel.Click += new EventHandler(btndel_Click);
            Label6 = new Label();
            Label6.Click += new EventHandler(Label6_Click);
            Button2 = new Button();
            Button2.Click += new EventHandler(Button2_Click);
            cbtype = new ComboBox();
            txtconfirm = new TextBox();
            txtpass = new TextBox();
            txtuname = new TextBox();
            txtname = new TextBox();
            Button1 = new Button();
            Button1.Click += new EventHandler(Button1_Click);
            Label5 = new Label();
            Label4 = new Label();
            Label3 = new Label();
            Label2 = new Label();
            Label1 = new Label();
            GroupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)DataGridView1).BeginInit();
            GroupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // GroupBox2
            // 
            GroupBox2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;

            GroupBox2.Controls.Add(DataGridView1);
            GroupBox2.Location = new Point(5, 269);
            GroupBox2.Name = "GroupBox2";
            GroupBox2.Size = new Size(412, 178);
            GroupBox2.TabIndex = 5;
            GroupBox2.TabStop = false;
            GroupBox2.Text = "List of Users";
            // 
            // DataGridView1
            // 
            DataGridView1.AllowUserToAddRows = false;
            DataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DataGridView1.Location = new Point(7, 14);
            DataGridView1.Name = "DataGridView1";
            DataGridView1.Size = new Size(391, 144);
            DataGridView1.TabIndex = 0;
            // 
            // GroupBox1
            // 
            GroupBox1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            GroupBox1.Controls.Add(Label7);
            GroupBox1.Controls.Add(txtEmpID);
            GroupBox1.Controls.Add(Button3);
            GroupBox1.Controls.Add(btnedit);
            GroupBox1.Controls.Add(lblid);
            GroupBox1.Controls.Add(btndel);
            GroupBox1.Controls.Add(Label6);
            GroupBox1.Controls.Add(Button2);
            GroupBox1.Controls.Add(cbtype);
            GroupBox1.Controls.Add(txtconfirm);
            GroupBox1.Controls.Add(txtpass);
            GroupBox1.Controls.Add(txtuname);
            GroupBox1.Controls.Add(txtname);
            GroupBox1.Controls.Add(Button1);
            GroupBox1.Controls.Add(Label5);
            GroupBox1.Controls.Add(Label4);
            GroupBox1.Controls.Add(Label3);
            GroupBox1.Controls.Add(Label2);
            GroupBox1.Controls.Add(Label1);
            GroupBox1.Location = new Point(9, 9);
            GroupBox1.Name = "GroupBox1";
            GroupBox1.Size = new Size(408, 254);
            GroupBox1.TabIndex = 4;
            GroupBox1.TabStop = false;
            GroupBox1.Text = "User Information";
            // 
            // Label7
            // 
            Label7.AutoSize = true;
            Label7.Location = new Point(13, 74);
            Label7.Name = "Label7";
            Label7.Size = new Size(73, 13);
            Label7.TabIndex = 18;
            Label7.Text = "Employee ID :";
            // 
            // txtEmpID
            // 
            txtEmpID.Location = new Point(108, 68);
            txtEmpID.Name = "txtEmpID";
            txtEmpID.Size = new Size(169, 20);
            txtEmpID.TabIndex = 17;
            // 
            // Button3
            // 
            Button3.Location = new Point(299, 131);
            Button3.Name = "Button3";
            Button3.Size = new Size(90, 23);
            Button3.TabIndex = 16;
            Button3.Text = "Clear";
            Button3.UseVisualStyleBackColor = true;
            // 
            // btnedit
            // 
            btnedit.Location = new Point(299, 101);
            btnedit.Name = "btnedit";
            btnedit.Size = new Size(90, 24);
            btnedit.TabIndex = 15;
            btnedit.Text = "Update";
            btnedit.UseVisualStyleBackColor = true;
            // 
            // lblid
            // 
            lblid.AutoSize = true;
            lblid.Location = new Point(13, 28);
            lblid.Name = "lblid";
            lblid.Size = new Size(15, 13);
            lblid.TabIndex = 14;
            lblid.Text = "id";
            lblid.Visible = false;
            // 
            // btndel
            // 
            btndel.Location = new Point(296, 71);
            btndel.Name = "btndel";
            btndel.Size = new Size(93, 24);
            btndel.TabIndex = 13;
            btndel.Text = "Delete";
            btndel.UseVisualStyleBackColor = true;
            // 
            // Label6
            // 
            Label6.AutoSize = true;
            Label6.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Underline, GraphicsUnit.Point, 0);
            Label6.ForeColor = Color.Blue;
            Label6.Location = new Point(13, 228);
            Label6.Name = "Label6";
            Label6.Size = new Size(95, 13);
            Label6.TabIndex = 12;
            Label6.Text = "Show List of Users";
            // 
            // Button2
            // 
            Button2.Location = new Point(299, 160);
            Button2.Name = "Button2";
            Button2.Size = new Size(90, 24);
            Button2.TabIndex = 11;
            Button2.Text = "Cancel";
            Button2.UseVisualStyleBackColor = true;
            // 
            // cbtype
            // 
            cbtype.FormattingEnabled = true;
            cbtype.Items.AddRange(new object[] { "Administrator", "Finance Officer", "HR", "Encoder" });
            cbtype.Location = new Point(108, 177);
            cbtype.Name = "cbtype";
            cbtype.Size = new Size(169, 21);
            cbtype.TabIndex = 10;
            // 
            // txtconfirm
            // 
            txtconfirm.Location = new Point(108, 150);
            txtconfirm.Name = "txtconfirm";
            txtconfirm.PasswordChar = '*';
            txtconfirm.Size = new Size(169, 20);
            txtconfirm.TabIndex = 9;
            txtconfirm.UseSystemPasswordChar = true;
            // 
            // txtpass
            // 
            txtpass.Location = new Point(108, 123);
            txtpass.Name = "txtpass";
            txtpass.PasswordChar = '*';
            txtpass.Size = new Size(169, 20);
            txtpass.TabIndex = 8;
            txtpass.UseSystemPasswordChar = true;
            // 
            // txtuname
            // 
            txtuname.Location = new Point(108, 97);
            txtuname.Name = "txtuname";
            txtuname.Size = new Size(169, 20);
            txtuname.TabIndex = 7;
            // 
            // txtname
            // 
            txtname.Location = new Point(108, 41);
            txtname.Name = "txtname";
            txtname.Size = new Size(169, 20);
            txtname.TabIndex = 6;
            // 
            // Button1
            // 
            Button1.Location = new Point(296, 41);
            Button1.Name = "Button1";
            Button1.Size = new Size(93, 24);
            Button1.TabIndex = 5;
            Button1.Text = "Save";
            Button1.UseVisualStyleBackColor = true;
            // 
            // Label5
            // 
            Label5.AutoSize = true;
            Label5.Location = new Point(13, 177);
            Label5.Name = "Label5";
            Label5.Size = new Size(65, 13);
            Label5.TabIndex = 4;
            Label5.Text = "User  Type :";
            // 
            // Label4
            // 
            Label4.AutoSize = true;
            Label4.Location = new Point(13, 153);
            Label4.Name = "Label4";
            Label4.Size = new Size(97, 13);
            Label4.TabIndex = 3;
            Label4.Text = "Confirm Password :";
            // 
            // Label3
            // 
            Label3.AutoSize = true;
            Label3.Location = new Point(13, 123);
            Label3.Name = "Label3";
            Label3.Size = new Size(59, 13);
            Label3.TabIndex = 2;
            Label3.Text = "Password :";
            // 
            // Label2
            // 
            Label2.AutoSize = true;
            Label2.Location = new Point(13, 100);
            Label2.Name = "Label2";
            Label2.Size = new Size(61, 13);
            Label2.TabIndex = 1;
            Label2.Text = "Username :";
            // 
            // Label1
            // 
            Label1.AutoSize = true;
            Label1.Location = new Point(13, 43);
            Label1.Name = "Label1";
            Label1.Size = new Size(41, 13);
            Label1.TabIndex = 0;
            Label1.Text = "Name :";
            // 
            // frmUserAccountsProfile
            // 
            AutoScaleDimensions = new SizeF(6.0f, 13.0f);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(422, 455);
            Controls.Add(GroupBox2);
            Controls.Add(GroupBox1);
            Name = "frmUserAccountsProfile";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "User Accounts Profile";
            GroupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)DataGridView1).EndInit();
            GroupBox1.ResumeLayout(false);
            GroupBox1.PerformLayout();
            Load += new EventHandler(Form1_Load);
            ResumeLayout(false);

        }
        internal GroupBox GroupBox2;
        internal DataGridView DataGridView1;
        internal GroupBox GroupBox1;
        internal Button Button3;
        internal Button btnedit;
        internal Label lblid;
        internal Button btndel;
        internal Label Label6;
        internal Button Button2;
        internal ComboBox cbtype;
        internal TextBox txtconfirm;
        internal TextBox txtpass;
        internal TextBox txtuname;
        internal TextBox txtname;
        internal Button Button1;
        internal Label Label5;
        internal Label Label4;
        internal Label Label3;
        internal Label Label2;
        internal Label Label1;
        internal Label Label7;
        internal TextBox txtEmpID;
    }
}
﻿using System;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Ichiban
{
    public partial class Utilities
    {
        public Utilities()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string portfolioPath = My.MyProject.Application.Info.DirectoryPath;
            FileSystem.FileCopy(Application.StartupPath + @"\enterprisedb.mdb", Application.StartupPath + @"\backup\enterprisedb.mdb");
            Interaction.MsgBox("Backup Successful");
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            string portfolioPath = My.MyProject.Application.Info.DirectoryPath;
            if (MessageBox.Show("Restoring the database will erase any changes you have made since you last backup. Are you sure you want to do this?", "Confirm Delete", MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.OK)
            {

                // Restore the database from a backup copy. 
                FileSystem.FileCopy(Application.StartupPath + @"\backup\enterprisedb.mdb", Application.StartupPath + @"\enterprisedb.mdb");
                Interaction.MsgBox("Database Restoration Successful");
            }
        }
    }
}
﻿using System;

namespace Ichiban
{


    public partial class frmlogin
    {

        private string sql;

        public frmlogin()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Button2_Click(object sender, EventArgs e)
        {

            sql = "select * from tbluseraccounts where userusername ='" + txtusername.Text + "' and userpassword = '" + txtpassword.Text + "'";
            jokensqlselect.jokenfindthis(sql);
            jokensqlselect.checkresult("Login");

        }
    }
}
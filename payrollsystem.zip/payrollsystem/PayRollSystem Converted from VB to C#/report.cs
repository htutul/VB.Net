﻿using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Ichiban
{
    public partial class reportType
    {
        private System.Data.OleDb.OleDbCommand acscmd = new System.Data.OleDb.OleDbCommand();
        private System.Data.OleDb.OleDbDataAdapter acsda = new System.Data.OleDb.OleDbDataAdapter();
        private System.Data.OleDb.OleDbConnection acscon = db.myconn();
        private DataSet acsds = new DataSet();
        private string strsql;
        private string strreportname;
        private string token;

        public reportType()
        {
            InitializeComponent();
        }
        private void report_Load(object sender, EventArgs e)
        {


        }
        public void report(string sql, string rptname)
        {
            try
            {
                acsds = new DataSet();
                strsql = sql;
                acscmd.CommandText = strsql;
                acscmd.Connection = acscon;
                acsda.SelectCommand = acscmd;
                acsda.Fill(acsds);

                strreportname = rptname;
                string strreportpath = Application.StartupPath + @"\reports\" + strreportname + ".rpt";
                // Dim strreportpath As String = "C:\Users\DELL\Documents\Visual Studio 2008\Projects\mytest\mytest\bin\reports\" & strreportname & ".rpt"
                if (!System.IO.File.Exists(strreportpath))
                {
                    Interaction.MsgBox("Unable to locate file:" + Constants.vbCrLf + strreportpath);

                }
                var reportdoc = new CrystalDecisions.CrystalReports.Engine.ReportDocument();

                reportdoc.Load(strreportpath);
                reportdoc.SetDataSource(acsds.Tables[0]);

                CrystalReportViewer1.ShowRefreshButton = false;
                CrystalReportViewer1.ShowCloseButton = false;
                CrystalReportViewer1.ShowGroupTreeButton = false;
                CrystalReportViewer1.ReportSource = reportdoc;
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message);
            }

        }


        private void Button1_Click(object sender, EventArgs e)
        {

            report("select * from overallpayrol order by period_start", "detailed");
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            report("select * from payslip where PERIOD_START  between #" + dtpPeriodStart.Text + "#  and #" + dtpPeriodEnd.Text + "#", "PaySlipVer1");
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            report("select * from empdetails", "EmployeeInfo");
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            report("select * from clientdetails", "clientDetails");

        }

        private void Button5_Click(object sender, EventArgs e)
        {
            report("select * from overallpayrol where PERIOD_START between #" + dtpPeriodStart.Text + "# AND #" + dtpPeriodEnd.Text + "# ORDER by period_start", "detailed");

        }

        private void Button6_Click(object sender, EventArgs e)
        {
            report("select * from clientguard", "clientguard");

        }
    }
}
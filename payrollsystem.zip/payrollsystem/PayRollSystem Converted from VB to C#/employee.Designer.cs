﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace Ichiban
{
    [Microsoft.VisualBasic.CompilerServices.DesignerGenerated()]
    public partial class employee : Form
    {

        // Form overrides dispose to clean up the component list.
        [DebuggerNonUserCode()]
        protected override void Dispose(bool disposing)
        {
            try
            {
                if (disposing && components is not null)
                {
                    components.Dispose();
                }
            }
            finally
            {
                base.Dispose(disposing);
            }
        }

        // Required by the Windows Form Designer
        private System.ComponentModel.IContainer components;

        // NOTE: The following procedure is required by the Windows Form Designer
        // It can be modified using the Windows Form Designer.  
        // Do not modify it using the code editor.
        [DebuggerStepThrough()]
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Panel1 = new Panel();
            Panel1.Paint += new PaintEventHandler(Panel1_Paint);
            Label4 = new Label();
            GroupBox1 = new GroupBox();
            Label9 = new Label();
            Label3 = new Label();
            GroupBox2 = new GroupBox();
            Button3 = new Button();
            Button3.Click += new EventHandler(Button3_Click);
            BTNNEW = new Button();
            BTNNEW.Click += new EventHandler(BTNNEW_Click);
            GroupBox3 = new GroupBox();
            LBLONDUTY = new Label();
            lblinactive = new Label();
            lblactive = new Label();
            lbltotalemployee = new Label();
            Label8 = new Label();
            Label7 = new Label();
            Label6 = new Label();
            Label5 = new Label();
            GroupBox4 = new GroupBox();
            lblEMployeeID = new Label();
            Label13 = new Label();
            Label14 = new Label();
            TXTSEARCH = new TextBox();
            TXTSEARCH.TextChanged += new EventHandler(TXTSEARCH_TextChanged);
            Panel2 = new Panel();
            Label10 = new Label();
            Label12 = new Label();
            Label1 = new Label();
            Label11 = new Label();
            Label2 = new Label();
            DataGridView1 = new DataGridView();
            DataGridView1.CellContentClick += new DataGridViewCellEventHandler(DataGridView1_CellContentClick);
            DataGridView1.CellDoubleClick += new DataGridViewCellEventHandler(DataGridView1_CellDoubleClick);
            DataGridView1.Click += new EventHandler(DataGridView1_Click);
            Timer1 = new Timer(components);
            Timer1.Tick += new EventHandler(Timer1_Tick);
            Panel1.SuspendLayout();
            GroupBox1.SuspendLayout();
            GroupBox2.SuspendLayout();
            GroupBox3.SuspendLayout();
            GroupBox4.SuspendLayout();
            Panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)DataGridView1).BeginInit();
            SuspendLayout();
            // 
            // Panel1
            // 
            Panel1.BackColor = SystemColors.ActiveCaption;
            Panel1.Controls.Add(Label4);
            Panel1.Dock = DockStyle.Top;
            Panel1.Location = new Point(0, 0);
            Panel1.Name = "Panel1";
            Panel1.Size = new Size(903, 51);
            Panel1.TabIndex = 4;
            // 
            // Label4
            // 
            Label4.Font = new Font("Microsoft Sans Serif", 18.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label4.ForeColor = SystemColors.HighlightText;
            Label4.Location = new Point(3, 9);
            Label4.Name = "Label4";
            Label4.Size = new Size(348, 33);
            Label4.TabIndex = 1;
            Label4.Text = "Employee Information";
            // 
            // GroupBox1
            // 
            GroupBox1.Controls.Add(Label9);
            GroupBox1.Controls.Add(Label3);
            GroupBox1.Location = new Point(13, 58);
            GroupBox1.Name = "GroupBox1";
            GroupBox1.Size = new Size(209, 125);
            GroupBox1.TabIndex = 5;
            GroupBox1.TabStop = false;
            // 
            // Label9
            // 
            Label9.AutoSize = true;
            Label9.Font = new Font("Microsoft Sans Serif", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label9.Location = new Point(7, 84);
            Label9.Name = "Label9";
            Label9.Size = new Size(72, 24);
            Label9.TabIndex = 1;
            Label9.Text = "Label9";
            // 
            // Label3
            // 
            Label3.AutoSize = true;
            Label3.Font = new Font("Microsoft Sans Serif", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label3.Location = new Point(7, 39);
            Label3.Name = "Label3";
            Label3.Size = new Size(72, 24);
            Label3.TabIndex = 0;
            Label3.Text = "Label3";
            // 
            // GroupBox2
            // 
            GroupBox2.Controls.Add(Button3);
            GroupBox2.Controls.Add(BTNNEW);
            GroupBox2.Location = new Point(13, 189);
            GroupBox2.Name = "GroupBox2";
            GroupBox2.Size = new Size(209, 85);
            GroupBox2.TabIndex = 6;
            GroupBox2.TabStop = false;
            // 
            // Button3
            // 
            Button3.Location = new Point(106, 20);
            Button3.Name = "Button3";
            Button3.Size = new Size(89, 47);
            Button3.TabIndex = 2;
            Button3.Text = "Deactivate";
            Button3.UseVisualStyleBackColor = true;
            // 
            // BTNNEW
            // 
            BTNNEW.Location = new Point(7, 20);
            BTNNEW.Name = "BTNNEW";
            BTNNEW.Size = new Size(89, 47);
            BTNNEW.TabIndex = 0;
            BTNNEW.Text = "Add New Employee";
            BTNNEW.UseVisualStyleBackColor = true;
            // 
            // GroupBox3
            // 
            GroupBox3.Controls.Add(LBLONDUTY);
            GroupBox3.Controls.Add(lblinactive);
            GroupBox3.Controls.Add(lblactive);
            GroupBox3.Controls.Add(lbltotalemployee);
            GroupBox3.Controls.Add(Label8);
            GroupBox3.Controls.Add(Label7);
            GroupBox3.Controls.Add(Label6);
            GroupBox3.Controls.Add(Label5);
            GroupBox3.Location = new Point(13, 280);
            GroupBox3.Name = "GroupBox3";
            GroupBox3.Size = new Size(209, 200);
            GroupBox3.TabIndex = 7;
            GroupBox3.TabStop = false;
            GroupBox3.Text = "Employee Details";
            // 
            // LBLONDUTY
            // 
            LBLONDUTY.AutoSize = true;
            LBLONDUTY.Font = new Font("Microsoft Sans Serif", 12.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            LBLONDUTY.Location = new Point(183, 126);
            LBLONDUTY.Name = "LBLONDUTY";
            LBLONDUTY.Size = new Size(18, 20);
            LBLONDUTY.TabIndex = 7;
            LBLONDUTY.Text = "0";
            // 
            // lblinactive
            // 
            lblinactive.AutoSize = true;
            lblinactive.Font = new Font("Microsoft Sans Serif", 12.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblinactive.Location = new Point(183, 87);
            lblinactive.Name = "lblinactive";
            lblinactive.Size = new Size(18, 20);
            lblinactive.TabIndex = 6;
            lblinactive.Text = "0";
            // 
            // lblactive
            // 
            lblactive.AutoSize = true;
            lblactive.Font = new Font("Microsoft Sans Serif", 12.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblactive.Location = new Point(183, 54);
            lblactive.Name = "lblactive";
            lblactive.Size = new Size(18, 20);
            lblactive.TabIndex = 5;
            lblactive.Text = "0";
            // 
            // lbltotalemployee
            // 
            lbltotalemployee.AutoSize = true;
            lbltotalemployee.Font = new Font("Microsoft Sans Serif", 12.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbltotalemployee.Location = new Point(183, 18);
            lbltotalemployee.Name = "lbltotalemployee";
            lbltotalemployee.Size = new Size(18, 20);
            lbltotalemployee.TabIndex = 4;
            lbltotalemployee.Text = "0";
            // 
            // Label8
            // 
            Label8.AutoSize = true;
            Label8.Font = new Font("Microsoft Sans Serif", 12.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label8.Location = new Point(103, 126);
            Label8.Name = "Label8";
            Label8.Size = new Size(76, 20);
            Label8.TabIndex = 3;
            Label8.Text = "On-Duty :";
            // 
            // Label7
            // 
            Label7.AutoSize = true;
            Label7.Font = new Font("Microsoft Sans Serif", 12.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label7.Location = new Point(-5, 87);
            Label7.Name = "Label7";
            Label7.Size = new Size(185, 20);
            Label7.TabIndex = 2;
            Label7.Text = "Total Inactive Employee :";
            // 
            // Label6
            // 
            Label6.AutoSize = true;
            Label6.Font = new Font("Microsoft Sans Serif", 12.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label6.Location = new Point(1, 54);
            Label6.Name = "Label6";
            Label6.Size = new Size(173, 20);
            Label6.TabIndex = 1;
            Label6.Text = "Total Active Employee :";
            // 
            // Label5
            // 
            Label5.AutoSize = true;
            Label5.Font = new Font("Microsoft Sans Serif", 12.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label5.Location = new Point(51, 18);
            Label5.Name = "Label5";
            Label5.Size = new Size(126, 20);
            Label5.TabIndex = 0;
            Label5.Text = "Total Employee :";
            // 
            // GroupBox4
            // 
            GroupBox4.Controls.Add(lblEMployeeID);
            GroupBox4.Controls.Add(Label13);
            GroupBox4.Controls.Add(Label14);
            GroupBox4.Controls.Add(TXTSEARCH);
            GroupBox4.Controls.Add(Panel2);
            GroupBox4.Controls.Add(DataGridView1);
            GroupBox4.Location = new Point(228, 58);
            GroupBox4.Name = "GroupBox4";
            GroupBox4.Size = new Size(663, 428);
            GroupBox4.TabIndex = 8;
            GroupBox4.TabStop = false;
            // 
            // lblEMployeeID
            // 
            lblEMployeeID.AutoSize = true;
            lblEMployeeID.Location = new Point(246, 38);
            lblEMployeeID.Name = "lblEMployeeID";
            lblEMployeeID.Size = new Size(65, 13);
            lblEMployeeID.TabIndex = 15;
            lblEMployeeID.Text = "EMployeeID";
            lblEMployeeID.Visible = false;
            // 
            // Label13
            // 
            Label13.AutoSize = true;
            Label13.ForeColor = Color.Red;
            Label13.Location = new Point(91, 19);
            Label13.Name = "Label13";
            Label13.Size = new Size(124, 13);
            Label13.TabIndex = 14;
            Label13.Text = "(First Name or Lastname)";
            // 
            // Label14
            // 
            Label14.AutoSize = true;
            Label14.Font = new Font("Microsoft Sans Serif", 12.0f, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label14.Location = new Point(9, 14);
            Label14.Name = "Label14";
            Label14.Size = new Size(76, 20);
            Label14.TabIndex = 13;
            Label14.Text = "Search :";
            // 
            // TXTSEARCH
            // 
            TXTSEARCH.Location = new Point(10, 35);
            TXTSEARCH.Name = "TXTSEARCH";
            TXTSEARCH.Size = new Size(230, 20);
            TXTSEARCH.TabIndex = 12;
            // 
            // Panel2
            // 
            Panel2.BorderStyle = BorderStyle.FixedSingle;
            Panel2.Controls.Add(Label10);
            Panel2.Controls.Add(Label12);
            Panel2.Controls.Add(Label1);
            Panel2.Controls.Add(Label11);
            Panel2.Controls.Add(Label2);
            Panel2.Location = new Point(10, 56);
            Panel2.Name = "Panel2";
            Panel2.Size = new Size(647, 26);
            Panel2.TabIndex = 12;
            // 
            // Label10
            // 
            Label10.AutoSize = true;
            Label10.ForeColor = Color.FromArgb(192, 64, 0);
            Label10.Location = new Point(329, 9);
            Label10.Name = "Label10";
            Label10.Size = new Size(58, 13);
            Label10.TabIndex = 7;
            Label10.Text = "Date Hired";
            // 
            // Label12
            // 
            Label12.AutoSize = true;
            Label12.ForeColor = Color.FromArgb(192, 64, 0);
            Label12.Location = new Point(288, 9);
            Label12.Name = "Label12";
            Label12.Size = new Size(19, 13);
            Label12.TabIndex = 11;
            Label12.Text = "MI";
            // 
            // Label1
            // 
            Label1.AutoSize = true;
            Label1.ForeColor = Color.FromArgb(192, 64, 0);
            Label1.Location = new Point(1, 9);
            Label1.Name = "Label1";
            Label1.Size = new Size(67, 13);
            Label1.TabIndex = 8;
            Label1.Text = "Employee ID";
            // 
            // Label11
            // 
            Label11.AutoSize = true;
            Label11.ForeColor = Color.FromArgb(192, 64, 0);
            Label11.Location = new Point(188, 9);
            Label11.Name = "Label11";
            Label11.Size = new Size(58, 13);
            Label11.TabIndex = 10;
            Label11.Text = "Last Name";
            // 
            // Label2
            // 
            Label2.AutoSize = true;
            Label2.ForeColor = Color.FromArgb(192, 64, 0);
            Label2.Location = new Point(92, 9);
            Label2.Name = "Label2";
            Label2.Size = new Size(57, 13);
            Label2.TabIndex = 9;
            Label2.Text = "First Name";
            // 
            // DataGridView1
            // 
            DataGridView1.AllowUserToAddRows = false;
            DataGridView1.AllowUserToDeleteRows = false;
            DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DataGridView1.ColumnHeadersVisible = false;
            DataGridView1.Location = new Point(10, 82);
            DataGridView1.Name = "DataGridView1";
            DataGridView1.RowHeadersVisible = false;
            DataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            DataGridView1.Size = new Size(647, 340);
            DataGridView1.TabIndex = 6;
            // 
            // Timer1
            // 
            // 
            // employee
            // 
            AutoScaleDimensions = new SizeF(6.0f, 13.0f);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(903, 498);
            Controls.Add(GroupBox4);
            Controls.Add(GroupBox3);
            Controls.Add(GroupBox2);
            Controls.Add(GroupBox1);
            Controls.Add(Panel1);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Name = "employee";
            StartPosition = FormStartPosition.CenterScreen;
            Panel1.ResumeLayout(false);
            GroupBox1.ResumeLayout(false);
            GroupBox1.PerformLayout();
            GroupBox2.ResumeLayout(false);
            GroupBox3.ResumeLayout(false);
            GroupBox3.PerformLayout();
            GroupBox4.ResumeLayout(false);
            GroupBox4.PerformLayout();
            Panel2.ResumeLayout(false);
            Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)DataGridView1).EndInit();
            Load += new EventHandler(employee_Load);
            ResumeLayout(false);

        }
        internal Panel Panel1;
        internal Label Label4;
        internal GroupBox GroupBox1;
        internal GroupBox GroupBox2;
        internal GroupBox GroupBox3;
        internal GroupBox GroupBox4;
        internal Button Button3;
        internal Button BTNNEW;
        internal Label Label3;
        internal Label LBLONDUTY;
        internal Label lblinactive;
        internal Label lblactive;
        internal Label lbltotalemployee;
        internal Label Label8;
        internal Label Label7;
        internal Label Label6;
        internal Label Label5;
        internal Timer Timer1;
        internal Label Label9;
        internal DataGridView DataGridView1;
        internal Label Label10;
        internal Label Label1;
        internal Label Label11;
        internal Label Label2;
        internal Label Label12;
        internal TextBox TXTSEARCH;
        internal Panel Panel2;
        internal Label Label13;
        internal Label Label14;
        internal Label lblEMployeeID;
    }
}
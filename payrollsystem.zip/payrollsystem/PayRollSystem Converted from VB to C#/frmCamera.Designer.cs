﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace Ichiban
{
    [Microsoft.VisualBasic.CompilerServices.DesignerGenerated()]
    public partial class frmCamera : Form
    {

        // Form overrides dispose to clean up the component list.
        [DebuggerNonUserCode()]
        protected override void Dispose(bool disposing)
        {
            try
            {
                if (disposing && components is not null)
                {
                    components.Dispose();
                }
            }
            finally
            {
                base.Dispose(disposing);
            }
        }

        // Required by the Windows Form Designer
        private System.ComponentModel.IContainer components;

        // NOTE: The following procedure is required by the Windows Form Designer
        // It can be modified using the Windows Form Designer.  
        // Do not modify it using the code editor.
        [DebuggerStepThrough()]
        private void InitializeComponent()
        {
            Button4 = new Button();
            Button4.Click += new EventHandler(Button4_Click_1);
            Button2 = new Button();
            Button2.Click += new EventHandler(Button2_Click_1);
            PictureBox1 = new PictureBox();
            Label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)PictureBox1).BeginInit();
            SuspendLayout();
            // 
            // Button4
            // 
            Button4.Font = new Font("Microsoft Sans Serif", 12.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Button4.Location = new Point(231, 343);
            Button4.Name = "Button4";
            Button4.Size = new Size(91, 28);
            Button4.TabIndex = 93;
            Button4.Text = "Capture";
            Button4.UseVisualStyleBackColor = true;
            // 
            // Button2
            // 
            Button2.Font = new Font("Microsoft Sans Serif", 12.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Button2.Location = new Point(12, 4);
            Button2.Name = "Button2";
            Button2.Size = new Size(91, 28);
            Button2.TabIndex = 92;
            Button2.Text = "Camera";
            Button2.UseVisualStyleBackColor = true;
            // 
            // PictureBox1
            // 
            PictureBox1.Image = My.Resources.Resources.Login_Manager;
            PictureBox1.Location = new Point(12, 38);
            PictureBox1.Name = "PictureBox1";
            PictureBox1.Size = new Size(310, 299);
            PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            PictureBox1.TabIndex = 91;
            PictureBox1.TabStop = false;
            // 
            // Label1
            // 
            Label1.AutoSize = true;
            Label1.Location = new Point(111, 12);
            Label1.Name = "Label1";
            Label1.Size = new Size(140, 13);
            Label1.TabIndex = 94;
            Label1.Text = "double click to start camera.";
            // 
            // frmCamera
            // 
            AutoScaleDimensions = new SizeF(6.0f, 13.0f);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(334, 378);
            Controls.Add(Label1);
            Controls.Add(Button4);
            Controls.Add(Button2);
            Controls.Add(PictureBox1);
            Name = "frmCamera";
            StartPosition = FormStartPosition.CenterScreen;
            ((System.ComponentModel.ISupportInitialize)PictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();

        }
        internal Button Button4;
        internal Button Button2;
        internal PictureBox PictureBox1;
        internal Label Label1;
    }
}
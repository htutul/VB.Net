﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace Ichiban
{
    [Microsoft.VisualBasic.CompilerServices.DesignerGenerated()]
    public partial class newemployee : Form
    {

        // Form overrides dispose to clean up the component list.
        [DebuggerNonUserCode()]
        protected override void Dispose(bool disposing)
        {
            try
            {
                if (disposing && components is not null)
                {
                    components.Dispose();
                }
            }
            finally
            {
                base.Dispose(disposing);
            }
        }

        // Required by the Windows Form Designer
        private System.ComponentModel.IContainer components;

        // NOTE: The following procedure is required by the Windows Form Designer
        // It can be modified using the Windows Form Designer.  
        // Do not modify it using the code editor.
        [DebuggerStepThrough()]
        private void InitializeComponent()
        {
            Panel1 = new Panel();
            Label4 = new Label();
            GroupBox1 = new GroupBox();
            cbpositon = new TextBox();
            Label40 = new Label();
            Label39 = new Label();
            Label38 = new Label();
            Label37 = new Label();
            Label36 = new Label();
            GroupBox2 = new GroupBox();
            rbdep0 = new RadioButton();
            rbdep4 = new RadioButton();
            rbdep3 = new RadioButton();
            rbdep2 = new RadioButton();
            rbdep1 = new RadioButton();
            Label35 = new Label();
            cbocivil = new ComboBox();
            cbocivil.TextChanged += new EventHandler(cbocivil_TextChanged);
            Label8 = new Label();
            TabControl1 = new TabControl();
            TabPage1 = new TabPage();
            Label27 = new Label();
            Label30 = new Label();
            txtcollegeYear = new MaskedTextBox();
            txthschool_yeAR = new MaskedTextBox();
            txtelem_year = new MaskedTextBox();
            Label29 = new Label();
            txtcollege = new MaskedTextBox();
            Label23 = new Label();
            txthschool = new MaskedTextBox();
            Label22 = new Label();
            txtelem = new MaskedTextBox();
            Label24 = new Label();
            TabPage3 = new TabPage();
            Label45 = new Label();
            Label46 = new Label();
            txtPHIC = new MaskedTextBox();
            txtPHIC.TextChanged += new EventHandler(txtPHIC_TextChanged);
            Label34 = new Label();
            Label44 = new Label();
            txtHDMF = new MaskedTextBox();
            txtHDMF.TextChanged += new EventHandler(txtHDMF_TextChanged);
            Label43 = new Label();
            Label33 = new Label();
            txtpc = new DateTimePicker();
            Label42 = new Label();
            Label41 = new Label();
            Label16 = new Label();
            Label19 = new Label();
            txtothers = new MaskedTextBox();
            txtothers.TextChanged += new EventHandler(txtothers_TextChanged);
            txtnbic = new MaskedTextBox();
            txtnbic.TextChanged += new EventHandler(txtnbic_TextChanged);
            Label32 = new Label();
            txtgl = new MaskedTextBox();
            txtgl.TextChanged += new EventHandler(txtgl_TextChanged);
            Label31 = new Label();
            cboworkstat = new ComboBox();
            dtpHiredate = new DateTimePicker();
            Label21 = new Label();
            Label25 = new Label();
            txtmotheradd = new TextBox();
            Label26 = new Label();
            txtfatheradd = new TextBox();
            Label28 = new Label();
            Label17 = new Label();
            txtsadd = new TextBox();
            lblsadd = new Label();
            txtmothername = new TextBox();
            Label20 = new Label();
            txtfathername = new TextBox();
            Label18 = new Label();
            txtnamSpouse = new TextBox();
            lblspouse = new Label();
            rdofemale = new RadioButton();
            rdomale = new RadioButton();
            dtpbdate = new DateTimePicker();
            dtpbdate.TextChanged += new EventHandler(dtpbdate_TextChanged);
            dtpbdate.ValueChanged += new EventHandler(dtpbdate_ValueChanged);
            txtreligon = new TextBox();
            Label13 = new Label();
            txtcitizen = new TextBox();
            Label14 = new Label();
            txtHeight = new TextBox();
            txtHeight.TextChanged += new EventHandler(txtHeight_TextChanged);
            Label11 = new Label();
            txtContact = new TextBox();
            txtContact.TextChanged += new EventHandler(txtContact_TextChanged);
            Label12 = new Label();
            txtbplace = new TextBox();
            Label9 = new Label();
            Label7 = new Label();
            Label15 = new Label();
            txtweight = new TextBox();
            txtweight.TextChanged += new EventHandler(txtweight_TextChanged);
            Label10 = new Label();
            txtage = new TextBox();
            Label5 = new Label();
            txtmname = new TextBox();
            txtmname.TextChanged += new EventHandler(txtmname_TextChanged);
            Label6 = new Label();
            Label1 = new Label();
            txtemp_id = new TextBox();
            label = new Label();
            txtfname = new TextBox();
            Label3 = new Label();
            txtlname = new TextBox();
            Label2 = new Label();
            btnadd = new Button();
            btnadd.Click += new EventHandler(btnadd_Click);
            OpenFileDialog1 = new OpenFileDialog();
            SaveFileDialog1 = new SaveFileDialog();
            Button1 = new Button();
            Button1.Click += new EventHandler(Button1_Click);
            TabPage2 = new TabPage();
            txtwecom1 = new TextBox();
            txtwecom2 = new TextBox();
            txtwecom3 = new TextBox();
            txtwepos1 = new TextBox();
            txtwepos2 = new TextBox();
            txtwepos3 = new TextBox();
            Label47 = new Label();
            Label48 = new Label();
            Label50 = new Label();
            txtwedate1 = new TextBox();
            txtwedate2 = new TextBox();
            txtwedate3 = new TextBox();
            Panel1.SuspendLayout();
            GroupBox1.SuspendLayout();
            GroupBox2.SuspendLayout();
            TabControl1.SuspendLayout();
            TabPage1.SuspendLayout();
            TabPage3.SuspendLayout();
            TabPage2.SuspendLayout();
            SuspendLayout();
            // 
            // Panel1
            // 
            Panel1.BackColor = SystemColors.ActiveCaption;
            Panel1.Controls.Add(Label4);
            Panel1.Dock = DockStyle.Top;
            Panel1.Location = new Point(0, 0);
            Panel1.Name = "Panel1";
            Panel1.Size = new Size(663, 51);
            Panel1.TabIndex = 3;
            // 
            // Label4
            // 
            Label4.Font = new Font("Microsoft Sans Serif", 18.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label4.ForeColor = SystemColors.HighlightText;
            Label4.Location = new Point(3, 9);
            Label4.Name = "Label4";
            Label4.Size = new Size(348, 33);
            Label4.TabIndex = 1;
            Label4.Text = "Add New Employee";
            // 
            // GroupBox1
            // 
            GroupBox1.Controls.Add(cbpositon);
            GroupBox1.Controls.Add(Label40);
            GroupBox1.Controls.Add(Label39);
            GroupBox1.Controls.Add(Label38);
            GroupBox1.Controls.Add(Label37);
            GroupBox1.Controls.Add(Label36);
            GroupBox1.Controls.Add(GroupBox2);
            GroupBox1.Controls.Add(Label35);
            GroupBox1.Controls.Add(cbocivil);
            GroupBox1.Controls.Add(Label8);
            GroupBox1.Controls.Add(TabControl1);
            GroupBox1.Controls.Add(cboworkstat);
            GroupBox1.Controls.Add(dtpHiredate);
            GroupBox1.Controls.Add(Label21);
            GroupBox1.Controls.Add(Label25);
            GroupBox1.Controls.Add(txtmotheradd);
            GroupBox1.Controls.Add(Label26);
            GroupBox1.Controls.Add(txtfatheradd);
            GroupBox1.Controls.Add(Label28);
            GroupBox1.Controls.Add(Label17);
            GroupBox1.Controls.Add(txtsadd);
            GroupBox1.Controls.Add(lblsadd);
            GroupBox1.Controls.Add(txtmothername);
            GroupBox1.Controls.Add(Label20);
            GroupBox1.Controls.Add(txtfathername);
            GroupBox1.Controls.Add(Label18);
            GroupBox1.Controls.Add(txtnamSpouse);
            GroupBox1.Controls.Add(lblspouse);
            GroupBox1.Controls.Add(rdofemale);
            GroupBox1.Controls.Add(rdomale);
            GroupBox1.Controls.Add(dtpbdate);
            GroupBox1.Controls.Add(txtreligon);
            GroupBox1.Controls.Add(Label13);
            GroupBox1.Controls.Add(txtcitizen);
            GroupBox1.Controls.Add(Label14);
            GroupBox1.Controls.Add(txtHeight);
            GroupBox1.Controls.Add(Label11);
            GroupBox1.Controls.Add(txtContact);
            GroupBox1.Controls.Add(Label12);
            GroupBox1.Controls.Add(txtbplace);
            GroupBox1.Controls.Add(Label9);
            GroupBox1.Controls.Add(Label7);
            GroupBox1.Controls.Add(Label15);
            GroupBox1.Controls.Add(txtweight);
            GroupBox1.Controls.Add(Label10);
            GroupBox1.Controls.Add(txtage);
            GroupBox1.Controls.Add(Label5);
            GroupBox1.Controls.Add(txtmname);
            GroupBox1.Controls.Add(Label6);
            GroupBox1.Controls.Add(Label1);
            GroupBox1.Controls.Add(txtemp_id);
            GroupBox1.Controls.Add(label);
            GroupBox1.Controls.Add(txtfname);
            GroupBox1.Controls.Add(Label3);
            GroupBox1.Controls.Add(txtlname);
            GroupBox1.Controls.Add(Label2);
            GroupBox1.Location = new Point(8, 57);
            GroupBox1.Name = "GroupBox1";
            GroupBox1.Size = new Size(648, 527);
            GroupBox1.TabIndex = 4;
            GroupBox1.TabStop = false;
            // 
            // cbpositon
            // 
            cbpositon.Enabled = false;
            cbpositon.Location = new Point(540, 254);
            cbpositon.Name = "cbpositon";
            cbpositon.ReadOnly = true;
            cbpositon.Size = new Size(90, 20);
            cbpositon.TabIndex = 94;
            cbpositon.Text = "Guard";
            // 
            // Label40
            // 
            Label40.AutoSize = true;
            Label40.Font = new Font("Microsoft Sans Serif", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label40.ForeColor = Color.Red;
            Label40.Location = new Point(93, 152);
            Label40.Name = "Label40";
            Label40.Size = new Size(18, 24);
            Label40.TabIndex = 93;
            Label40.Text = "*";
            // 
            // Label39
            // 
            Label39.AutoSize = true;
            Label39.Font = new Font("Microsoft Sans Serif", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label39.ForeColor = Color.Red;
            Label39.Location = new Point(89, 122);
            Label39.Name = "Label39";
            Label39.Size = new Size(18, 24);
            Label39.TabIndex = 92;
            Label39.Text = "*";
            // 
            // Label38
            // 
            Label38.AutoSize = true;
            Label38.Font = new Font("Microsoft Sans Serif", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label38.ForeColor = Color.Red;
            Label38.Location = new Point(69, 97);
            Label38.Name = "Label38";
            Label38.Size = new Size(18, 24);
            Label38.TabIndex = 91;
            Label38.Text = "*";
            // 
            // Label37
            // 
            Label37.AutoSize = true;
            Label37.Font = new Font("Microsoft Sans Serif", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label37.ForeColor = Color.Red;
            Label37.Location = new Point(517, 71);
            Label37.Name = "Label37";
            Label37.Size = new Size(18, 24);
            Label37.TabIndex = 90;
            Label37.Text = "*";
            // 
            // Label36
            // 
            Label36.AutoSize = true;
            Label36.Font = new Font("Microsoft Sans Serif", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label36.ForeColor = Color.Red;
            Label36.Location = new Point(277, 70);
            Label36.Name = "Label36";
            Label36.Size = new Size(18, 24);
            Label36.TabIndex = 89;
            Label36.Text = "*";
            // 
            // GroupBox2
            // 
            GroupBox2.Controls.Add(rbdep0);
            GroupBox2.Controls.Add(rbdep4);
            GroupBox2.Controls.Add(rbdep3);
            GroupBox2.Controls.Add(rbdep2);
            GroupBox2.Controls.Add(rbdep1);
            GroupBox2.Enabled = false;
            GroupBox2.Location = new Point(28, 324);
            GroupBox2.Name = "GroupBox2";
            GroupBox2.Size = new Size(263, 60);
            GroupBox2.TabIndex = 57;
            GroupBox2.TabStop = false;
            GroupBox2.Text = "Number of Qualified Dependent";
            // 
            // rbdep0
            // 
            rbdep0.AutoSize = true;
            rbdep0.Location = new Point(20, 30);
            rbdep0.Name = "rbdep0";
            rbdep0.Size = new Size(31, 17);
            rbdep0.TabIndex = 4;
            rbdep0.TabStop = true;
            rbdep0.Text = "0";
            rbdep0.UseVisualStyleBackColor = true;
            // 
            // rbdep4
            // 
            rbdep4.AutoSize = true;
            rbdep4.Location = new Point(198, 30);
            rbdep4.Name = "rbdep4";
            rbdep4.Size = new Size(31, 17);
            rbdep4.TabIndex = 3;
            rbdep4.TabStop = true;
            rbdep4.Text = "4";
            rbdep4.UseVisualStyleBackColor = true;
            // 
            // rbdep3
            // 
            rbdep3.AutoSize = true;
            rbdep3.Location = new Point(160, 30);
            rbdep3.Name = "rbdep3";
            rbdep3.Size = new Size(31, 17);
            rbdep3.TabIndex = 2;
            rbdep3.TabStop = true;
            rbdep3.Text = "3";
            rbdep3.UseVisualStyleBackColor = true;
            // 
            // rbdep2
            // 
            rbdep2.AutoSize = true;
            rbdep2.Location = new Point(114, 30);
            rbdep2.Name = "rbdep2";
            rbdep2.Size = new Size(31, 17);
            rbdep2.TabIndex = 1;
            rbdep2.TabStop = true;
            rbdep2.Text = "2";
            rbdep2.UseVisualStyleBackColor = true;
            // 
            // rbdep1
            // 
            rbdep1.AutoSize = true;
            rbdep1.Location = new Point(69, 30);
            rbdep1.Name = "rbdep1";
            rbdep1.Size = new Size(31, 17);
            rbdep1.TabIndex = 0;
            rbdep1.TabStop = true;
            rbdep1.Text = "1";
            rbdep1.UseVisualStyleBackColor = true;
            // 
            // Label35
            // 
            Label35.AutoSize = true;
            Label35.Font = new Font("Microsoft Sans Serif", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label35.ForeColor = Color.Red;
            Label35.Location = new Point(89, 70);
            Label35.Name = "Label35";
            Label35.Size = new Size(18, 24);
            Label35.TabIndex = 88;
            Label35.Text = "*";
            // 
            // cbocivil
            // 
            cbocivil.FormattingEnabled = true;
            cbocivil.Items.AddRange(new object[] { "Zero Exemption", "Single", "Married" });
            cbocivil.Location = new Point(109, 288);
            cbocivil.Name = "cbocivil";
            cbocivil.Size = new Size(116, 21);
            cbocivil.TabIndex = 56;
            cbocivil.Text = "Single";
            // 
            // Label8
            // 
            Label8.AutoSize = true;
            Label8.Location = new Point(42, 291);
            Label8.Name = "Label8";
            Label8.Size = new Size(65, 13);
            Label8.TabIndex = 53;
            Label8.Text = "Civil Status :";
            // 
            // TabControl1
            // 
            TabControl1.Controls.Add(TabPage1);
            TabControl1.Controls.Add(TabPage3);
            TabControl1.Controls.Add(TabPage2);
            TabControl1.Location = new Point(14, 387);
            TabControl1.Name = "TabControl1";
            TabControl1.SelectedIndex = 0;
            TabControl1.Size = new Size(629, 135);
            TabControl1.TabIndex = 84;
            // 
            // TabPage1
            // 
            TabPage1.Controls.Add(Label27);
            TabPage1.Controls.Add(Label30);
            TabPage1.Controls.Add(txtcollegeYear);
            TabPage1.Controls.Add(txthschool_yeAR);
            TabPage1.Controls.Add(txtelem_year);
            TabPage1.Controls.Add(Label29);
            TabPage1.Controls.Add(txtcollege);
            TabPage1.Controls.Add(Label23);
            TabPage1.Controls.Add(txthschool);
            TabPage1.Controls.Add(Label22);
            TabPage1.Controls.Add(txtelem);
            TabPage1.Controls.Add(Label24);
            TabPage1.Location = new Point(4, 22);
            TabPage1.Name = "TabPage1";
            TabPage1.Padding = new Padding(3);
            TabPage1.Size = new Size(621, 109);
            TabPage1.TabIndex = 0;
            TabPage1.Text = "Educational Backround";
            TabPage1.UseVisualStyleBackColor = true;
            // 
            // Label27
            // 
            Label27.AutoSize = true;
            Label27.Location = new Point(362, 76);
            Label27.Name = "Label27";
            Label27.Size = new Size(35, 13);
            Label27.TabIndex = 9;
            Label27.Text = "Year :";
            // 
            // Label30
            // 
            Label30.AutoSize = true;
            Label30.Location = new Point(362, 50);
            Label30.Name = "Label30";
            Label30.Size = new Size(35, 13);
            Label30.TabIndex = 8;
            Label30.Text = "Year :";
            // 
            // txtcollegeYear
            // 
            txtcollegeYear.Location = new Point(411, 73);
            txtcollegeYear.Name = "txtcollegeYear";
            txtcollegeYear.Size = new Size(198, 20);
            txtcollegeYear.TabIndex = 5;
            // 
            // txthschool_yeAR
            // 
            txthschool_yeAR.Location = new Point(411, 47);
            txthschool_yeAR.Name = "txthschool_yeAR";
            txthschool_yeAR.Size = new Size(198, 20);
            txthschool_yeAR.TabIndex = 7;
            // 
            // txtelem_year
            // 
            txtelem_year.Location = new Point(411, 16);
            txtelem_year.Name = "txtelem_year";
            txtelem_year.Size = new Size(198, 20);
            txtelem_year.TabIndex = 6;
            // 
            // Label29
            // 
            Label29.AutoSize = true;
            Label29.Location = new Point(362, 19);
            Label29.Name = "Label29";
            Label29.Size = new Size(35, 13);
            Label29.TabIndex = 4;
            Label29.Text = "Year :";
            // 
            // txtcollege
            // 
            txtcollege.Location = new Point(111, 70);
            txtcollege.Name = "txtcollege";
            txtcollege.Size = new Size(238, 20);
            txtcollege.TabIndex = 1;
            // 
            // Label23
            // 
            Label23.AutoSize = true;
            Label23.Location = new Point(48, 73);
            Label23.Name = "Label23";
            Label23.Size = new Size(48, 13);
            Label23.TabIndex = 0;
            Label23.Text = "College :";
            // 
            // txthschool
            // 
            txthschool.Location = new Point(111, 44);
            txthschool.Name = "txthschool";
            txthschool.Size = new Size(238, 20);
            txthschool.TabIndex = 1;
            // 
            // Label22
            // 
            Label22.AutoSize = true;
            Label22.Location = new Point(27, 47);
            Label22.Name = "Label22";
            Label22.Size = new Size(71, 13);
            Label22.TabIndex = 0;
            Label22.Text = "High School :";
            // 
            // txtelem
            // 
            txtelem.Location = new Point(111, 18);
            txtelem.Name = "txtelem";
            txtelem.Size = new Size(238, 20);
            txtelem.TabIndex = 1;
            // 
            // Label24
            // 
            Label24.AutoSize = true;
            Label24.Location = new Point(27, 21);
            Label24.Name = "Label24";
            Label24.Size = new Size(65, 13);
            Label24.TabIndex = 0;
            Label24.Text = "Elementary :";
            // 
            // TabPage3
            // 
            TabPage3.Controls.Add(Label45);
            TabPage3.Controls.Add(Label46);
            TabPage3.Controls.Add(txtPHIC);
            TabPage3.Controls.Add(Label34);
            TabPage3.Controls.Add(Label44);
            TabPage3.Controls.Add(txtHDMF);
            TabPage3.Controls.Add(Label43);
            TabPage3.Controls.Add(Label33);
            TabPage3.Controls.Add(txtpc);
            TabPage3.Controls.Add(Label42);
            TabPage3.Controls.Add(Label41);
            TabPage3.Controls.Add(Label16);
            TabPage3.Controls.Add(Label19);
            TabPage3.Controls.Add(txtothers);
            TabPage3.Controls.Add(txtnbic);
            TabPage3.Controls.Add(Label32);
            TabPage3.Controls.Add(txtgl);
            TabPage3.Controls.Add(Label31);
            TabPage3.Location = new Point(4, 22);
            TabPage3.Name = "TabPage3";
            TabPage3.Size = new Size(621, 109);
            TabPage3.TabIndex = 2;
            TabPage3.Text = "License Record";
            TabPage3.UseVisualStyleBackColor = true;
            // 
            // Label45
            // 
            Label45.AutoSize = true;
            Label45.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label45.ForeColor = Color.Red;
            Label45.Location = new Point(458, 9);
            Label45.Name = "Label45";
            Label45.Size = new Size(15, 18);
            Label45.TabIndex = 104;
            Label45.Text = "*";
            // 
            // Label46
            // 
            Label46.AutoSize = true;
            Label46.Location = new Point(389, 11);
            Label46.Name = "Label46";
            Label46.Size = new Size(76, 13);
            Label46.TabIndex = 103;
            Label46.Text = "Philhealth No :";
            // 
            // txtPHIC
            // 
            txtPHIC.Location = new Point(392, 30);
            txtPHIC.Name = "txtPHIC";
            txtPHIC.Size = new Size(154, 20);
            txtPHIC.TabIndex = 102;
            // 
            // Label34
            // 
            Label34.AutoSize = true;
            Label34.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label34.ForeColor = Color.Red;
            Label34.Location = new Point(450, 55);
            Label34.Name = "Label34";
            Label34.Size = new Size(15, 18);
            Label34.TabIndex = 101;
            Label34.Text = "*";
            // 
            // Label44
            // 
            Label44.AutoSize = true;
            Label44.Location = new Point(389, 56);
            Label44.Name = "Label44";
            Label44.Size = new Size(65, 13);
            Label44.TabIndex = 100;
            Label44.Text = "Pagibig No :";
            // 
            // txtHDMF
            // 
            txtHDMF.Location = new Point(392, 75);
            txtHDMF.Name = "txtHDMF";
            txtHDMF.Size = new Size(154, 20);
            txtHDMF.TabIndex = 99;
            // 
            // Label43
            // 
            Label43.AutoSize = true;
            Label43.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label43.ForeColor = Color.Red;
            Label43.Location = new Point(114, 54);
            Label43.Name = "Label43";
            Label43.Size = new Size(15, 18);
            Label43.TabIndex = 98;
            Label43.Text = "*";
            // 
            // Label33
            // 
            Label33.AutoSize = true;
            Label33.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label33.ForeColor = Color.Red;
            Label33.Location = new Point(129, 12);
            Label33.Name = "Label33";
            Label33.Size = new Size(15, 18);
            Label33.TabIndex = 97;
            Label33.Text = "*";
            // 
            // txtpc
            // 
            txtpc.Format = DateTimePickerFormat.Short;
            txtpc.Location = new Point(31, 75);
            txtpc.Name = "txtpc";
            txtpc.Size = new Size(121, 20);
            txtpc.TabIndex = 96;
            // 
            // Label42
            // 
            Label42.AutoSize = true;
            Label42.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label42.ForeColor = Color.Red;
            Label42.Location = new Point(247, 13);
            Label42.Name = "Label42";
            Label42.Size = new Size(15, 18);
            Label42.TabIndex = 95;
            Label42.Text = "*";
            // 
            // Label41
            // 
            Label41.AutoSize = true;
            Label41.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label41.ForeColor = Color.Red;
            Label41.Location = new Point(250, 56);
            Label41.Name = "Label41";
            Label41.Size = new Size(15, 18);
            Label41.TabIndex = 94;
            Label41.Text = "*";
            // 
            // Label16
            // 
            Label16.AutoSize = true;
            Label16.Location = new Point(207, 59);
            Label16.Name = "Label16";
            Label16.Size = new Size(51, 13);
            Label16.TabIndex = 12;
            Label16.Text = "SSS No :";
            // 
            // Label19
            // 
            Label19.AutoSize = true;
            Label19.Location = new Point(207, 17);
            Label19.Name = "Label19";
            Label19.Size = new Size(45, 13);
            Label19.TabIndex = 10;
            Label19.Text = "TIN No.";
            // 
            // txtothers
            // 
            txtothers.Location = new Point(210, 78);
            txtothers.Name = "txtothers";
            txtothers.Size = new Size(154, 20);
            txtothers.TabIndex = 9;
            // 
            // txtnbic
            // 
            txtnbic.Location = new Point(210, 33);
            txtnbic.Name = "txtnbic";
            txtnbic.Size = new Size(154, 20);
            txtnbic.TabIndex = 7;
            // 
            // Label32
            // 
            Label32.AutoSize = true;
            Label32.Location = new Point(32, 61);
            Label32.Name = "Label32";
            Label32.Size = new Size(82, 13);
            Label32.TabIndex = 4;
            Label32.Text = "Expiration Date.";
            // 
            // txtgl
            // 
            txtgl.Location = new Point(31, 33);
            txtgl.Name = "txtgl";
            txtgl.Size = new Size(173, 20);
            txtgl.TabIndex = 3;
            // 
            // Label31
            // 
            Label31.AutoSize = true;
            Label31.Location = new Point(32, 17);
            Label31.Name = "Label31";
            Label31.Size = new Size(97, 13);
            Label31.TabIndex = 2;
            Label31.Text = "Guard Licence No.";
            // 
            // cboworkstat
            // 
            cboworkstat.Enabled = false;
            cboworkstat.FormattingEnabled = true;
            cboworkstat.Items.AddRange(new object[] { "Active" });
            cboworkstat.Location = new Point(341, 254);
            cboworkstat.Name = "cboworkstat";
            cboworkstat.Size = new Size(86, 21);
            cboworkstat.TabIndex = 39;
            cboworkstat.Text = "Active";
            // 
            // dtpHiredate
            // 
            dtpHiredate.Format = DateTimePickerFormat.Short;
            dtpHiredate.Location = new Point(112, 254);
            dtpHiredate.Name = "dtpHiredate";
            dtpHiredate.Size = new Size(105, 20);
            dtpHiredate.TabIndex = 38;
            // 
            // Label21
            // 
            Label21.AutoSize = true;
            Label21.Location = new Point(294, 233);
            Label21.Name = "Label21";
            Label21.Size = new Size(88, 13);
            Label21.TabIndex = 83;
            Label21.Text = "Current Address :";
            // 
            // Label25
            // 
            Label25.AutoSize = true;
            Label25.Location = new Point(484, 258);
            Label25.Name = "Label25";
            Label25.Size = new Size(50, 13);
            Label25.TabIndex = 17;
            Label25.Text = "Position :";
            // 
            // txtmotheradd
            // 
            txtmotheradd.Location = new Point(392, 226);
            txtmotheradd.Name = "txtmotheradd";
            txtmotheradd.Size = new Size(238, 20);
            txtmotheradd.TabIndex = 82;
            // 
            // Label26
            // 
            Label26.AutoSize = true;
            Label26.Location = new Point(292, 261);
            Label26.Name = "Label26";
            Label26.Size = new Size(43, 13);
            Label26.TabIndex = 15;
            Label26.Text = "Status :";
            // 
            // txtfatheradd
            // 
            txtfatheradd.Location = new Point(392, 200);
            txtfatheradd.Name = "txtfatheradd";
            txtfatheradd.Size = new Size(238, 20);
            txtfatheradd.TabIndex = 81;
            // 
            // Label28
            // 
            Label28.AutoSize = true;
            Label28.Location = new Point(37, 261);
            Label28.Name = "Label28";
            Label28.Size = new Size(64, 13);
            Label28.TabIndex = 13;
            Label28.Text = "Hired Date :";
            // 
            // Label17
            // 
            Label17.AutoSize = true;
            Label17.Location = new Point(294, 207);
            Label17.Name = "Label17";
            Label17.Size = new Size(88, 13);
            Label17.TabIndex = 80;
            Label17.Text = "Current Address :";
            // 
            // txtsadd
            // 
            txtsadd.Enabled = false;
            txtsadd.Location = new Point(392, 353);
            txtsadd.Name = "txtsadd";
            txtsadd.Size = new Size(238, 20);
            txtsadd.TabIndex = 79;
            // 
            // lblsadd
            // 
            lblsadd.AutoSize = true;
            lblsadd.Location = new Point(333, 356);
            lblsadd.Name = "lblsadd";
            lblsadd.Size = new Size(51, 13);
            lblsadd.TabIndex = 78;
            lblsadd.Text = "Address :";
            // 
            // txtmothername
            // 
            txtmothername.Location = new Point(112, 228);
            txtmothername.Name = "txtmothername";
            txtmothername.Size = new Size(152, 20);
            txtmothername.TabIndex = 77;
            // 
            // Label20
            // 
            Label20.AutoSize = true;
            Label20.Location = new Point(23, 235);
            Label20.Name = "Label20";
            Label20.Size = new Size(84, 13);
            Label20.TabIndex = 76;
            Label20.Text = "Mother's Name :";
            // 
            // txtfathername
            // 
            txtfathername.Location = new Point(112, 202);
            txtfathername.Name = "txtfathername";
            txtfathername.Size = new Size(152, 20);
            txtfathername.TabIndex = 75;
            // 
            // Label18
            // 
            Label18.AutoSize = true;
            Label18.Location = new Point(23, 209);
            Label18.Name = "Label18";
            Label18.Size = new Size(81, 13);
            Label18.TabIndex = 74;
            Label18.Text = "Father's Name :";
            // 
            // txtnamSpouse
            // 
            txtnamSpouse.Enabled = false;
            txtnamSpouse.Location = new Point(392, 327);
            txtnamSpouse.Name = "txtnamSpouse";
            txtnamSpouse.Size = new Size(152, 20);
            txtnamSpouse.TabIndex = 73;
            // 
            // lblspouse
            // 
            lblspouse.AutoSize = true;
            lblspouse.Location = new Point(304, 334);
            lblspouse.Name = "lblspouse";
            lblspouse.Size = new Size(80, 13);
            lblspouse.TabIndex = 72;
            lblspouse.Text = "Spouse Name :";
            // 
            // rdofemale
            // 
            rdofemale.AutoSize = true;
            rdofemale.Location = new Point(167, 97);
            rdofemale.Name = "rdofemale";
            rdofemale.Size = new Size(59, 17);
            rdofemale.TabIndex = 71;
            rdofemale.TabStop = true;
            rdofemale.Text = "Female";
            rdofemale.UseVisualStyleBackColor = true;
            // 
            // rdomale
            // 
            rdomale.AutoSize = true;
            rdomale.Location = new Point(112, 96);
            rdomale.Name = "rdomale";
            rdomale.Size = new Size(48, 17);
            rdomale.TabIndex = 70;
            rdomale.TabStop = true;
            rdomale.Text = "Male";
            rdomale.UseVisualStyleBackColor = true;
            // 
            // dtpbdate
            // 
            dtpbdate.Format = DateTimePickerFormat.Short;
            dtpbdate.Location = new Point(343, 96);
            dtpbdate.Name = "dtpbdate";
            dtpbdate.Size = new Size(121, 20);
            dtpbdate.TabIndex = 69;
            // 
            // txtreligon
            // 
            txtreligon.Location = new Point(320, 176);
            txtreligon.Name = "txtreligon";
            txtreligon.Size = new Size(144, 20);
            txtreligon.TabIndex = 68;
            // 
            // Label13
            // 
            Label13.AutoSize = true;
            Label13.Location = new Point(265, 179);
            Label13.Name = "Label13";
            Label13.Size = new Size(49, 13);
            Label13.TabIndex = 65;
            Label13.Text = "Religon :";
            // 
            // txtcitizen
            // 
            txtcitizen.Location = new Point(112, 176);
            txtcitizen.Name = "txtcitizen";
            txtcitizen.Size = new Size(110, 20);
            txtcitizen.TabIndex = 67;
            // 
            // Label14
            // 
            Label14.AutoSize = true;
            Label14.Location = new Point(25, 183);
            Label14.Name = "Label14";
            Label14.Size = new Size(63, 13);
            Label14.TabIndex = 66;
            Label14.Text = "Citizenship :";
            // 
            // txtHeight
            // 
            txtHeight.Location = new Point(348, 147);
            txtHeight.Name = "txtHeight";
            txtHeight.Size = new Size(60, 20);
            txtHeight.TabIndex = 64;
            // 
            // Label11
            // 
            Label11.AutoSize = true;
            Label11.Location = new Point(270, 152);
            Label11.Name = "Label11";
            Label11.Size = new Size(73, 13);
            Label11.TabIndex = 61;
            Label11.Text = "Height ( cm ) :";
            // 
            // txtContact
            // 
            txtContact.Location = new Point(112, 150);
            txtContact.Name = "txtContact";
            txtContact.Size = new Size(110, 20);
            txtContact.TabIndex = 63;
            // 
            // Label12
            // 
            Label12.AutoSize = true;
            Label12.Location = new Point(24, 157);
            Label12.Name = "Label12";
            Label12.Size = new Size(70, 13);
            Label12.TabIndex = 62;
            Label12.Text = "Contact No. :";
            // 
            // txtbplace
            // 
            txtbplace.Location = new Point(112, 122);
            txtbplace.Name = "txtbplace";
            txtbplace.Size = new Size(352, 20);
            txtbplace.TabIndex = 60;
            // 
            // Label9
            // 
            Label9.AutoSize = true;
            Label9.Location = new Point(23, 129);
            Label9.Name = "Label9";
            Label9.Size = new Size(51, 13);
            Label9.TabIndex = 59;
            Label9.Text = "Address :";
            // 
            // Label7
            // 
            Label7.AutoSize = true;
            Label7.Location = new Point(278, 100);
            Label7.Name = "Label7";
            Label7.Size = new Size(57, 13);
            Label7.TabIndex = 57;
            Label7.Text = "BirthDate :";
            // 
            // Label15
            // 
            Label15.AutoSize = true;
            Label15.Location = new Point(23, 99);
            Label15.Name = "Label15";
            Label15.Size = new Size(48, 13);
            Label15.TabIndex = 58;
            Label15.Text = "Gender :";
            // 
            // txtweight
            // 
            txtweight.Location = new Point(505, 148);
            txtweight.Name = "txtweight";
            txtweight.Size = new Size(75, 20);
            txtweight.TabIndex = 55;
            // 
            // Label10
            // 
            Label10.AutoSize = true;
            Label10.Location = new Point(422, 152);
            Label10.Name = "Label10";
            Label10.Size = new Size(75, 13);
            Label10.TabIndex = 54;
            Label10.Text = "Weight ( lbs ) :";
            // 
            // txtage
            // 
            txtage.Enabled = false;
            txtage.Location = new Point(538, 118);
            txtage.Name = "txtage";
            txtage.Size = new Size(75, 20);
            txtage.TabIndex = 52;
            txtage.TextAlign = HorizontalAlignment.Center;
            // 
            // Label5
            // 
            Label5.AutoSize = true;
            Label5.Location = new Point(500, 125);
            Label5.Name = "Label5";
            Label5.Size = new Size(32, 13);
            Label5.TabIndex = 51;
            Label5.Text = "Age :";
            // 
            // txtmname
            // 
            txtmname.Location = new Point(538, 70);
            txtmname.Name = "txtmname";
            txtmname.Size = new Size(75, 20);
            txtmname.TabIndex = 50;
            // 
            // Label6
            // 
            Label6.AutoSize = true;
            Label6.Location = new Point(542, 54);
            Label6.Name = "Label6";
            Label6.Size = new Size(22, 13);
            Label6.TabIndex = 49;
            Label6.Text = "M.I";
            // 
            // Label1
            // 
            Label1.AutoSize = true;
            Label1.Location = new Point(23, 77);
            Label1.Name = "Label1";
            Label1.Size = new Size(41, 13);
            Label1.TabIndex = 48;
            Label1.Text = "Name :";
            // 
            // txtemp_id
            // 
            txtemp_id.Enabled = false;
            txtemp_id.Location = new Point(109, 27);
            txtemp_id.Name = "txtemp_id";
            txtemp_id.Size = new Size(155, 20);
            txtemp_id.TabIndex = 47;
            // 
            // label
            // 
            label.AutoSize = true;
            label.Location = new Point(25, 30);
            label.Name = "label";
            label.Size = new Size(76, 13);
            label.TabIndex = 46;
            label.Text = "Employees Id :";
            // 
            // txtfname
            // 
            txtfname.Location = new Point(297, 70);
            txtfname.Name = "txtfname";
            txtfname.Size = new Size(167, 20);
            txtfname.TabIndex = 45;
            // 
            // Label3
            // 
            Label3.AutoSize = true;
            Label3.Location = new Point(300, 54);
            Label3.Name = "Label3";
            Label3.Size = new Size(57, 13);
            Label3.TabIndex = 42;
            Label3.Text = "First Name";
            // 
            // txtlname
            // 
            txtlname.Location = new Point(109, 69);
            txtlname.Name = "txtlname";
            txtlname.Size = new Size(155, 20);
            txtlname.TabIndex = 44;
            // 
            // Label2
            // 
            Label2.AutoSize = true;
            Label2.Location = new Point(113, 54);
            Label2.Name = "Label2";
            Label2.Size = new Size(58, 13);
            Label2.TabIndex = 43;
            Label2.Text = "Last Name";
            // 
            // btnadd
            // 
            btnadd.Location = new Point(505, 585);
            btnadd.Name = "btnadd";
            btnadd.Size = new Size(147, 32);
            btnadd.TabIndex = 40;
            btnadd.Text = "Save";
            btnadd.UseVisualStyleBackColor = true;
            // 
            // OpenFileDialog1
            // 
            OpenFileDialog1.FileName = "OpenFileDialog1";
            // 
            // Button1
            // 
            Button1.Location = new Point(368, 585);
            Button1.Name = "Button1";
            Button1.Size = new Size(131, 32);
            Button1.TabIndex = 42;
            Button1.Text = "Take Picture";
            Button1.UseVisualStyleBackColor = true;
            // 
            // TabPage2
            // 
            TabPage2.Controls.Add(txtwedate3);
            TabPage2.Controls.Add(txtwedate2);
            TabPage2.Controls.Add(txtwedate1);
            TabPage2.Controls.Add(Label50);
            TabPage2.Controls.Add(Label48);
            TabPage2.Controls.Add(Label47);
            TabPage2.Controls.Add(txtwepos3);
            TabPage2.Controls.Add(txtwepos2);
            TabPage2.Controls.Add(txtwepos1);
            TabPage2.Controls.Add(txtwecom3);
            TabPage2.Controls.Add(txtwecom2);
            TabPage2.Controls.Add(txtwecom1);
            TabPage2.Location = new Point(4, 22);
            TabPage2.Name = "TabPage2";
            TabPage2.Padding = new Padding(3);
            TabPage2.Size = new Size(621, 109);
            TabPage2.TabIndex = 3;
            TabPage2.Text = "Work Experience";
            TabPage2.UseVisualStyleBackColor = true;
            // 
            // txtwecom1
            // 
            txtwecom1.Location = new Point(17, 30);
            txtwecom1.Name = "txtwecom1";
            txtwecom1.Size = new Size(289, 20);
            txtwecom1.TabIndex = 95;
            // 
            // txtwecom2
            // 
            txtwecom2.Location = new Point(17, 55);
            txtwecom2.Name = "txtwecom2";
            txtwecom2.Size = new Size(289, 20);
            txtwecom2.TabIndex = 101;
            // 
            // txtwecom3
            // 
            txtwecom3.Location = new Point(17, 81);
            txtwecom3.Name = "txtwecom3";
            txtwecom3.Size = new Size(289, 20);
            txtwecom3.TabIndex = 102;
            // 
            // txtwepos1
            // 
            txtwepos1.Location = new Point(313, 29);
            txtwepos1.Name = "txtwepos1";
            txtwepos1.Size = new Size(186, 20);
            txtwepos1.TabIndex = 103;
            // 
            // txtwepos2
            // 
            txtwepos2.Location = new Point(313, 55);
            txtwepos2.Name = "txtwepos2";
            txtwepos2.Size = new Size(186, 20);
            txtwepos2.TabIndex = 104;
            // 
            // txtwepos3
            // 
            txtwepos3.Location = new Point(313, 81);
            txtwepos3.Name = "txtwepos3";
            txtwepos3.Size = new Size(186, 20);
            txtwepos3.TabIndex = 105;
            // 
            // Label47
            // 
            Label47.AutoSize = true;
            Label47.Location = new Point(21, 11);
            Label47.Name = "Label47";
            Label47.Size = new Size(51, 13);
            Label47.TabIndex = 95;
            Label47.Text = "Company";
            // 
            // Label48
            // 
            Label48.AutoSize = true;
            Label48.Location = new Point(508, 10);
            Label48.Name = "Label48";
            Label48.Size = new Size(75, 13);
            Label48.TabIndex = 106;
            Label48.Text = "Inclusive Date";
            // 
            // Label50
            // 
            Label50.AutoSize = true;
            Label50.Location = new Point(316, 11);
            Label50.Name = "Label50";
            Label50.Size = new Size(44, 13);
            Label50.TabIndex = 108;
            Label50.Text = "Position";
            // 
            // txtwedate1
            // 
            txtwedate1.Location = new Point(505, 29);
            txtwedate1.Name = "txtwedate1";
            txtwedate1.Size = new Size(107, 20);
            txtwedate1.TabIndex = 95;
            // 
            // txtwedate2
            // 
            txtwedate2.Location = new Point(505, 55);
            txtwedate2.Name = "txtwedate2";
            txtwedate2.Size = new Size(107, 20);
            txtwedate2.TabIndex = 109;
            // 
            // txtwedate3
            // 
            txtwedate3.Location = new Point(505, 81);
            txtwedate3.Name = "txtwedate3";
            txtwedate3.Size = new Size(107, 20);
            txtwedate3.TabIndex = 110;
            // 
            // newemployee
            // 
            AutoScaleDimensions = new SizeF(6.0f, 13.0f);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(663, 619);
            Controls.Add(Button1);
            Controls.Add(btnadd);
            Controls.Add(GroupBox1);
            Controls.Add(Panel1);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Name = "newemployee";
            StartPosition = FormStartPosition.CenterScreen;
            Panel1.ResumeLayout(false);
            GroupBox1.ResumeLayout(false);
            GroupBox1.PerformLayout();
            GroupBox2.ResumeLayout(false);
            GroupBox2.PerformLayout();
            TabControl1.ResumeLayout(false);
            TabPage1.ResumeLayout(false);
            TabPage1.PerformLayout();
            TabPage3.ResumeLayout(false);
            TabPage3.PerformLayout();
            TabPage2.ResumeLayout(false);
            TabPage2.PerformLayout();
            Load += new EventHandler(newemployee_Load);
            ResumeLayout(false);

        }
        internal Panel Panel1;
        internal Label Label4;
        internal GroupBox GroupBox1;
        internal TextBox txtemp_id;
        internal Label label;
        internal TextBox txtfname;
        internal Label Label3;
        internal TextBox txtlname;
        internal Label Label2;
        internal ComboBox cbocivil;
        internal TextBox txtweight;
        internal Label Label10;
        internal Label Label8;
        internal TextBox txtage;
        internal Label Label5;
        internal TextBox txtmname;
        internal Label Label6;
        internal Label Label1;
        internal ComboBox cboworkstat;
        internal DateTimePicker dtpHiredate;
        internal Label Label25;
        internal Label Label26;
        internal Label Label28;
        internal Label Label21;
        internal TextBox txtmotheradd;
        internal TextBox txtfatheradd;
        internal Label Label17;
        internal TextBox txtsadd;
        internal Label lblsadd;
        internal TextBox txtmothername;
        internal Label Label20;
        internal TextBox txtfathername;
        internal Label Label18;
        internal TextBox txtnamSpouse;
        internal Label lblspouse;
        internal RadioButton rdofemale;
        internal RadioButton rdomale;
        internal DateTimePicker dtpbdate;
        internal TextBox txtreligon;
        internal Label Label13;
        internal TextBox txtcitizen;
        internal Label Label14;
        internal TextBox txtHeight;
        internal Label Label11;
        internal TextBox txtContact;
        internal Label Label12;
        internal TextBox txtbplace;
        internal Label Label9;
        internal Label Label7;
        internal Label Label15;
        internal TabControl TabControl1;
        internal TabPage TabPage1;
        internal Label Label27;
        internal Label Label30;
        internal MaskedTextBox txtcollegeYear;
        internal MaskedTextBox txthschool_yeAR;
        internal MaskedTextBox txtelem_year;
        internal Label Label29;
        internal MaskedTextBox txtcollege;
        internal Label Label23;
        internal MaskedTextBox txthschool;
        internal Label Label22;
        internal MaskedTextBox txtelem;
        internal Label Label24;
        internal TabPage TabPage3;
        internal Button btnadd;
        internal GroupBox GroupBox2;
        internal RadioButton rbdep4;
        internal RadioButton rbdep3;
        internal RadioButton rbdep2;
        internal RadioButton rbdep1;
        internal RadioButton rbdep0;
        internal OpenFileDialog OpenFileDialog1;
        internal SaveFileDialog SaveFileDialog1;
        internal Label Label32;
        internal MaskedTextBox txtgl;
        internal Label Label31;
        internal Button Button1;
        internal Label Label39;
        internal Label Label38;
        internal Label Label37;
        internal Label Label36;
        internal Label Label35;
        internal Label Label16;
        internal Label Label19;
        internal MaskedTextBox txtothers;
        internal MaskedTextBox txtnbic;
        internal Label Label40;
        internal Label Label42;
        internal Label Label41;
        internal Label Label43;
        internal Label Label33;
        internal DateTimePicker txtpc;
        internal TextBox cbpositon;
        internal Label Label45;
        internal Label Label46;
        internal MaskedTextBox txtPHIC;
        internal Label Label34;
        internal Label Label44;
        internal MaskedTextBox txtHDMF;
        internal TabPage TabPage2;
        internal TextBox txtwepos2;
        internal TextBox txtwepos1;
        internal TextBox txtwecom3;
        internal TextBox txtwecom2;
        internal TextBox txtwecom1;
        internal Label Label50;
        internal Label Label48;
        internal Label Label47;
        internal TextBox txtwepos3;
        internal TextBox txtwedate3;
        internal TextBox txtwedate2;
        internal TextBox txtwedate1;
    }
}
﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace Ichiban
{
    [Microsoft.VisualBasic.CompilerServices.DesignerGenerated()]
    public partial class popup : Form
    {

        // Form overrides dispose to clean up the component list.
        [DebuggerNonUserCode()]
        protected override void Dispose(bool disposing)
        {
            try
            {
                if (disposing && components is not null)
                {
                    components.Dispose();
                }
            }
            finally
            {
                base.Dispose(disposing);
            }
        }

        // Required by the Windows Form Designer
        private System.ComponentModel.IContainer components;

        // NOTE: The following procedure is required by the Windows Form Designer
        // It can be modified using the Windows Form Designer.  
        // Do not modify it using the code editor.
        [DebuggerStepThrough()]
        private void InitializeComponent()
        {
            GroupBox1 = new GroupBox();
            Button1 = new Button();
            Button1.Click += new EventHandler(Button1_Click);
            DataGridView4 = new DataGridView();
            Label44 = new Label();
            txtsearch = new TextBox();
            txtsearch.TextChanged += new EventHandler(txtsearch_TextChanged);
            Panel1 = new Panel();
            Label4 = new Label();
            GroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)DataGridView4).BeginInit();
            Panel1.SuspendLayout();
            SuspendLayout();
            // 
            // GroupBox1
            // 
            GroupBox1.Controls.Add(Button1);
            GroupBox1.Controls.Add(DataGridView4);
            GroupBox1.Controls.Add(Label44);
            GroupBox1.Controls.Add(txtsearch);
            GroupBox1.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            GroupBox1.Location = new Point(12, 53);
            GroupBox1.Name = "GroupBox1";
            GroupBox1.Size = new Size(605, 367);
            GroupBox1.TabIndex = 29;
            GroupBox1.TabStop = false;
            GroupBox1.Text = "Filter for Employee Data";
            // 
            // Button1
            // 
            Button1.Location = new Point(540, 34);
            Button1.Name = "Button1";
            Button1.Size = new Size(54, 30);
            Button1.TabIndex = 28;
            Button1.Text = "Use";
            Button1.UseVisualStyleBackColor = true;
            // 
            // DataGridView4
            // 
            DataGridView4.AllowUserToAddRows = false;
            DataGridView4.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DataGridView4.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DataGridView4.Location = new Point(12, 70);
            DataGridView4.Name = "DataGridView4";
            DataGridView4.RowHeadersVisible = false;
            DataGridView4.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            DataGridView4.Size = new Size(582, 290);
            DataGridView4.TabIndex = 25;
            // 
            // Label44
            // 
            Label44.AutoSize = true;
            Label44.Location = new Point(14, 26);
            Label44.Name = "Label44";
            Label44.Size = new Size(176, 16);
            Label44.TabIndex = 26;
            Label44.Text = "Search Name of Employee :";
            // 
            // txtsearch
            // 
            txtsearch.Location = new Point(13, 44);
            txtsearch.Name = "txtsearch";
            txtsearch.Size = new Size(315, 22);
            txtsearch.TabIndex = 27;
            // 
            // Panel1
            // 
            Panel1.BackColor = SystemColors.ActiveCaption;
            Panel1.Controls.Add(Label4);
            Panel1.Dock = DockStyle.Top;
            Panel1.Location = new Point(0, 0);
            Panel1.Name = "Panel1";
            Panel1.Size = new Size(623, 51);
            Panel1.TabIndex = 30;
            // 
            // Label4
            // 
            Label4.Font = new Font("Microsoft Sans Serif", 18.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label4.ForeColor = SystemColors.HighlightText;
            Label4.Location = new Point(3, 9);
            Label4.Name = "Label4";
            Label4.Size = new Size(348, 33);
            Label4.TabIndex = 1;
            Label4.Text = "Select Employee";
            // 
            // popup
            // 
            AutoScaleDimensions = new SizeF(6.0f, 13.0f);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(623, 430);
            Controls.Add(Panel1);
            Controls.Add(GroupBox1);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Name = "popup";
            StartPosition = FormStartPosition.CenterScreen;
            GroupBox1.ResumeLayout(false);
            GroupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)DataGridView4).EndInit();
            Panel1.ResumeLayout(false);
            ResumeLayout(false);

        }
        internal GroupBox GroupBox1;
        internal Button Button1;
        internal DataGridView DataGridView4;
        internal Label Label44;
        internal TextBox txtsearch;
        internal Panel Panel1;
        internal Label Label4;
    }
}
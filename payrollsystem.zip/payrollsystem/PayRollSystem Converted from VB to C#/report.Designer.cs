﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace Ichiban
{
    [Microsoft.VisualBasic.CompilerServices.DesignerGenerated()]
    public partial class reportType : Form
    {

        // Form overrides dispose to clean up the component list.
        [DebuggerNonUserCode()]
        protected override void Dispose(bool disposing)
        {
            try
            {
                if (disposing && components is not null)
                {
                    components.Dispose();
                }
            }
            finally
            {
                base.Dispose(disposing);
            }
        }

        // Required by the Windows Form Designer
        private System.ComponentModel.IContainer components;

        // NOTE: The following procedure is required by the Windows Form Designer
        // It can be modified using the Windows Form Designer.  
        // Do not modify it using the code editor.
        [DebuggerStepThrough()]
        private void InitializeComponent()
        {
            CrystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            Panel1 = new Panel();
            Button5 = new Button();
            Button5.Click += new EventHandler(Button5_Click);
            Button4 = new Button();
            Button4.Click += new EventHandler(Button4_Click);
            Button3 = new Button();
            Button3.Click += new EventHandler(Button3_Click);
            Button2 = new Button();
            Button2.Click += new EventHandler(Button2_Click);
            Button1 = new Button();
            Button1.Click += new EventHandler(Button1_Click);
            Label15 = new Label();
            dtpPeriodEnd = new DateTimePicker();
            Label14 = new Label();
            dtpPeriodStart = new DateTimePicker();
            Panel2 = new Panel();
            Button6 = new Button();
            Button6.Click += new EventHandler(Button6_Click);
            Panel1.SuspendLayout();
            Panel2.SuspendLayout();
            SuspendLayout();
            // 
            // CrystalReportViewer1
            // 
            CrystalReportViewer1.ActiveViewIndex = -1;
            CrystalReportViewer1.BorderStyle = BorderStyle.FixedSingle;
            CrystalReportViewer1.DisplayGroupTree = false;
            CrystalReportViewer1.Dock = DockStyle.Fill;
            CrystalReportViewer1.Location = new Point(0, 0);
            CrystalReportViewer1.Name = "CrystalReportViewer1";
            CrystalReportViewer1.SelectionFormula = "";
            CrystalReportViewer1.Size = new Size(774, 533);
            CrystalReportViewer1.TabIndex = 0;
            CrystalReportViewer1.ViewTimeSelectionFormula = "";
            // 
            // Panel1
            // 
            Panel1.Controls.Add(Button6);
            Panel1.Controls.Add(Button5);
            Panel1.Controls.Add(Button4);
            Panel1.Controls.Add(Button3);
            Panel1.Controls.Add(Button2);
            Panel1.Controls.Add(Button1);
            Panel1.Controls.Add(Label15);
            Panel1.Controls.Add(dtpPeriodEnd);
            Panel1.Controls.Add(Label14);
            Panel1.Controls.Add(dtpPeriodStart);
            Panel1.Dock = DockStyle.Left;
            Panel1.Location = new Point(0, 0);
            Panel1.Name = "Panel1";
            Panel1.Size = new Size(133, 533);
            Panel1.TabIndex = 1;
            // 
            // Button5
            // 
            Button5.Location = new Point(8, 147);
            Button5.Name = "Button5";
            Button5.Size = new Size(114, 23);
            Button5.TabIndex = 101;
            Button5.Text = "Payroll Summary";
            Button5.UseVisualStyleBackColor = true;
            // 
            // Button4
            // 
            Button4.Location = new Point(8, 289);
            Button4.Name = "Button4";
            Button4.Size = new Size(114, 23);
            Button4.TabIndex = 100;
            Button4.Text = "Client List";
            Button4.UseVisualStyleBackColor = true;
            // 
            // Button3
            // 
            Button3.Location = new Point(7, 260);
            Button3.Name = "Button3";
            Button3.Size = new Size(114, 23);
            Button3.TabIndex = 99;
            Button3.Text = "Employee List";
            Button3.UseVisualStyleBackColor = true;
            // 
            // Button2
            // 
            Button2.Location = new Point(8, 118);
            Button2.Name = "Button2";
            Button2.Size = new Size(114, 23);
            Button2.TabIndex = 98;
            Button2.Text = "Generate Payslip";
            Button2.UseVisualStyleBackColor = true;
            // 
            // Button1
            // 
            Button1.Location = new Point(7, 213);
            Button1.Name = "Button1";
            Button1.Size = new Size(114, 41);
            Button1.TabIndex = 97;
            Button1.Text = "Payroll Summary Print All";
            Button1.UseVisualStyleBackColor = true;
            // 
            // Label15
            // 
            Label15.AutoSize = true;
            Label15.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label15.Location = new Point(12, 69);
            Label15.Name = "Label15";
            Label15.Size = new Size(65, 13);
            Label15.TabIndex = 93;
            Label15.Text = "Period End :";
            // 
            // dtpPeriodEnd
            // 
            dtpPeriodEnd.Format = DateTimePickerFormat.Short;
            dtpPeriodEnd.Location = new Point(9, 83);
            dtpPeriodEnd.Name = "dtpPeriodEnd";
            dtpPeriodEnd.Size = new Size(114, 20);
            dtpPeriodEnd.TabIndex = 91;
            // 
            // Label14
            // 
            Label14.AutoSize = true;
            Label14.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label14.Location = new Point(11, 32);
            Label14.Name = "Label14";
            Label14.Size = new Size(68, 13);
            Label14.TabIndex = 92;
            Label14.Text = "Period Start :";
            // 
            // dtpPeriodStart
            // 
            dtpPeriodStart.Format = DateTimePickerFormat.Short;
            dtpPeriodStart.Location = new Point(8, 47);
            dtpPeriodStart.Name = "dtpPeriodStart";
            dtpPeriodStart.Size = new Size(114, 20);
            dtpPeriodStart.TabIndex = 90;
            // 
            // Panel2
            // 
            Panel2.Controls.Add(CrystalReportViewer1);
            Panel2.Dock = DockStyle.Fill;
            Panel2.Location = new Point(133, 0);
            Panel2.Name = "Panel2";
            Panel2.Size = new Size(774, 533);
            Panel2.TabIndex = 2;
            // 
            // Button6
            // 
            Button6.Location = new Point(8, 318);
            Button6.Name = "Button6";
            Button6.Size = new Size(114, 42);
            Button6.TabIndex = 102;
            Button6.Text = "Client List and Guards";
            Button6.UseVisualStyleBackColor = true;
            // 
            // report
            // 
            AutoScaleDimensions = new SizeF(6.0f, 13.0f);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(907, 533);
            Controls.Add(Panel2);
            Controls.Add(Panel1);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Name = "report";
            StartPosition = FormStartPosition.CenterScreen;
            WindowState = FormWindowState.Maximized;
            Panel1.ResumeLayout(false);
            Panel1.PerformLayout();
            Panel2.ResumeLayout(false);
            Load += new EventHandler(report_Load);
            ResumeLayout(false);

        }
        internal CrystalDecisions.Windows.Forms.CrystalReportViewer CrystalReportViewer1;
        internal Panel Panel1;
        internal Panel Panel2;
        internal Label Label15;
        internal DateTimePicker dtpPeriodEnd;
        internal Label Label14;
        internal DateTimePicker dtpPeriodStart;
        internal Button Button5;
        internal Button Button4;
        internal Button Button3;
        internal Button Button2;
        internal Button Button1;
        internal Button Button6;
    }
}
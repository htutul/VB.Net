﻿using System;
using System.ComponentModel;
using System.Diagnostics;

namespace Ichiban.My
{
    internal static partial class MyProject
    {
        internal partial class MyForms
        {

            [EditorBrowsable(EditorBrowsableState.Never)]
            public assign m_assign;

            public assign assign
            {
                [DebuggerHidden]
                get
                {
                    m_assign = Create__Instance__(m_assign);
                    return m_assign;
                }
                [DebuggerHidden]
                set
                {
                    if (ReferenceEquals(value, m_assign))
                        return;
                    if (value is not null)
                        throw new ArgumentException("Property can only be set to Nothing");
                    Dispose__Instance__(ref m_assign);
                }
            }


            [EditorBrowsable(EditorBrowsableState.Never)]
            public client m_client;

            public client client
            {
                [DebuggerHidden]
                get
                {
                    m_client = Create__Instance__(m_client);
                    return m_client;
                }
                [DebuggerHidden]
                set
                {
                    if (ReferenceEquals(value, m_client))
                        return;
                    if (value is not null)
                        throw new ArgumentException("Property can only be set to Nothing");
                    Dispose__Instance__(ref m_client);
                }
            }


            [EditorBrowsable(EditorBrowsableState.Never)]
            public employee m_employee;

            public employee employee
            {
                [DebuggerHidden]
                get
                {
                    m_employee = Create__Instance__(m_employee);
                    return m_employee;
                }
                [DebuggerHidden]
                set
                {
                    if (ReferenceEquals(value, m_employee))
                        return;
                    if (value is not null)
                        throw new ArgumentException("Property can only be set to Nothing");
                    Dispose__Instance__(ref m_employee);
                }
            }


            [EditorBrowsable(EditorBrowsableState.Never)]
            public Form1 m_Form1;

            public Form1 Form1
            {
                [DebuggerHidden]
                get
                {
                    m_Form1 = Create__Instance__(m_Form1);
                    return m_Form1;
                }
                [DebuggerHidden]
                set
                {
                    if (ReferenceEquals(value, m_Form1))
                        return;
                    if (value is not null)
                        throw new ArgumentException("Property can only be set to Nothing");
                    Dispose__Instance__(ref m_Form1);
                }
            }


            [EditorBrowsable(EditorBrowsableState.Never)]
            public frmCamera m_frmCamera;

            public frmCamera frmCamera
            {
                [DebuggerHidden]
                get
                {
                    m_frmCamera = Create__Instance__(m_frmCamera);
                    return m_frmCamera;
                }
                [DebuggerHidden]
                set
                {
                    if (ReferenceEquals(value, m_frmCamera))
                        return;
                    if (value is not null)
                        throw new ArgumentException("Property can only be set to Nothing");
                    Dispose__Instance__(ref m_frmCamera);
                }
            }


            [EditorBrowsable(EditorBrowsableState.Never)]
            public frmIndividualprofile m_frmIndividualprofile;

            public frmIndividualprofile frmIndividualprofile
            {
                [DebuggerHidden]
                get
                {
                    m_frmIndividualprofile = Create__Instance__(m_frmIndividualprofile);
                    return m_frmIndividualprofile;
                }
                [DebuggerHidden]
                set
                {
                    if (ReferenceEquals(value, m_frmIndividualprofile))
                        return;
                    if (value is not null)
                        throw new ArgumentException("Property can only be set to Nothing");
                    Dispose__Instance__(ref m_frmIndividualprofile);
                }
            }


            [EditorBrowsable(EditorBrowsableState.Never)]
            public frmlogin m_frmlogin;

            public frmlogin frmlogin
            {
                [DebuggerHidden]
                get
                {
                    m_frmlogin = Create__Instance__(m_frmlogin);
                    return m_frmlogin;
                }
                [DebuggerHidden]
                set
                {
                    if (ReferenceEquals(value, m_frmlogin))
                        return;
                    if (value is not null)
                        throw new ArgumentException("Property can only be set to Nothing");
                    Dispose__Instance__(ref m_frmlogin);
                }
            }


            [EditorBrowsable(EditorBrowsableState.Never)]
            public frmUserAccountsProfile m_frmUserAccountsProfile;

            public frmUserAccountsProfile frmUserAccountsProfile
            {
                [DebuggerHidden]
                get
                {
                    m_frmUserAccountsProfile = Create__Instance__(m_frmUserAccountsProfile);
                    return m_frmUserAccountsProfile;
                }
                [DebuggerHidden]
                set
                {
                    if (ReferenceEquals(value, m_frmUserAccountsProfile))
                        return;
                    if (value is not null)
                        throw new ArgumentException("Property can only be set to Nothing");
                    Dispose__Instance__(ref m_frmUserAccountsProfile);
                }
            }


            [EditorBrowsable(EditorBrowsableState.Never)]
            public newemployee m_newemployee;

            public newemployee newemployee
            {
                [DebuggerHidden]
                get
                {
                    m_newemployee = Create__Instance__(m_newemployee);
                    return m_newemployee;
                }
                [DebuggerHidden]
                set
                {
                    if (ReferenceEquals(value, m_newemployee))
                        return;
                    if (value is not null)
                        throw new ArgumentException("Property can only be set to Nothing");
                    Dispose__Instance__(ref m_newemployee);
                }
            }


            [EditorBrowsable(EditorBrowsableState.Never)]
            public payroll m_payroll;

            public payroll payroll
            {
                [DebuggerHidden]
                get
                {
                    m_payroll = Create__Instance__(m_payroll);
                    return m_payroll;
                }
                [DebuggerHidden]
                set
                {
                    if (ReferenceEquals(value, m_payroll))
                        return;
                    if (value is not null)
                        throw new ArgumentException("Property can only be set to Nothing");
                    Dispose__Instance__(ref m_payroll);
                }
            }


            [EditorBrowsable(EditorBrowsableState.Never)]
            public popup m_popup;

            public popup popup
            {
                [DebuggerHidden]
                get
                {
                    m_popup = Create__Instance__(m_popup);
                    return m_popup;
                }
                [DebuggerHidden]
                set
                {
                    if (ReferenceEquals(value, m_popup))
                        return;
                    if (value is not null)
                        throw new ArgumentException("Property can only be set to Nothing");
                    Dispose__Instance__(ref m_popup);
                }
            }


            [EditorBrowsable(EditorBrowsableState.Never)]
            public reportType m_reportType;

            public reportType reportType
            {
                [DebuggerHidden]
                get
                {
                    m_reportType = Create__Instance__(m_reportType);
                    return m_reportType;
                }
                [DebuggerHidden]
                set
                {
                    if (ReferenceEquals(value, m_reportType))
                        return;
                    if (value is not null)
                        throw new ArgumentException("Property can only be set to Nothing");
                    Dispose__Instance__(ref m_reportType);
                }
            }


            [EditorBrowsable(EditorBrowsableState.Never)]
            public Utilities m_Utilities;

            public Utilities Utilities
            {
                [DebuggerHidden]
                get
                {
                    m_Utilities = Create__Instance__(m_Utilities);
                    return m_Utilities;
                }
                [DebuggerHidden]
                set
                {
                    if (ReferenceEquals(value, m_Utilities))
                        return;
                    if (value is not null)
                        throw new ArgumentException("Property can only be set to Nothing");
                    Dispose__Instance__(ref m_Utilities);
                }
            }

        }


    }
}
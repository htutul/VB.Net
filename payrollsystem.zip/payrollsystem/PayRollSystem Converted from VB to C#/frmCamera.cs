﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

namespace Ichiban
{
    public partial class frmCamera
    {
        public frmCamera()
        {
            InitializeComponent();
        }


        private void OpenPreviewWindow()
        {
            int iHeight = PictureBox1.Height;
            int iWidth = PictureBox1.Width;
            string arglpszWindowName = ModCamera.iDevice.ToString();
            ModCamera.hHwnd = ModCamera.capCreateCaptureWindowA(ref arglpszWindowName, ModCamera.WS_VISIBLE | ModCamera.WS_CHILD, 0, 0, 640, (short)480, PictureBox1.Handle.ToInt32(), 0);
            ModCamera.iDevice = Conversions.ToInteger(arglpszWindowName);
            if (Conversions.ToBoolean(ModCamera.SendMessage(ModCamera.hHwnd, ModCamera.WM_Cap_Paki_CONNECT, ModCamera.iDevice, 0)))
            {
                ModCamera.SendMessage(ModCamera.hHwnd, ModCamera.WM_Cap_SET_SCALE, Conversions.ToInteger(true), 0);
                ModCamera.SendMessage(ModCamera.hHwnd, ModCamera.WM_Cap_SET_PREVIEWRATE, 66, 0);
                ModCamera.SendMessage(ModCamera.hHwnd, ModCamera.WM_Cap_SET_PREVIEW, Conversions.ToInteger(true), 0);
                ModCamera.SetWindowPos(ModCamera.hHwnd, ModCamera.HWND_BOTTOM, 0, 0, PictureBox1.Width, PictureBox1.Height, ModCamera.SWP_NOMOVE | ModCamera.SWP_NOZORDER);
            }
            else
            {
                ModCamera.DestroyWindow(ModCamera.hHwnd);
            }
        }

        private void ClosePreviewWindow()
        {
            ModCamera.SendMessage(ModCamera.hHwnd, ModCamera.WM_Cap_Paki_DISCONNECT, ModCamera.iDevice, 0);
            ModCamera.DestroyWindow(ModCamera.hHwnd);
        }






        private void Button2_Click_1(object sender, EventArgs e)
        {
            OpenPreviewWindow();
        }

        private void Button4_Click_1(object sender, EventArgs e)
        {
            if (Button4.Text == "Capture")
            {

                Button4.Text = "Save";

                IDataObject Data;
                Image Bmap;
                ModCamera.SendMessage(ModCamera.hHwnd, ModCamera.WM_Cap_EDIT_COPY, 0, 0);
                Data = Clipboard.GetDataObject();

                if (Data.GetDataPresent(typeof(Bitmap)))
                {
                    Bmap = (Image)Data.GetData(typeof(Bitmap));
                    PictureBox1.Image = Bmap;
                    ClosePreviewWindow();

                }
            }

            else if (Button4.Text == "Save")
            {

                var savefiledialog1 = new SaveFileDialog();

                savefiledialog1.Title = "save File";
                savefiledialog1.FileName = "*.bmp";
                savefiledialog1.Filter = "Bitmap |*.bmp* ";

                if (savefiledialog1.ShowDialog() == DialogResult.OK)
                {
                    PictureBox1.Image.Save(savefiledialog1.FileName, System.Drawing.Imaging.ImageFormat.Bmp);

                }

                Close();

            }
        }
    }
}
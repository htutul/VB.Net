﻿using System;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace Ichiban
{
    public partial class assign
    {
        public assign()
        {
            InitializeComponent();
        }

        private void assign_Load(object sender, EventArgs e)
        {
            load_data();
            lblrate.Text = Strings.FormatNumber(lblrate.Text, 2);
            // txtbasicPay.Text = FormatNumber(txtbasicPay.Text, 2)
        }
        public void load_data()
        {
            usableselect.jokenselect("Select ID, EMPID, LNAME & ', ' & FNAME & ' ' & MI as [Guard Name], AGE, BDAY, BPLACE, HEIGHT, WEIGHT,CONTACT, WORKSTATUS from tblemployee where GPOSITION = 'Guard' and WORKSTATUS = 'Active' and ASSIGN = NO");
            usableselect.filltable(DataGridView3, "EmpInfo");
        }

        private void DataGridView3_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                ID.Text = Conversions.ToString(DataGridView3.CurrentRow.Cells[0].Value);
                LBLEMPID.Text = DataGridView3.CurrentRow.Cells[1].Value.ToString();
                LBLFULLNAME.Text = DataGridView3.CurrentRow.Cells[2].Value.ToString();
                LBLAGE.Text = Conversions.ToString(DataGridView3.CurrentRow.Cells[3].Value);
                LBLEMPSTATUS.Text = DataGridView3.CurrentRow.Cells[7].Value.ToString();
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message);
            }


        }



        private void BTNASSIGN_Click(object sender, EventArgs e)
        {
            crud.jokeninsert("INSERT INTO tblassign(EMPID,CLIENTID,EMP_FULLNAME,CLIENT_RATE,ASSIGN_DATE, STARTDATE,ENDDATE) VALUES('" + LBLEMPID.Text + "','" + LBLCLIENTID.Text + "','" + LBLFULLNAME.Text + "','" + lblrate.Text + "', #" + Conversions.ToString(DateTime.Today) + "#, #" + lblstart.Text + "#,#" + lblend.Text + "#)");
            crud.jokenupdate("UPDATE tblemployee set ASSIGN=1 WHERE ID = " + ID.Text + " ");
            Interaction.MsgBox("Guard has been assigned!");
            load_data();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            Interaction.MsgBox(DateTime.Today);
        }
    }
}
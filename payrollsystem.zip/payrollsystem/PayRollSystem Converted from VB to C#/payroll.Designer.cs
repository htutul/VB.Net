﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace Ichiban
{
    [Microsoft.VisualBasic.CompilerServices.DesignerGenerated()]
    public partial class payroll : Form
    {

        // Form overrides dispose to clean up the component list.
        [DebuggerNonUserCode()]
        protected override void Dispose(bool disposing)
        {
            try
            {
                if (disposing && components is not null)
                {
                    components.Dispose();
                }
            }
            finally
            {
                base.Dispose(disposing);
            }
        }

        // Required by the Windows Form Designer
        private System.ComponentModel.IContainer components;

        // NOTE: The following procedure is required by the Windows Form Designer
        // It can be modified using the Windows Form Designer.  
        // Do not modify it using the code editor.
        [DebuggerStepThrough()]
        private void InitializeComponent()
        {
            Panel1 = new Panel();
            Label4 = new Label();
            Label15 = new Label();
            Label14 = new Label();
            dtpPeriodEnd = new DateTimePicker();
            dtpPeriodStart = new DateTimePicker();
            dtpPeriodStart.TextChanged += new EventHandler(dtpPeriodStart_TextChanged);
            Button1 = new Button();
            Button1.Click += new EventHandler(Button1_Click);
            Label44 = new Label();
            payEmpName = new TextBox();
            Label45 = new Label();
            GroupBox1 = new GroupBox();
            txtPHIL_ER = new TextBox();
            txtPGIBIG_ER = new TextBox();
            Label12 = new Label();
            txtSSS_ER = new TextBox();
            txtPagibigLoans = new TextBox();
            txtPagibigLoans.TextChanged += new EventHandler(txtPagibigLoans_TextChanged);
            txttotalDeductions = new TextBox();
            Label27 = new Label();
            txtOtherLoans = new TextBox();
            txtOtherLoans.TextChanged += new EventHandler(txtOtherLoans_TextChanged);
            Label16 = new Label();
            Label30 = new Label();
            txtSSSLoans = new TextBox();
            txtSSSLoans.TextChanged += new EventHandler(txtSSSLoans_TextChanged);
            Label29 = new Label();
            txtWtax = new TextBox();
            txtWtax.TextChanged += new EventHandler(txtWtax_TextChanged);
            Label33 = new Label();
            txtPhilhealth = new TextBox();
            txtPhilhealth.TextChanged += new EventHandler(txtPhilhealth_TextChanged);
            Label31 = new Label();
            txtPagibig = new TextBox();
            txtPagibig.TextChanged += new EventHandler(txtPagibig_TextChanged);
            txtSSS = new TextBox();
            txtSSS.TextChanged += new EventHandler(txtSSS_TextChanged);
            Label32 = new Label();
            Label34 = new Label();
            btncancel = new Button();
            btncancel.Click += new EventHandler(btncancel_Click);
            btnsave = new Button();
            btnsave.Click += new EventHandler(btnsave_Click);
            Label28 = new Label();
            txtNetIncome = new TextBox();
            txtClientRate = new TextBox();
            txtClientRate.TextChanged += new EventHandler(txtClientRate_TextChanged);
            Label1 = new Label();
            txtAgencyFee = new TextBox();
            Label2 = new Label();
            txtByMonthlyRate = new TextBox();
            Label3 = new Label();
            txtHourlyRate = new TextBox();
            Label5 = new Label();
            GrossSalary = new TextBox();
            GrossSalary.TextChanged += new EventHandler(GrossSalary_TextChanged);
            Label6 = new Label();
            Button2 = new Button();
            Button2.Click += new EventHandler(Button2_Click);
            txtGrossPay = new TextBox();
            txtGrossPay.TextChanged += new EventHandler(txtGrossPay_TextChanged);
            Label7 = new Label();
            txtbasicPay = new TextBox();
            Label8 = new Label();
            txtNoHoursWork = new TextBox();
            txtNoHoursWork.TextChanged += new EventHandler(txtNoHoursWork_TextChanged);
            Label9 = new Label();
            txtAllowances = new TextBox();
            txtAllowances.TextChanged += new EventHandler(txtAllowances_TextChanged);
            Label10 = new Label();
            txtAdjustments = new TextBox();
            txtAdjustments.TextChanged += new EventHandler(txtAdjustments_TextChanged);
            Label11 = new Label();
            GroupBox2 = new GroupBox();
            TextBox1 = new TextBox();
            Button3 = new Button();
            Button3.Click += new EventHandler(Button3_Click);
            TextBox2 = new TextBox();
            Label13 = new Label();
            Label23 = new Label();
            payEmpID = new TextBox();
            TXTCLIENTID = new TextBox();
            TXTCLIENTNAME = new TextBox();
            Button4 = new Button();
            Button4.Click += new EventHandler(Button4_Click);
            Label17 = new Label();
            Button5 = new Button();
            Button5.Click += new EventHandler(Button5_Click);
            lblpayrolid = new Label();
            Label18 = new Label();
            Panel1.SuspendLayout();
            GroupBox1.SuspendLayout();
            GroupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // Panel1
            // 
            Panel1.BackColor = SystemColors.ActiveCaption;
            Panel1.Controls.Add(Label4);
            Panel1.Dock = DockStyle.Top;
            Panel1.Location = new Point(0, 0);
            Panel1.Name = "Panel1";
            Panel1.Size = new Size(724, 51);
            Panel1.TabIndex = 3;
            // 
            // Label4
            // 
            Label4.Font = new Font("Microsoft Sans Serif", 18.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label4.ForeColor = SystemColors.HighlightText;
            Label4.Location = new Point(3, 9);
            Label4.Name = "Label4";
            Label4.Size = new Size(203, 33);
            Label4.TabIndex = 1;
            Label4.Text = "Payroll";
            // 
            // Label15
            // 
            Label15.AutoSize = true;
            Label15.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label15.Location = new Point(162, 71);
            Label15.Name = "Label15";
            Label15.Size = new Size(65, 13);
            Label15.TabIndex = 89;
            Label15.Text = "Period End :";
            // 
            // Label14
            // 
            Label14.AutoSize = true;
            Label14.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label14.Location = new Point(30, 72);
            Label14.Name = "Label14";
            Label14.Size = new Size(68, 13);
            Label14.TabIndex = 88;
            Label14.Text = "Period Start :";
            // 
            // dtpPeriodEnd
            // 
            dtpPeriodEnd.Enabled = false;
            dtpPeriodEnd.Format = DateTimePickerFormat.Short;
            dtpPeriodEnd.Location = new Point(159, 87);
            dtpPeriodEnd.Name = "dtpPeriodEnd";
            dtpPeriodEnd.Size = new Size(126, 20);
            dtpPeriodEnd.TabIndex = 10;
            // 
            // dtpPeriodStart
            // 
            dtpPeriodStart.Format = DateTimePickerFormat.Short;
            dtpPeriodStart.Location = new Point(27, 87);
            dtpPeriodStart.Name = "dtpPeriodStart";
            dtpPeriodStart.Size = new Size(126, 20);
            dtpPeriodStart.TabIndex = 9;
            // 
            // Button1
            // 
            Button1.Font = new Font("Microsoft Sans Serif", 9.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Button1.Location = new Point(291, 75);
            Button1.Name = "Button1";
            Button1.Size = new Size(68, 32);
            Button1.TabIndex = 22;
            Button1.Text = "Open List";
            Button1.UseVisualStyleBackColor = true;
            // 
            // Label44
            // 
            Label44.AutoSize = true;
            Label44.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label44.Location = new Point(30, 125);
            Label44.Name = "Label44";
            Label44.Size = new Size(73, 13);
            Label44.TabIndex = 24;
            Label44.Text = "Employee ID :";
            // 
            // payEmpName
            // 
            payEmpName.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            payEmpName.Location = new Point(159, 141);
            payEmpName.Name = "payEmpName";
            payEmpName.ReadOnly = true;
            payEmpName.Size = new Size(200, 22);
            payEmpName.TabIndex = 25;
            // 
            // Label45
            // 
            Label45.AutoSize = true;
            Label45.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label45.Location = new Point(163, 126);
            Label45.Name = "Label45";
            Label45.Size = new Size(55, 13);
            Label45.TabIndex = 26;
            Label45.Text = "Fullname :";
            // 
            // GroupBox1
            // 
            GroupBox1.Controls.Add(txtPHIL_ER);
            GroupBox1.Controls.Add(txtPGIBIG_ER);
            GroupBox1.Controls.Add(Label12);
            GroupBox1.Controls.Add(txtSSS_ER);
            GroupBox1.Location = new Point(249, 508);
            GroupBox1.Name = "GroupBox1";
            GroupBox1.Size = new Size(132, 62);
            GroupBox1.TabIndex = 56;
            GroupBox1.TabStop = false;
            GroupBox1.Text = "Deduction";
            // 
            // txtPHIL_ER
            // 
            txtPHIL_ER.Location = new Point(18, 87);
            txtPHIL_ER.Name = "txtPHIL_ER";
            txtPHIL_ER.ReadOnly = true;
            txtPHIL_ER.Size = new Size(78, 20);
            txtPHIL_ER.TabIndex = 86;
            txtPHIL_ER.Text = "0.00";
            // 
            // txtPGIBIG_ER
            // 
            txtPGIBIG_ER.Location = new Point(18, 64);
            txtPGIBIG_ER.Name = "txtPGIBIG_ER";
            txtPGIBIG_ER.ReadOnly = true;
            txtPGIBIG_ER.Size = new Size(78, 20);
            txtPGIBIG_ER.TabIndex = 85;
            txtPGIBIG_ER.Text = "100";
            // 
            // Label12
            // 
            Label12.AutoSize = true;
            Label12.Location = new Point(59, 17);
            Label12.Name = "Label12";
            Label12.Size = new Size(22, 13);
            Label12.TabIndex = 84;
            Label12.Text = "ER";
            // 
            // txtSSS_ER
            // 
            txtSSS_ER.Location = new Point(18, 32);
            txtSSS_ER.Name = "txtSSS_ER";
            txtSSS_ER.ReadOnly = true;
            txtSSS_ER.Size = new Size(78, 20);
            txtSSS_ER.TabIndex = 83;
            txtSSS_ER.Text = "0.00";
            // 
            // txtPagibigLoans
            // 
            txtPagibigLoans.Location = new Point(342, 327);
            txtPagibigLoans.Name = "txtPagibigLoans";
            txtPagibigLoans.Size = new Size(80, 20);
            txtPagibigLoans.TabIndex = 89;
            txtPagibigLoans.Text = "0.00";
            txtPagibigLoans.TextAlign = HorizontalAlignment.Center;
            // 
            // txttotalDeductions
            // 
            txttotalDeductions.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            txttotalDeductions.Location = new Point(335, 414);
            txttotalDeductions.Name = "txttotalDeductions";
            txttotalDeductions.ReadOnly = true;
            txttotalDeductions.Size = new Size(87, 22);
            txttotalDeductions.TabIndex = 81;
            txttotalDeductions.Text = "0.00";
            txttotalDeductions.TextAlign = HorizontalAlignment.Center;
            // 
            // Label27
            // 
            Label27.AutoSize = true;
            Label27.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label27.Location = new Point(33, 420);
            Label27.Name = "Label27";
            Label27.Size = new Size(141, 16);
            Label27.TabIndex = 80;
            Label27.Text = "TOTAL DEDUCTION :";
            // 
            // txtOtherLoans
            // 
            txtOtherLoans.Location = new Point(342, 356);
            txtOtherLoans.Name = "txtOtherLoans";
            txtOtherLoans.Size = new Size(80, 20);
            txtOtherLoans.TabIndex = 24;
            txtOtherLoans.Text = "0.00";
            txtOtherLoans.TextAlign = HorizontalAlignment.Center;
            // 
            // Label16
            // 
            Label16.AutoSize = true;
            Label16.Location = new Point(256, 331);
            Label16.Name = "Label16";
            Label16.Size = new Size(83, 13);
            Label16.TabIndex = 90;
            Label16.Text = "Pag-ibig Loans :";
            // 
            // Label30
            // 
            Label30.AutoSize = true;
            Label30.Location = new Point(258, 307);
            Label30.Name = "Label30";
            Label30.Size = new Size(66, 13);
            Label30.TabIndex = 25;
            Label30.Text = "SSS Loans :";
            // 
            // txtSSSLoans
            // 
            txtSSSLoans.Location = new Point(342, 301);
            txtSSSLoans.Name = "txtSSSLoans";
            txtSSSLoans.Size = new Size(80, 20);
            txtSSSLoans.TabIndex = 23;
            txtSSSLoans.Text = "0.00";
            txtSSSLoans.TextAlign = HorizontalAlignment.Center;
            // 
            // Label29
            // 
            Label29.AutoSize = true;
            Label29.Location = new Point(256, 356);
            Label29.Name = "Label29";
            Label29.Size = new Size(71, 13);
            Label29.TabIndex = 26;
            Label29.Text = "Other Loans :";
            // 
            // txtWtax
            // 
            txtWtax.BackColor = SystemColors.Control;
            txtWtax.Location = new Point(157, 379);
            txtWtax.Name = "txtWtax";
            txtWtax.Size = new Size(80, 20);
            txtWtax.TabIndex = 22;
            txtWtax.Text = "0.00";
            txtWtax.TextAlign = HorizontalAlignment.Center;
            // 
            // Label33
            // 
            Label33.AutoSize = true;
            Label33.Location = new Point(33, 382);
            Label33.Name = "Label33";
            Label33.Size = new Size(47, 13);
            Label33.TabIndex = 21;
            Label33.Text = "W/Tax :";
            // 
            // txtPhilhealth
            // 
            txtPhilhealth.Location = new Point(159, 353);
            txtPhilhealth.Name = "txtPhilhealth";
            txtPhilhealth.ReadOnly = true;
            txtPhilhealth.Size = new Size(78, 20);
            txtPhilhealth.TabIndex = 19;
            txtPhilhealth.Text = "0.00";
            txtPhilhealth.TextAlign = HorizontalAlignment.Center;
            // 
            // Label31
            // 
            Label31.AutoSize = true;
            Label31.Location = new Point(33, 355);
            Label31.Name = "Label31";
            Label31.Size = new Size(59, 13);
            Label31.TabIndex = 20;
            Label31.Text = "Philhealth :";
            // 
            // txtPagibig
            // 
            txtPagibig.Location = new Point(159, 327);
            txtPagibig.Name = "txtPagibig";
            txtPagibig.ReadOnly = true;
            txtPagibig.Size = new Size(78, 20);
            txtPagibig.TabIndex = 17;
            txtPagibig.Text = "100";
            txtPagibig.TextAlign = HorizontalAlignment.Center;
            // 
            // txtSSS
            // 
            txtSSS.Location = new Point(159, 301);
            txtSSS.Name = "txtSSS";
            txtSSS.ReadOnly = true;
            txtSSS.Size = new Size(78, 20);
            txtSSS.TabIndex = 15;
            txtSSS.Text = "0.00";
            txtSSS.TextAlign = HorizontalAlignment.Center;
            // 
            // Label32
            // 
            Label32.AutoSize = true;
            Label32.Location = new Point(33, 307);
            Label32.Name = "Label32";
            Label32.Size = new Size(34, 13);
            Label32.TabIndex = 18;
            Label32.Text = "SSS :";
            // 
            // Label34
            // 
            Label34.AutoSize = true;
            Label34.Location = new Point(33, 326);
            Label34.Name = "Label34";
            Label34.Size = new Size(54, 13);
            Label34.TabIndex = 16;
            Label34.Text = "Pag- ibig :";
            // 
            // btncancel
            // 
            btncancel.Location = new Point(609, 438);
            btncancel.Name = "btncancel";
            btncancel.Size = new Size(88, 34);
            btncancel.TabIndex = 88;
            btncancel.Text = "Cancel";
            btncancel.UseVisualStyleBackColor = true;
            // 
            // btnsave
            // 
            btnsave.Location = new Point(519, 438);
            btnsave.Name = "btnsave";
            btnsave.Size = new Size(88, 34);
            btnsave.TabIndex = 87;
            btnsave.Text = "Save";
            btnsave.UseVisualStyleBackColor = true;
            // 
            // Label28
            // 
            Label28.AutoSize = true;
            Label28.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label28.Location = new Point(264, 239);
            Label28.Name = "Label28";
            Label28.Size = new Size(69, 13);
            Label28.TabIndex = 79;
            Label28.Text = "Total Salary :";
            // 
            // txtNetIncome
            // 
            txtNetIncome.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtNetIncome.Location = new Point(335, 452);
            txtNetIncome.Name = "txtNetIncome";
            txtNetIncome.ReadOnly = true;
            txtNetIncome.Size = new Size(87, 22);
            txtNetIncome.TabIndex = 82;
            txtNetIncome.Text = "0.00";
            txtNetIncome.TextAlign = HorizontalAlignment.Center;
            // 
            // txtClientRate
            // 
            txtClientRate.Location = new Point(129, 25);
            txtClientRate.Name = "txtClientRate";
            txtClientRate.ReadOnly = true;
            txtClientRate.Size = new Size(80, 20);
            txtClientRate.TabIndex = 57;
            txtClientRate.Text = "0.00";
            txtClientRate.TextAlign = HorizontalAlignment.Center;
            // 
            // Label1
            // 
            Label1.AutoSize = true;
            Label1.Location = new Point(53, 30);
            Label1.Name = "Label1";
            Label1.Size = new Size(65, 13);
            Label1.TabIndex = 58;
            Label1.Text = "Client Rate :";
            // 
            // txtAgencyFee
            // 
            txtAgencyFee.Location = new Point(129, 51);
            txtAgencyFee.Name = "txtAgencyFee";
            txtAgencyFee.ReadOnly = true;
            txtAgencyFee.Size = new Size(80, 20);
            txtAgencyFee.TabIndex = 59;
            txtAgencyFee.Text = "0.00";
            txtAgencyFee.TextAlign = HorizontalAlignment.Center;
            // 
            // Label2
            // 
            Label2.AutoSize = true;
            Label2.Location = new Point(53, 54);
            Label2.Name = "Label2";
            Label2.Size = new Size(70, 13);
            Label2.TabIndex = 60;
            Label2.Text = "Agency Fee :";
            // 
            // txtByMonthlyRate
            // 
            txtByMonthlyRate.Location = new Point(129, 77);
            txtByMonthlyRate.Name = "txtByMonthlyRate";
            txtByMonthlyRate.ReadOnly = true;
            txtByMonthlyRate.Size = new Size(80, 20);
            txtByMonthlyRate.TabIndex = 61;
            txtByMonthlyRate.Text = "0.00";
            txtByMonthlyRate.TextAlign = HorizontalAlignment.Center;
            // 
            // Label3
            // 
            Label3.AutoSize = true;
            Label3.Location = new Point(27, 80);
            Label3.Name = "Label3";
            Label3.Size = new Size(91, 13);
            Label3.TabIndex = 62;
            Label3.Text = "By Monthly Rate :";
            // 
            // txtHourlyRate
            // 
            txtHourlyRate.Location = new Point(129, 135);
            txtHourlyRate.Name = "txtHourlyRate";
            txtHourlyRate.ReadOnly = true;
            txtHourlyRate.Size = new Size(80, 20);
            txtHourlyRate.TabIndex = 63;
            txtHourlyRate.Text = "0.00";
            txtHourlyRate.TextAlign = HorizontalAlignment.Center;
            // 
            // Label5
            // 
            Label5.AutoSize = true;
            Label5.Location = new Point(53, 138);
            Label5.Name = "Label5";
            Label5.Size = new Size(69, 13);
            Label5.TabIndex = 64;
            Label5.Text = "Hourly Rate :";
            // 
            // GrossSalary
            // 
            GrossSalary.Font = new Font("Microsoft Sans Serif", 9.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            GrossSalary.Location = new Point(342, 182);
            GrossSalary.Name = "GrossSalary";
            GrossSalary.ReadOnly = true;
            GrossSalary.Size = new Size(80, 21);
            GrossSalary.TabIndex = 65;
            GrossSalary.Text = "0.00";
            GrossSalary.TextAlign = HorizontalAlignment.Center;
            // 
            // Label6
            // 
            Label6.AutoSize = true;
            Label6.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label6.Location = new Point(264, 187);
            Label6.Name = "Label6";
            Label6.Size = new Size(60, 13);
            Label6.TabIndex = 66;
            Label6.Text = "Basic Pay :";
            // 
            // Button2
            // 
            Button2.Location = new Point(168, 538);
            Button2.Name = "Button2";
            Button2.Size = new Size(75, 23);
            Button2.TabIndex = 67;
            Button2.Text = "SSS";
            Button2.UseVisualStyleBackColor = true;
            Button2.Visible = false;
            // 
            // txtGrossPay
            // 
            txtGrossPay.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtGrossPay.Location = new Point(342, 236);
            txtGrossPay.Name = "txtGrossPay";
            txtGrossPay.ReadOnly = true;
            txtGrossPay.Size = new Size(80, 20);
            txtGrossPay.TabIndex = 68;
            txtGrossPay.Text = "0.00";
            txtGrossPay.TextAlign = HorizontalAlignment.Center;
            // 
            // Label7
            // 
            Label7.AutoSize = true;
            Label7.Font = new Font("Microsoft Sans Serif", 12.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label7.Location = new Point(35, 452);
            Label7.Name = "Label7";
            Label7.Size = new Size(171, 20);
            Label7.TabIndex = 69;
            Label7.Text = "Net Pay for the Period :";
            // 
            // txtbasicPay
            // 
            txtbasicPay.Location = new Point(129, 109);
            txtbasicPay.Name = "txtbasicPay";
            txtbasicPay.ReadOnly = true;
            txtbasicPay.Size = new Size(80, 20);
            txtbasicPay.TabIndex = 70;
            txtbasicPay.Text = "0.00";
            txtbasicPay.TextAlign = HorizontalAlignment.Center;
            // 
            // Label8
            // 
            Label8.AutoSize = true;
            Label8.Location = new Point(53, 114);
            Label8.Name = "Label8";
            Label8.Size = new Size(60, 13);
            Label8.TabIndex = 71;
            Label8.Text = "Basic Pay :";
            // 
            // txtNoHoursWork
            // 
            txtNoHoursWork.Location = new Point(159, 180);
            txtNoHoursWork.Name = "txtNoHoursWork";
            txtNoHoursWork.Size = new Size(80, 20);
            txtNoHoursWork.TabIndex = 72;
            txtNoHoursWork.Text = "0.00";
            txtNoHoursWork.TextAlign = HorizontalAlignment.Center;
            // 
            // Label9
            // 
            Label9.AutoSize = true;
            Label9.Location = new Point(30, 187);
            Label9.Name = "Label9";
            Label9.Size = new Size(102, 13);
            Label9.TabIndex = 73;
            Label9.Text = "No. Hours Worked :";
            // 
            // txtAllowances
            // 
            txtAllowances.Location = new Point(159, 206);
            txtAllowances.Name = "txtAllowances";
            txtAllowances.Size = new Size(80, 20);
            txtAllowances.TabIndex = 74;
            txtAllowances.Text = "0.00";
            txtAllowances.TextAlign = HorizontalAlignment.Center;
            // 
            // Label10
            // 
            Label10.AutoSize = true;
            Label10.Location = new Point(33, 213);
            Label10.Name = "Label10";
            Label10.Size = new Size(67, 13);
            Label10.TabIndex = 75;
            Label10.Text = "Allowances :";
            // 
            // txtAdjustments
            // 
            txtAdjustments.Location = new Point(159, 232);
            txtAdjustments.Name = "txtAdjustments";
            txtAdjustments.Size = new Size(80, 20);
            txtAdjustments.TabIndex = 76;
            txtAdjustments.Text = "0.00";
            txtAdjustments.TextAlign = HorizontalAlignment.Center;
            // 
            // Label11
            // 
            Label11.AutoSize = true;
            Label11.Location = new Point(29, 239);
            Label11.Name = "Label11";
            Label11.Size = new Size(73, 13);
            Label11.TabIndex = 77;
            Label11.Text = " Adjustments :";
            // 
            // GroupBox2
            // 
            GroupBox2.Controls.Add(Label1);
            GroupBox2.Controls.Add(txtClientRate);
            GroupBox2.Controls.Add(Label2);
            GroupBox2.Controls.Add(txtAgencyFee);
            GroupBox2.Controls.Add(Label3);
            GroupBox2.Controls.Add(txtByMonthlyRate);
            GroupBox2.Controls.Add(txtbasicPay);
            GroupBox2.Controls.Add(Label5);
            GroupBox2.Controls.Add(Label8);
            GroupBox2.Controls.Add(txtHourlyRate);
            GroupBox2.Location = new Point(451, 182);
            GroupBox2.Name = "GroupBox2";
            GroupBox2.Size = new Size(246, 174);
            GroupBox2.TabIndex = 78;
            GroupBox2.TabStop = false;
            GroupBox2.Text = "Income";
            // 
            // TextBox1
            // 
            TextBox1.Location = new Point(16, 512);
            TextBox1.Name = "TextBox1";
            TextBox1.Size = new Size(100, 20);
            TextBox1.TabIndex = 79;
            TextBox1.Visible = false;
            // 
            // Button3
            // 
            Button3.Location = new Point(9, 538);
            Button3.Name = "Button3";
            Button3.Size = new Size(75, 23);
            Button3.TabIndex = 80;
            Button3.Text = "PHIC";
            Button3.UseVisualStyleBackColor = true;
            Button3.Visible = false;
            // 
            // TextBox2
            // 
            TextBox2.Location = new Point(127, 512);
            TextBox2.Name = "TextBox2";
            TextBox2.Size = new Size(100, 20);
            TextBox2.TabIndex = 81;
            TextBox2.Visible = false;
            // 
            // Label13
            // 
            Label13.AutoSize = true;
            Label13.Font = new Font("Microsoft Sans Serif", 9.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label13.Location = new Point(470, 543);
            Label13.Name = "Label13";
            Label13.Size = new Size(59, 15);
            Label13.TabIndex = 84;
            Label13.Text = "Client ID :";
            Label13.Visible = false;
            // 
            // Label23
            // 
            Label23.AutoSize = true;
            Label23.Font = new Font("Microsoft Sans Serif", 9.0f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label23.Location = new Point(249, 520);
            Label23.Name = "Label23";
            Label23.Size = new Size(81, 15);
            Label23.TabIndex = 82;
            Label23.Text = "Client Name :";
            Label23.Visible = false;
            // 
            // payEmpID
            // 
            payEmpID.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            payEmpID.Location = new Point(27, 140);
            payEmpID.Name = "payEmpID";
            payEmpID.ReadOnly = true;
            payEmpID.Size = new Size(126, 22);
            payEmpID.TabIndex = 23;
            // 
            // TXTCLIENTID
            // 
            TXTCLIENTID.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            TXTCLIENTID.Location = new Point(535, 540);
            TXTCLIENTID.Name = "TXTCLIENTID";
            TXTCLIENTID.ReadOnly = true;
            TXTCLIENTID.Size = new Size(125, 22);
            TXTCLIENTID.TabIndex = 85;
            TXTCLIENTID.Visible = false;
            // 
            // TXTCLIENTNAME
            // 
            TXTCLIENTNAME.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            TXTCLIENTNAME.Location = new Point(252, 538);
            TXTCLIENTNAME.Name = "TXTCLIENTNAME";
            TXTCLIENTNAME.ReadOnly = true;
            TXTCLIENTNAME.Size = new Size(210, 22);
            TXTCLIENTNAME.TabIndex = 86;
            TXTCLIENTNAME.Visible = false;
            // 
            // Button4
            // 
            Button4.Location = new Point(87, 538);
            Button4.Name = "Button4";
            Button4.Size = new Size(75, 23);
            Button4.TabIndex = 87;
            Button4.Text = "HDMF";
            Button4.UseVisualStyleBackColor = true;
            Button4.Visible = false;
            // 
            // Label17
            // 
            Label17.AutoSize = true;
            Label17.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            Label17.Location = new Point(13, 282);
            Label17.Name = "Label17";
            Label17.Size = new Size(140, 16);
            Label17.TabIndex = 91;
            Label17.Text = "LESS DEDUCTIONS :";
            // 
            // Button5
            // 
            Button5.Location = new Point(473, 511);
            Button5.Name = "Button5";
            Button5.Size = new Size(75, 23);
            Button5.TabIndex = 92;
            Button5.Text = "Tax";
            Button5.UseVisualStyleBackColor = true;
            // 
            // lblpayrolid
            // 
            lblpayrolid.AutoSize = true;
            lblpayrolid.Location = new Point(577, 72);
            lblpayrolid.Name = "lblpayrolid";
            lblpayrolid.Size = new Size(43, 13);
            lblpayrolid.TabIndex = 94;
            lblpayrolid.Text = "payrolid";
            // 
            // Label18
            // 
            Label18.AutoSize = true;
            Label18.Location = new Point(516, 72);
            Label18.Name = "Label18";
            Label18.Size = new Size(55, 13);
            Label18.TabIndex = 95;
            Label18.Text = "Payroll ID:";
            // 
            // payroll
            // 
            AutoScaleDimensions = new SizeF(6.0f, 13.0f);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonHighlight;
            ClientSize = new Size(724, 493);
            Controls.Add(Label18);
            Controls.Add(lblpayrolid);
            Controls.Add(Button5);
            Controls.Add(Label17);
            Controls.Add(txtGrossPay);
            Controls.Add(txtPagibigLoans);
            Controls.Add(txttotalDeductions);
            Controls.Add(Label15);
            Controls.Add(Label27);
            Controls.Add(txtWtax);
            Controls.Add(txtOtherLoans);
            Controls.Add(Label14);
            Controls.Add(Label29);
            Controls.Add(Label33);
            Controls.Add(txtPhilhealth);
            Controls.Add(Label16);
            Controls.Add(dtpPeriodEnd);
            Controls.Add(txtSSSLoans);
            Controls.Add(Label30);
            Controls.Add(Label31);
            Controls.Add(btncancel);
            Controls.Add(txtPagibig);
            Controls.Add(dtpPeriodStart);
            Controls.Add(txtSSS);
            Controls.Add(txtAdjustments);
            Controls.Add(Label34);
            Controls.Add(btnsave);
            Controls.Add(Label11);
            Controls.Add(Label32);
            Controls.Add(Button4);
            Controls.Add(txtNetIncome);
            Controls.Add(Label7);
            Controls.Add(TXTCLIENTID);
            Controls.Add(txtAllowances);
            Controls.Add(Label6);
            Controls.Add(TXTCLIENTNAME);
            Controls.Add(GrossSalary);
            Controls.Add(Label13);
            Controls.Add(Label10);
            Controls.Add(Label23);
            Controls.Add(TextBox2);
            Controls.Add(Label28);
            Controls.Add(txtNoHoursWork);
            Controls.Add(Button3);
            Controls.Add(Label9);
            Controls.Add(TextBox1);
            Controls.Add(GroupBox2);
            Controls.Add(Button2);
            Controls.Add(GroupBox1);
            Controls.Add(Button1);
            Controls.Add(payEmpID);
            Controls.Add(Label44);
            Controls.Add(payEmpName);
            Controls.Add(Label45);
            Controls.Add(Panel1);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Name = "payroll";
            StartPosition = FormStartPosition.CenterScreen;
            Panel1.ResumeLayout(false);
            GroupBox1.ResumeLayout(false);
            GroupBox1.PerformLayout();
            GroupBox2.ResumeLayout(false);
            GroupBox2.PerformLayout();
            Load += new EventHandler(payroll_Load);
            ResumeLayout(false);
            PerformLayout();

        }
        internal Panel Panel1;
        internal Label Label4;
        internal Button Button1;
        internal Label Label44;
        internal TextBox payEmpName;
        internal Label Label45;
        internal GroupBox GroupBox1;
        internal TextBox txtOtherLoans;
        internal TextBox txtSSSLoans;
        internal Label Label29;
        internal Label Label30;
        internal TextBox txtWtax;
        internal Label Label33;
        internal TextBox txtPhilhealth;
        internal Label Label31;
        internal TextBox txtPagibig;
        internal TextBox txtSSS;
        internal Label Label32;
        internal Label Label34;
        internal TextBox txtClientRate;
        internal Label Label1;
        internal TextBox txtAgencyFee;
        internal Label Label2;
        internal TextBox txtByMonthlyRate;
        internal Label Label3;
        internal TextBox txtHourlyRate;
        internal Label Label5;
        internal TextBox GrossSalary;
        internal Label Label6;
        internal Button Button2;
        internal TextBox txtGrossPay;
        internal Label Label7;
        internal TextBox txtbasicPay;
        internal Label Label8;
        internal TextBox txtNoHoursWork;
        internal Label Label9;
        internal TextBox txtAllowances;
        internal Label Label10;
        internal TextBox txtAdjustments;
        internal Label Label11;
        internal Label Label28;
        internal Label Label27;
        internal TextBox txtNetIncome;
        internal TextBox txttotalDeductions;
        internal GroupBox GroupBox2;
        internal DateTimePicker dtpPeriodStart;
        internal TextBox TextBox1;
        internal Button Button3;
        internal TextBox TextBox2;
        internal TextBox txtPHIL_ER;
        internal TextBox txtPGIBIG_ER;
        internal Label Label12;
        internal TextBox txtSSS_ER;
        internal Label Label13;
        internal Label Label23;
        internal TextBox payEmpID;
        internal TextBox TXTCLIENTID;
        internal TextBox TXTCLIENTNAME;
        internal Button Button4;
        internal Button btnsave;
        internal Button btncancel;
        internal Label Label15;
        internal Label Label14;
        internal DateTimePicker dtpPeriodEnd;
        internal TextBox txtPagibigLoans;
        internal Label Label16;
        internal Label Label17;
        internal Button Button5;
        internal Label lblpayrolid;
        internal Label Label18;
    }
}
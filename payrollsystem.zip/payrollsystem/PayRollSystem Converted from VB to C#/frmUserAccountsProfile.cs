﻿using System;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace Ichiban
{
    public partial class frmUserAccountsProfile
    {
        public frmUserAccountsProfile()
        {
            InitializeComponent();
        }

        public void displaymember()
        {
            usableselect.jokenselect("Select user_id, employee_id, UserName, userusername, userpassword, job_title From tbluseraccounts");
            usableselect.filltable(DataGridView1, "EmpInfo");

        }

        private void itemdatagrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            lblid.Text = DataGridView1.CurrentRow.Cells[0].Value.ToString();
            txtEmpID.Text = DataGridView1.CurrentRow.Cells[1].Value.ToString();
            txtname.Text = DataGridView1.CurrentRow.Cells[2].Value.ToString();
            txtuname.Text = DataGridView1.CurrentRow.Cells[3].Value.ToString();
            txtpass.Text = DataGridView1.CurrentRow.Cells[5].Value.ToString();
            cbtype.SelectedItem = DataGridView1.CurrentRow.Cells[5].Value.ToString();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Height = 300;
        }

        private void Label6_Click(object sender, EventArgs e)
        {
            if (Label6.Text == "Show List of Users")
            {
                Height = 500;
                displaymember();
                Label6.Text = "Hide list of users";
            }
            else if (Label6.Text == "Hide list of users")
            {
                Height = 300;
                Label6.Text = "Show List of Users";
            }
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            usableselect.clearall(GroupBox1, DataGridView1);
            cbtype.Text = null;

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if (txtpass.TextLength < 4)
            {

                Interaction.MsgBox("Password must be more than 8 characters");
            }

            else if ((txtpass.Text ?? "") != (txtconfirm.Text ?? ""))
            {
                Interaction.MsgBox("Password Confirmation did not match!", MsgBoxStyle.Information);
            }

            else
            {
                crud.jokeninsert(Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject("INSERT INTO tbluseraccounts ( employee_id, UserName, userusername, userpassword, job_title ) " + " VALUES('" + txtEmpID.Text + "','" + txtname.Text + "','" + txtuname.Text + "','" + txtpass.Text + "','", cbtype.SelectedItem), "')")));
                displaymember();

            }


            Button3_Click(sender, e);
        }

        private void btndel_Click(object sender, EventArgs e)
        {
            crud.jokendelete("Delete * from tbluseraccounts where user_id= " + lblid.Text + "");
            displaymember();
            Button3_Click(sender, e);
        }

        private void btnedit_Click(object sender, EventArgs e)
        {

            if ((txtpass.Text ?? "") != (txtconfirm.Text ?? ""))
            {
                Interaction.MsgBox("Password Confirmation did not match!", MsgBoxStyle.Information);
            }
            else
            {
                crud.jokenupdate(Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("UPDATE tbluseraccounts set UserName ='" + txtname.Text + "' , employee_id = '" + txtEmpID.Text + "', userusername = '" + txtuname.Text + "', userpassword = '" + txtpass.Text + "', job_title= '", cbtype.SelectedItem), "' where user_id = "), lblid.Text), "")));
                displaymember();
            }
            Button3_Click(sender, e);
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            Close();

        }


    }
}
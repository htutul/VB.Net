﻿using System;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace Ichiban
{
    public partial class popup
    {

        private string sql;

        public popup()
        {
            InitializeComponent();
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            usableselect.jokenselect("SELECT ASSIGNID,EMPID,CLIENTID,EMP_FULLNAME,CLIENT_RATE,ASSIGN_DATE,STARTDATE,ENDDATE FROM tblassign where EMP_FULLNAME LIKE '%" + txtsearch.Text + "%'");
            usableselect.filltable(DataGridView4, "EmpInfo");
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                My.MyProject.Forms.payroll.payEmpID.Text = Conversions.ToString(DataGridView4.CurrentRow.Cells[1].Value);
                My.MyProject.Forms.payroll.TXTCLIENTID.Text = Conversions.ToString(DataGridView4.CurrentRow.Cells[2].Value);
                My.MyProject.Forms.payroll.payEmpName.Text = DataGridView4.CurrentRow.Cells[3].Value.ToString();

                My.MyProject.Forms.payroll.txtClientRate.Text = DataGridView4.CurrentRow.Cells[4].Value.ToString();

                sql = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject("select taxid from tblemployee where empid ='", DataGridView4.CurrentRow.Cells[1].Value), "'"));
                jokensqlselect.jokenfindthis(sql);
                jokensqlselect.checkresult("Tax");

                Close();
            }
            catch (Exception ex)
            {
                Interaction.MsgBox("Please select employee from the table!");
            }

        }


    }
}
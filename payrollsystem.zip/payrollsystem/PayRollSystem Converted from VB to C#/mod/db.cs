﻿using System.Windows.Forms;

namespace Ichiban
{
    static class db
    {
        public static System.Data.OleDb.OleDbConnection myconn()
        {
            return new System.Data.OleDb.OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Application.StartupPath + @"\enterprisedb.mdb");
        }

    }
}
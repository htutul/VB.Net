﻿using System.Runtime.InteropServices;

namespace Ichiban
{
    static class ModCamera
    {

        public const short WM_Cap = 1024;
        public const int WM_Cap_Paki_CONNECT = WM_Cap + 10;
        public const int WM_Cap_Paki_DISCONNECT = WM_Cap + 11;
        public const int WM_Cap_EDIT_COPY = WM_Cap + 30;
        public const int WM_Cap_SET_PREVIEW = WM_Cap + 50;
        public const int WM_Cap_SET_PREVIEWRATE = WM_Cap + 52;
        public const int WM_Cap_SET_SCALE = WM_Cap + 53;
        public const int WS_CHILD = 0x40000000;
        public const int WS_VISIBLE = 0x10000000;
        public const short SWP_NOMOVE = 2;
        public const short SWP_NOSIZE = 1;
        public const short SWP_NOZORDER = 4;
        public const short HWND_BOTTOM = 1;
        public static int iDevice = 0;
        public static int hHwnd;
        [DllImport("user32", EntryPoint = "SendMessageA")]
        public static extern int SendMessage(int hwnd, int wMsg, int wParam, object lParam);
        [DllImport("user32", EntryPoint = "SetWindowPos")]
        public static extern int SetWindowPos(int hwnd, int hWndInsertAfter, int x, int y, int cx, int cy, int wFlags);
        [DllImport("user32")]
        public static extern bool DestroyWindow(int hndw);
        [DllImport("avicap32.dll")]
        public static extern int capCreateCaptureWindowA(string lpszWindowName, int dwStyle, int x, int y, int nWidth, short nHeight, int hWndParent, int nID);
        [DllImport("avicap32.dll")]
        public static extern bool capGetDriverDescriptionA(short wDriver, string lpszName, int cbName, string lpszVer, int cbVer);

    }
}
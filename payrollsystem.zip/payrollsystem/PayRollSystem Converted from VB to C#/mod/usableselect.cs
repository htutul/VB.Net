﻿using System;
using System.Collections;
using System.Data;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace Ichiban
{
    static class usableselect
    {

        private static System.Data.OleDb.OleDbCommand cmd = new System.Data.OleDb.OleDbCommand();
        private static System.Data.OleDb.OleDbDataAdapter da = new System.Data.OleDb.OleDbDataAdapter();
        public static int total;
        public static void jokenselect(string sql)
        {
            try
            {
                publicvariable.con.Open();
                {
                    ref var withBlock = ref cmd;
                    withBlock.Connection = publicvariable.con;
                    withBlock.CommandText = sql;
                }
            }

            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message, MsgBoxStyle.Exclamation);
            }
            publicvariable.con.Close();
            da.Dispose();
        }
        public static void filltable(object dtgrd, string design)
        {

            var publictable = new DataTable();




            try
            {
                da.SelectCommand = cmd;
                da.Fill(publictable);
                ((dynamic)dtgrd).DataSource = publictable;

                switch (design ?? "")
                {

                    case "EmpInfo":
                        {

                            ((dynamic)dtgrd).Columns(0).Visible = false;
                            break;
                        }

                    case "EmpPic":
                        {

                            ((dynamic)dtgrd).Columns(0).Visible = false;
                            // dtgrd.Columns(1).Visible = False

                            ((dynamic)dtgrd).Columns(2).width = 100;
                            ((dynamic)dtgrd).Columns(3).width = 100;
                            ((dynamic)dtgrd).Columns(4).width = 30;

                            ((dynamic)dtgrd).Columns(5).Visible = false;
                            ((dynamic)dtgrd).Columns(6).Visible = false;
                            ((dynamic)dtgrd).Columns(7).Visible = false;
                            ((dynamic)dtgrd).Columns(8).Visible = false;
                            ((dynamic)dtgrd).Columns(9).Visible = false;
                            ((dynamic)dtgrd).Columns(10).Visible = false;
                            ((dynamic)dtgrd).Columns(11).Visible = false;
                            ((dynamic)dtgrd).Columns(12).Visible = false;
                            ((dynamic)dtgrd).Columns(13).Visible = false;
                            ((dynamic)dtgrd).Columns(14).Visible = false;
                            ((dynamic)dtgrd).Columns(15).Visible = false;
                            ((dynamic)dtgrd).Columns(16).Visible = false;
                            // dtgrd.Columns(17).Visible = False
                            ((dynamic)dtgrd).Columns(18).Visible = false;

                            ((dynamic)dtgrd).Columns(20).Visible = false;
                            ((dynamic)dtgrd).Columns(21).Visible = false;
                            ((dynamic)dtgrd).Columns(22).Visible = false;
                            ((dynamic)dtgrd).Columns(23).Visible = false;
                            ((dynamic)dtgrd).Columns(24).Visible = false;
                            ((dynamic)dtgrd).Columns(25).Visible = false;
                            ((dynamic)dtgrd).Columns(26).Visible = false;
                            ((dynamic)dtgrd).Columns(27).Visible = false;
                            ((dynamic)dtgrd).Columns(28).Visible = false;
                            ((dynamic)dtgrd).Columns(29).Visible = false;
                            ((dynamic)dtgrd).Columns(30).Visible = false;
                            ((dynamic)dtgrd).Columns(31).Visible = false;
                            ((dynamic)dtgrd).Columns(32).Visible = false;
                            ((dynamic)dtgrd).Columns(33).Visible = false;
                            ((dynamic)dtgrd).Columns(34).Visible = false;
                            ((dynamic)dtgrd).Columns(35).Visible = false;
                            ((dynamic)dtgrd).Columns(36).Visible = false;
                            ((dynamic)dtgrd).Columns(37).Visible = false;
                            ((dynamic)dtgrd).Columns(38).Visible = false;
                            ((dynamic)dtgrd).Columns(39).Visible = false;
                            ((dynamic)dtgrd).Columns(40).Visible = false;
                            ((dynamic)dtgrd).Columns(41).Visible = false;
                            ((dynamic)dtgrd).Columns(42).Visible = false;
                            ((dynamic)dtgrd).Columns(43).Visible = false;
                            ((dynamic)dtgrd).Columns(44).Visible = false;
                            ((dynamic)dtgrd).Columns(45).Visible = false;
                            ((dynamic)dtgrd).Columns(46).Visible = false;
                            ((dynamic)dtgrd).Columns(47).Visible = false;
                            ((dynamic)dtgrd).Columns(48).Visible = false;
                            ((dynamic)dtgrd).Columns(49).Visible = false;
                            ((dynamic)dtgrd).Columns(50).Visible = false;
                            ((dynamic)dtgrd).Columns(51).Visible = false;
                            break;
                        }


                }


                da.Dispose();
            }

            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message, MsgBoxStyle.Information);
            }

        }

        public static void filltotal_employee()
        {
            var ds = new DataSet();
            var publictable = new DataTable();

            da.SelectCommand = cmd;
            da.Fill(ds, "EMPNO");
            My.MyProject.Forms.employee.lbltotalemployee.Text = Conversions.ToString(ds.Tables["EMPNO"].Rows[0][0]);
        }
        public static void filltotal_activeemployee()
        {
            var ds = new DataSet();
            var publictable = new DataTable();

            da.SelectCommand = cmd;
            da.Fill(ds, "EMPNO");
            My.MyProject.Forms.employee.lblactive.Text = Conversions.ToString(ds.Tables["EMPNO"].Rows[0][0]);
        }
        public static void filltotal_inactiveemployee()
        {
            var ds = new DataSet();
            var publictable = new DataTable();

            da.SelectCommand = cmd;
            da.Fill(ds, "EMPNO");
            My.MyProject.Forms.employee.lblinactive.Text = Conversions.ToString(ds.Tables["EMPNO"].Rows[0][0]);
        }
        public static void filltotal_onduty()
        {
            var ds = new DataSet();
            var publictable = new DataTable();

            da.SelectCommand = cmd;
            da.Fill(ds, "EMPNO");
            My.MyProject.Forms.employee.LBLONDUTY.Text = Conversions.ToString(ds.Tables["EMPNO"].Rows[0][0]);
        }
        public static void fillitemtable(object dtgrd)
        {
            var publictable = new DataTable();
            try
            {
                da.SelectCommand = cmd;
                da.Fill(publictable);
                ((dynamic)dtgrd).DataSource = publictable;
                ((dynamic)dtgrd).Columns(0).Visible = false;
                ((dynamic)dtgrd).Columns(1).width = 60;
                ((dynamic)dtgrd).Columns(2).width = 90;
                ((dynamic)dtgrd).Columns(3).width = 50;
                ((dynamic)dtgrd).Columns(4).width = 15;
                ((dynamic)dtgrd).Columns(5).visible = false;
                ((dynamic)dtgrd).Columns(6).visible = false;
                ((dynamic)dtgrd).Columns(7).visible = false;
                ((dynamic)dtgrd).Columns(8).visible = false;
                ((dynamic)dtgrd).Columns(9).visible = false;
                ((dynamic)dtgrd).Columns(10).visible = false;
                ((dynamic)dtgrd).Columns(11).visible = false;
                ((dynamic)dtgrd).Columns(12).visible = false;

                da.Dispose();
            }

            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message, MsgBoxStyle.Information);
            }

            // total = publictable.Compute("sum([Total Price])", String.Empty)
            // publictable.Rows.Add(Nothing, "", "", "Grand Total", Nothing, Nothing, total)

        }

        public static void clearall(object @group, object cleardtg)
        {
            foreach (Control ctrl in (IEnumerable)((dynamic)group).Controls)
            {
                if (ReferenceEquals(ctrl.GetType(), typeof(TextBox)))
                {
                    ctrl.Text = null;
                    ((dynamic)cleardtg).DataSource = (object)null;
                }
            }
        }

        public static void cleartext(object @group)
        {
            foreach (Control ctrl in (IEnumerable)((dynamic)group).Controls)
            {
                if (ReferenceEquals(ctrl.GetType(), typeof(TextBox)))
                {
                    ctrl.Text = null;

                }
            }
        }


    }
}
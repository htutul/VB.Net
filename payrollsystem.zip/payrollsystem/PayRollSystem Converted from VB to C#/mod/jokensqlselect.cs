﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace Ichiban
{
    static class jokensqlselect
    {
        private static System.Data.OleDb.OleDbCommand cmd = new System.Data.OleDb.OleDbCommand();
        private static System.Data.OleDb.OleDbDataAdapter da = new System.Data.OleDb.OleDbDataAdapter();

        public static void jokenfindthis(string sql)
        {
            try
            {
                publicvariable.con.Open();
                {
                    ref var withBlock = ref cmd;
                    withBlock.Connection = publicvariable.con;
                    withBlock.CommandText = sql;
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message, MsgBoxStyle.Exclamation);
            }
            publicvariable.con.Close();
            da.Dispose();

        }
        public static void Checkclient(string @var)
        {

            var table = new DataTable();

            try
            {
                da.SelectCommand = cmd;
                da.Fill(table);

                if (table.Rows.Count > 0)
                {

                    switch (@var ?? "")
                    {

                        case "employee":
                            {

                                Interaction.MsgBox("Employee ID already exist.");
                                break;
                            }

                        case "client":
                            {

                                Interaction.MsgBox("Client ID already exist.");
                                break;
                            }






                    }
                }

                else
                {

                    switch (@var ?? "")
                    {


                        case "employee":
                            {
                                break;
                            }

                        // With frmemployee

                        // ejbinsert("insert into tblemployee (EMPID, FNAME, LNAME, MI, AGE, BDAY, BPLACE, HEIGHT, WEIGHT, CIVIL_STATUS, CONTACT, RELIGION, SPOUSE, SP_ADDRESS, CITIZENSHIP, HIREDDATE, WORKSTATUS, GPOSITION) values ('" & _
                        // .txtempid.Text & "','" & .txtfname.Text & "','" & .txtlname.Text & "','" & _
                        // .txtmi.Text & "'," & Val(.txtage.Text) & ",#" & .dtpbirthdate.Text & "#,'" & _
                        // .txtbirthplace.Text & "','" & .txtheight.Text & "','" & .txtweight.Text & "','" & _
                        // .cbcivilstatus.Text & "','" & .txtcontact.Text & "','" & .txtreligion.Text & "','" & _
                        // .txtspouse.Text & "','" & .txtspouseadd.Text & "','" & .txtcitezenship.Text & "',#" & .dtphireddate.Text & "#,'" & .cbworkstatus.Text & "','" & .cbpositon.Text & "')")

                        // End With


                        case "client":
                            {

                                {
                                    var withBlock = My.MyProject.Forms.client;

                                    crud.jokeninsert("insert into tblclient (CLIENTID, CL_NAME, CL_ADDRESS, CL_RATE, START_DATE, END_DATE) values ('" + withBlock.LBLCLIENTID.Text + "','" + withBlock.txtClinetName.Text + "','" + withBlock.txtClientadd.Text + "'," + Conversion.Val(withBlock.txtrate.Text) + ", #" + withBlock.strtdate.Text + "#, #" + withBlock.endDate.Text + "#)");


                                }

                                break;
                            }


                            // Case "guard"

                            // ejbinsert("insert into tblassign (empid, clientid, ASSGSTATUS, ASSIGN_DATE) values ('" & stringEmpID & "','" & frmassign.cbclientnameselect.SelectedValue & "', 'Active', '" & Date.Today.ToString & "' )")
                            // ejbupdate("update tblemployee set ASSIGN = YES where EMPID = '" & stringEmpID & "'")

                    }

                }
            }

            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message, MsgBoxStyle.Information);
            }
        }

        public static void checkresult(string moodle)
        {

            var table = new DataTable();
            try
            {
                da.SelectCommand = cmd;
                da.Fill(table);

                if (table.Rows.Count > 0)
                {

                    switch (moodle ?? "")
                    {

                        case "Login":
                            {

                                publicvariable.Nname = Conversions.ToString(table.Rows[0][5]);
                                publicvariable.Ngposition = Conversions.ToString(table.Rows[0][4]);

                                if (publicvariable.Ngposition == "Administrator")
                                {
                                    My.MyProject.Forms.Form1.lbllogname.Text = "Welcome, " + publicvariable.Nname;

                                    {
                                        var withBlock = My.MyProject.Forms.Form1;

                                        withBlock.lbllogname.Visible = true;
                                        withBlock.Button1.Enabled = true;
                                        withBlock.Button2.Enabled = true;
                                        withBlock.Button4.Enabled = true;
                                        withBlock.Button5.Enabled = true;
                                        withBlock.Button6.Enabled = true;
                                        withBlock.Button7.Enabled = true;

                                    }
                                }

                                else if (publicvariable.Ngposition == "Finance Officer")
                                {

                                    My.MyProject.Forms.Form1.lbllogname.Text = "Welcome, " + publicvariable.Nname;

                                    {
                                        var withBlock1 = My.MyProject.Forms.Form1;

                                        withBlock1.lbllogname.Visible = true;
                                        // .Button1.Enabled = True
                                        // .Button2.Enabled = True
                                        withBlock1.Button4.Enabled = true;
                                        withBlock1.Button5.Enabled = true;
                                        // .Button6.Enabled = True

                                    }
                                }

                                else if (publicvariable.Ngposition == "HR")
                                {

                                    My.MyProject.Forms.Form1.lbllogname.Text = "Welcome, " + publicvariable.Nname;

                                    {
                                        var withBlock2 = My.MyProject.Forms.Form1;

                                        withBlock2.lbllogname.Visible = true;
                                        withBlock2.Button1.Enabled = true;
                                        // .Button2.Enabled = True
                                        // .Button4.Enabled = True
                                        // .Button5.Enabled = True
                                        withBlock2.Button6.Enabled = true;

                                    }




                                }


                                My.MyProject.Forms.frmlogin.Close();
                                My.MyProject.Forms.Form1.Button3.Text = "Logout";
                                break;
                            }



                        case "Tax":
                            {


                                publicvariable.emptaxid = Conversions.ToString(table.Rows[0][0]);
                                break;
                            }

                        case "Pic":
                            {

                                string path;

                                path = Conversions.ToString(table.Rows[0][2]);

                                crud.jokenupdate("UPDATE tblemppic SET picfile='" + My.MyProject.Forms.frmIndividualprofile.TextBox2.Text + "'  where empid = '" + My.MyProject.Forms.frmIndividualprofile.Label1.Text + "'");
                                Interaction.MsgBox("Picture Updated");
                                break;
                            }

                        case "picload":
                            {
                                string path;

                                path = Conversions.ToString(table.Rows[0][0]);

                                // MsgBox(Application.StartupPath & "\pictures" & "\" & path)
                                My.MyProject.Forms.frmIndividualprofile.PictureBox2.Image = Image.FromFile("" + Application.StartupPath + @"\pictures" + @"\" + path + "");
                                break;
                            }

                        case "idincre":
                            {

                                string newid;

                                newid = Conversions.ToString(table.Rows[0][0]);

                                My.MyProject.Forms.newemployee.txtemp_id.Text = newid;
                                break;
                            }
                        case "Payroll":
                            {

                                Interaction.MsgBox("Payrol record already exist");
                                break;
                            }


                    }
                }

                else
                {

                    switch (moodle ?? "")
                    {

                        case "Login":
                            {
                                Interaction.MsgBox("Contact administrator to registered!");
                                break;
                            }

                        case "picload":
                            {

                                My.MyProject.Forms.frmIndividualprofile.PictureBox2.Image = null;
                                break;
                            }

                        case "Pic":
                            {
                                string path;

                                path = My.MyProject.Forms.frmIndividualprofile.TextBox2.Text;

                                crud.jokeninsert("insert into tblemppic (picfile, empid) values ('" + path + "','" + My.MyProject.Forms.frmIndividualprofile.Label1.Text + "')");
                                Interaction.MsgBox("Picture Uploaded");
                                break;
                            }

                        case "Payroll":
                            {

                                {
                                    var withBlock3 = My.MyProject.Forms.payroll;
                                    crud.jokeninsert("INSERT INTO tblpayroll ( CLIENTID,  EMPID, CLIENT_RATE, AGENCY_FEE, MONTHLY_RATE," + " BASIC_PAY, HOURLY_RATE, HOURS_WORK, GROSS_SAL, ALLOWANCE," + " ADJUSTMENTS, GROSS_PAY,SSS, SSS_ER, HDMF, HDMF_ER, " + " PHIC, PHIC_ER, WTAX, SSS_LOANS, OTHER_LOANS, TOTAL_DED, " + " NET_INCOME, PERIOD_START, PERIOD_END, ENCODED_BY, BY_POSITION, PAGLOANS, PAYROLLID )" + " VALUES('" + withBlock3.TXTCLIENTID.Text + "','" + withBlock3.payEmpID.Text + "'," + Conversion.Val(withBlock3.txtClientRate.Text) + "," + Conversion.Val(withBlock3.txtAgencyFee.Text) + "," + Conversion.Val(withBlock3.txtByMonthlyRate.Text) + ", " + " " + Conversion.Val(withBlock3.txtbasicPay.Text) + ", " + Conversion.Val(withBlock3.txtHourlyRate.Text) + ", " + Conversion.Val(withBlock3.txtNoHoursWork.Text) + ", " + Conversion.Val(withBlock3.GrossSalary.Text) + ", " + Conversion.Val(withBlock3.txtAllowances.Text) + ", " + " " + Conversion.Val(withBlock3.txtAdjustments.Text) + ", " + Conversion.Val(withBlock3.txtGrossPay.Text) + ", " + Conversion.Val(withBlock3.txtSSS.Text) + ", " + Conversion.Val(withBlock3.txtSSS_ER.Text) + ", " + Conversion.Val(withBlock3.txtPagibig.Text) + ", " + Conversion.Val(withBlock3.txtPGIBIG_ER.Text) + ", " + " " + Conversion.Val(withBlock3.txtPhilhealth.Text) + ", " + Conversion.Val(withBlock3.txtPHIL_ER.Text) + ", " + Conversion.Val(withBlock3.txtWtax.Text) + ", " + Conversion.Val(withBlock3.txtSSSLoans.Text) + ", " + Conversion.Val(withBlock3.txtOtherLoans.Text) + ", " + Conversion.Val(withBlock3.txttotalDeductions.Text) + "," + " " + Conversion.Val(withBlock3.txtNetIncome.Text) + ",#" + withBlock3.dtpPeriodStart.Text + "#,#" + withBlock3.dtpPeriodEnd.Text + "#,'" + publicvariable.Nname + "','" + publicvariable.Ngposition + "'," + Conversion.Val(withBlock3.txtPagibigLoans.Text) + ",'" + withBlock3.lblpayrolid.Text + "')");








                                    Interaction.MsgBox("Payroll has successfully created!");

                                }

                                break;
                            }

                    }




                }
            }

            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message, MsgBoxStyle.Information);
            }

        }
    }
}
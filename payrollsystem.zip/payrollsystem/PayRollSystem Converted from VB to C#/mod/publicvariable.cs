﻿
namespace Ichiban
{
    static class publicvariable
    {
        public static System.Data.OleDb.OleDbConnection con = db.myconn();
        public static string Nname;
        public static string Ngposition;
        public static string taxid;
        public static string emptaxid;



    }
}
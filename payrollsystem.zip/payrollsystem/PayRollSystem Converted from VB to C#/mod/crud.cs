﻿using System;
using Microsoft.VisualBasic;

namespace Ichiban
{
    static class crud
    {
        private static int result;
        private static System.Data.OleDb.OleDbCommand cmd = new System.Data.OleDb.OleDbCommand();
        public static void jokeninsert(string sql)
        {
            try
            {
                publicvariable.con.Open();
                {
                    ref var withBlock = ref cmd;
                    withBlock.Connection = publicvariable.con;
                    withBlock.CommandText = sql;
                    result = cmd.ExecuteNonQuery();
                    if (result == 0)
                    {
                        Interaction.MsgBox("No Data has been Inserted!");
                        // Else
                        // MsgBox("New Data is inseted succesfully!")
                    }
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message, MsgBoxStyle.Information);

            }
            publicvariable.con.Close();

        }

        public static void jokenupdate(string sql)
        {
            try
            {
                publicvariable.con.Open();
                {
                    ref var withBlock = ref cmd;
                    withBlock.Connection = publicvariable.con;
                    withBlock.CommandText = sql;
                    result = cmd.ExecuteNonQuery();
                    if (result == 0)
                    {
                        Interaction.MsgBox("No Data has been Updated!");
                        // Else
                        // MsgBox("New Data is updated succesfully!")
                    }
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message, MsgBoxStyle.Information);

            }
            publicvariable.con.Close();

        }

        public static void jokendelete(string sql)
        {
            try
            {
                publicvariable.con.Open();
                {
                    ref var withBlock = ref cmd;
                    withBlock.Connection = publicvariable.con;
                    withBlock.CommandText = sql;
                    result = cmd.ExecuteNonQuery();
                    if (result == 0)
                    {
                        Interaction.MsgBox("No Data has been Updated!");
                        // Else
                        // MsgBox("New Data is updated succesfully!")
                    }
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message, MsgBoxStyle.Information);

            }
            publicvariable.con.Close();

        }
    }
}
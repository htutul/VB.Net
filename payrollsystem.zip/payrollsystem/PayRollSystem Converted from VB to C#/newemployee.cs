﻿using System;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace Ichiban
{
    public partial class newemployee
    {
        public newemployee()
        {
            InitializeComponent();
        }

        private void btnadd_Click(object sender, EventArgs e)
        {


            if (string.IsNullOrEmpty(txtfname.Text) | string.IsNullOrEmpty(txtlname.Text) | string.IsNullOrEmpty(txtmname.Text) | string.IsNullOrEmpty(txtbplace.Text) | string.IsNullOrEmpty(txtage.Text) | string.IsNullOrEmpty(txtgl.Text) | string.IsNullOrEmpty(txtnbic.Text) | string.IsNullOrEmpty(txtothers.Text))
            {
                Interaction.MsgBox("You must fill up the Required fields.", MsgBoxStyle.Critical);
            }
            else
            {
                var rdo = default(object);

                if (rdomale.Checked == true)
                {
                    rdo = "Male";
                }
                else if (rdofemale.Checked == true)
                {
                    rdo = "Female";
                }
                else
                {
                    Interaction.MsgBox("Please Select Gender.");
                }

                if (rbdep1.Checked & cbocivil.Text == "Married")
                {
                    publicvariable.taxid = "M1";
                }
                else if (rbdep2.Checked & cbocivil.Text == "Married")
                {
                    publicvariable.taxid = "M2";
                }
                else if (rbdep3.Checked & cbocivil.Text == "Married")
                {
                    publicvariable.taxid = "M3";
                }
                else if (rbdep4.Checked & cbocivil.Text == "Married")
                {
                    publicvariable.taxid = "M4";
                }
                else if (rbdep0.Checked & cbocivil.Text == "Married")
                {
                    publicvariable.taxid = "M";
                }

                if (rbdep1.Checked & cbocivil.Text == "Single")
                {
                    publicvariable.taxid = "S1";
                }
                else if (rbdep2.Checked & cbocivil.Text == "Single")
                {
                    publicvariable.taxid = "S2";
                }
                else if (rbdep3.Checked & cbocivil.Text == "Single")
                {
                    publicvariable.taxid = "S3";
                }
                else if (rbdep4.Checked & cbocivil.Text == "Single")
                {
                    publicvariable.taxid = "S4";
                }
                else if (rbdep0.Checked & cbocivil.Text == "Single")
                {
                    publicvariable.taxid = "S";
                }

                crud.jokeninsert(Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("INSERT INTO tblemployee " + "(EMPID,FNAME,LNAME,MI,AGE,GENDER,BDAY,BPLACE,HEIGHT,WEIGHT,CIVIL_STATUS,CONTACT,RELIGION,SPOUSE,SP_ADDRESS," + "CITIZENSHIP,HIREDDATE,WORKSTATUS,GPOSITION,ASSIGN, TAXID, PHIC, HDMF) " + "VALUES ('" + txtemp_id.Text + "','" + txtfname.Text + "','" + txtlname.Text + "','" + txtmname.Text + "','" + txtage.Text + "','", rdo), "','"), dtpbdate.Value), "','"), txtbplace.Text), "','"), txtHeight.Text), "','"), txtweight.Text), "','"), cbocivil.Text), "','"), txtContact.Text), "','"), txtreligon.Text), "','"), txtnamSpouse.Text), "','"), txtsadd.Text), "','"), txtcitizen.Text), "','"), dtpHiredate.Value), "','"), cboworkstat.Text), "','"), cbpositon.Text), "',0 ,'"), publicvariable.taxid), "','"), txtPHIC.Text), "','"), txtHDMF.Text), "')")));








                crud.jokeninsert("INSERT INTO tblempbackgrd(EMPID,MOTHER,M_ADDRESS,ELEMENTARY,ELEMYEAR,SECONDARY,SECONDARY_YEAR,TERTIARY,TERTIARY_YEAR,OTHERS,FATHER,F_ADDRESS,SPOUSE,SPOUSEADD,GLNO,POLCL,NBICL,WECOMP1,WECOMP2,WECOMP3,WEPOS1,WEPOS2,WEPOS3,WEDATE1,WEDATE2,WEDATE3)" + "VALUES ('" + txtemp_id.Text + "','" + txtmothername.Text + "','" + txtmotheradd.Text + "','" + txtelem.Text + "','" + txtelem_year.Text + "','" + txthschool.Text + "','" + txthschool_yeAR.Text + "','" + txtcollege.Text + "','" + txtcollegeYear.Text + "','" + txtothers.Text + "','" + txtfathername.Text + "','" + txtfatheradd.Text + "','" + txtnamSpouse.Text + "','" + txtsadd.Text + "','" + txtgl.Text + "','" + txtpc.Text + "','" + txtnbic.Text + "','" + txtwecom1.Text + "','" + txtwecom2.Text + "','" + txtwecom3.Text + "','" + txtwepos1.Text + "','" + txtwepos2.Text + "','" + txtwepos3.Text + "','" + txtwedate1.Text + "','" + txtwedate2.Text + "','" + txtwedate3.Text + "')");







                Interaction.MsgBox("The Data Has Been Saved in the Database.");

                My.MyProject.Forms.employee.Show();
                Close();



            }

        }

        private void newemployee_Load(object sender, EventArgs e)
        {

            string sql;

            sql = "SELECT EMPID + 3 FROM tblemployee where id=(select max (id) from tblemployee)";
            jokensqlselect.jokenfindthis(sql);
            jokensqlselect.checkresult("idincre");


            cbocivil.Text = null;
            GroupBox2.Enabled = false;
            GroupBox2.Show();





        }

        private void cbocivil_TextChanged(object sender, EventArgs e)
        {
            if (cbocivil.Text == "Single")
            {
            }
            // GroupBox2.Show()

            else if (cbocivil.Text == "Married")
            {
                GroupBox2.Enabled = true;
                txtnamSpouse.Enabled = true;
                txtsadd.Enabled = true;
            }
            else
            {
                GroupBox2.Enabled = false;

                publicvariable.taxid = "Z";

            }
        }
        private void Button1_Click(object sender, EventArgs e)
        {
            My.MyProject.Forms.frmCamera.Show();

        }

        private void dtpbdate_TextChanged(object sender, EventArgs e)
        {

            var offset = new DateTime(1, 1, 1);

            var dateOne = dtpbdate.Value;
            var dateTwo = DateTime.Now;

            var diff = dateTwo - dateOne;

            int years = (offset + diff).Year - 1;



            if (years < 18 & years < 50)
            {
                Interaction.MsgBox("Age requirement must be 18 - 50 years old!");
            }
            else
            {
                txtage.Text = years.ToString();
            }

        }

        private void txtContact_TextChanged(object sender, EventArgs e)
        {
            if (!Information.IsNumeric(txtContact.Text))
            {
                txtContact.Text = null;
            }

        }

        private void txtHeight_TextChanged(object sender, EventArgs e)
        {
            if (!Information.IsNumeric(txtHeight.Text))
            {
                txtHeight.Text = null;
            }
            if (txtHeight.TextLength > 3)
            {
                txtHeight.Text = null;
            }
        }

        private void txtweight_TextChanged(object sender, EventArgs e)
        {
            if (!Information.IsNumeric(txtweight.Text))
            {
                txtContact.Text = null;
            }
            if (txtweight.TextLength > 3)
            {
                txtweight.Text = null;
            }
        }


        private void txtmname_TextChanged(object sender, EventArgs e)
        {
            if (txtmname.TextLength > 1)
            {
                txtmname.Text = null;
            }
        }


        private void txtnbic_TextChanged(object sender, EventArgs e)
        {
            if (!Information.IsNumeric(txtnbic.Text))
            {
                txtnbic.Text = null;

            }
            if (txtnbic.TextLength > 10)
            {
                Interaction.MsgBox("TIN number must not more than 10 digits.");
            }
        }

        private void txtothers_TextChanged(object sender, EventArgs e)
        {
            if (!Information.IsNumeric(txtothers.Text))
            {
                txtothers.Text = null;
            }
            if (txtothers.TextLength > 10)
            {
                Interaction.MsgBox("SSS ID number must not more than 10 digits.");
            }
        }

        private void txtgl_TextChanged(object sender, EventArgs e)
        {
            if (!Information.IsNumeric(txtgl.Text))
            {
                txtgl.Text = null;
            }
            if (txtgl.TextLength > 10)
            {
                Interaction.MsgBox("Guard License number must not more than 10 digits.");
            }
        }

        private void txtPHIC_TextChanged(object sender, EventArgs e)
        {
            if (!Information.IsNumeric(txtPHIC.Text))
            {
                txtPHIC.Text = null;
            }
            if (txtPHIC.TextLength > 11)
            {
                Interaction.MsgBox("PHIC ID number must not more than 11 digits.");
            }
        }

        private void txtHDMF_TextChanged(object sender, EventArgs e)
        {
            if (!Information.IsNumeric(txtHDMF.Text))
            {
                txtgl.Text = null;
            }
            if (txtHDMF.TextLength > 12)
            {
                Interaction.MsgBox("HDMF ID number must not more than 12 digits.");
            }
        }

        private void dtpbdate_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}